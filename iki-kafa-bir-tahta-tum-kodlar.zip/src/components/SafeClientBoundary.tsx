"use client";

import React, { Component, type ReactNode } from "react";
import Link from "next/link";

interface Props {
  children: ReactNode;
  fallbackTitle?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class SafeClientBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("SafeClientBoundary caught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <main className="flex min-h-screen flex-col items-center justify-center bg-[#0d2e13] px-4 text-center text-white">
          <div className="w-full max-w-sm rounded-3xl border border-white/20 bg-black/40 p-6 shadow-2xl backdrop-blur">
            <div className="text-4xl mb-3">🁫</div>
            <h2 className="text-lg font-black text-amber-400">
              {this.props.fallbackTitle || "İki Kafa Bir Tahta"}
            </h2>
            <p className="mt-2 text-xs text-slate-300">
              Oyun tahtası hazırlanırken bir durum oluştu. Yeniden Başlat&#39;a basarak hemen oyuna başlayabilirsiniz.
            </p>
            <div className="mt-5 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => {
                  try {
                    localStorage.removeItem("pc_domino_save_v7");
                    localStorage.removeItem("pc_domino_save_v6");
                    localStorage.removeItem("pc_domino_save_v5");
                  } catch {}
                  window.location.reload();
                }}
                className="w-full rounded-xl bg-amber-500 py-3 text-sm font-black text-slate-950 shadow hover:bg-amber-400 active:scale-95 transition"
              >
                Yeniden Başlat ↻
              </button>
              <Link
                href="/"
                className="w-full rounded-xl bg-white/10 py-2.5 text-xs font-bold text-white hover:bg-white/20 transition"
              >
                Ana Sayfaya Dön →
              </Link>
            </div>
          </div>
        </main>
      );
    }

    return this.props.children;
  }
}
