"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { LANGUAGES, type Language, useI18n } from "@/lib/i18n";

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 py-2.5">
      <div className="text-sm font-medium">{label}</div>
      <div className="flex flex-wrap items-center gap-1.5">{children}</div>
    </div>
  );
}

function Toggle({
  value,
  options,
  onChange,
}: {
  value: string;
  options: { id: string; label: string }[];
  onChange: (v: string) => void;
}) {
  return (
    <>
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          onClick={() => onChange(o.id)}
          className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
            value === o.id ? "bg-amber-400 text-slate-900 shadow-sm" : "bg-white/10 hover:bg-white/20"
          }`}
        >
          {o.label}
        </button>
      ))}
    </>
  );
}

export interface SessionInfo {
  id: string;
  name: string;
  email: string;
  picture: string | null;
}

export function SettingsModal({ onClose }: { onClose: () => void }) {
  const { lang, t } = useI18n();
  const [currentLang, setCurrentLang] = useState<Language>(lang);
  const [theme, setTheme] = useState("dark");
  const [fps, setFps] = useState("1");
  const [fpsCap, setFpsCap] = useState("120");
  const [anim, setAnim] = useState("1");
  const [animMs, setAnimMs] = useState("320");
  const [hints, setHints] = useState("0");
  const [nick, setNick] = useState("");

  useEffect(() => {
    try {
      const l = (localStorage.getItem("pc_lang") as Language) || "tr";
      setCurrentLang(l);
      setTheme(localStorage.getItem("pc_theme") || "dark");
      setFps(localStorage.getItem("pc_fps") ?? "1");
      setFpsCap(localStorage.getItem("pc_fps_cap") || "120");
      setAnim(localStorage.getItem("pc_anim") ?? "1");
      setAnimMs(localStorage.getItem("pc_anim_ms") ?? "320");
      setHints(localStorage.getItem("pc_game_hints") ?? "0");
      setNick(localStorage.getItem("pc_nick") || "");
    } catch {}
  }, []);

  const save = (key: string, val: string) => {
    try {
      localStorage.setItem(key, val);
      window.dispatchEvent(new CustomEvent("pc-settings"));
    } catch {}
  };

  const handleLangChange = (newLang: Language) => {
    setCurrentLang(newLang);
    save("pc_lang", newLang);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="pc-fade-up max-h-[90vh] w-full max-w-sm overflow-y-auto rounded-3xl border border-white/15 bg-[#141b36] p-5 text-slate-100 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-bold">⚙️ {t.settings}</h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg bg-white/10 px-2.5 py-1 text-sm font-bold hover:bg-white/20"
            aria-label="Kapat"
          >
            ✕
          </button>
        </div>

        <div className="divide-y divide-white/10">
          {/* Dil Seçimi (Language) */}
          <div className="py-2.5">
            <div className="mb-1.5 text-sm font-medium">🌐 Dil / Language</div>
            <div className="grid grid-cols-3 gap-1.5">
              {LANGUAGES.map((l) => (
                <button
                  key={l.code}
                  type="button"
                  onClick={() => handleLangChange(l.code)}
                  className={`flex items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs font-semibold transition ${
                    currentLang === l.code ? "bg-amber-400 text-slate-900 font-bold" : "bg-white/10 hover:bg-white/20"
                  }`}
                >
                  <span>{l.flag}</span>
                  <span>{l.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Tema Seçimi */}
          <Row label={t.theme}>
            <Toggle
              value={theme}
              onChange={(v) => {
                setTheme(v);
                save("pc_theme", v);
              }}
              options={[
                { id: "dark", label: "🌙 Koyu" },
                { id: "ocean", label: "🌊 Okyanus" },
                { id: "forest", label: "🌲 Orman" },
                { id: "midnight", label: "🌑 Gece" },
                { id: "light", label: "☀️ Açık" },
              ]}
            />
          </Row>

          {/* İpuçları & Rehber */}
          <div className="py-2.5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium">{t.hints}</div>
                <div className="pc-dim text-[11px]">{t.hintsDesc}</div>
              </div>
              <div className="flex gap-1">
                <Toggle
                  value={hints}
                  onChange={(v) => {
                    setHints(v);
                    save("pc_game_hints", v);
                  }}
                  options={[
                    { id: "0", label: t.off },
                    { id: "1", label: t.on },
                  ]}
                />
              </div>
            </div>
          </div>

          <Row label="Taş / Kart Animasyonu">
            <Toggle
              value={anim}
              onChange={(v) => {
                setAnim(v);
                save("pc_anim", v);
              }}
              options={[
                { id: "1", label: t.on },
                { id: "0", label: t.off },
              ]}
            />
          </Row>

          {anim === "1" && (
            <Row label="Animasyon hızı">
              <Toggle
                value={animMs}
                onChange={(v) => {
                  setAnimMs(v);
                  save("pc_anim_ms", v);
                }}
                options={[
                  { id: "180", label: "Hızlı" },
                  { id: "320", label: "Normal" },
                  { id: "550", label: "Yavaş" },
                  { id: "950", label: "🐢 Ultra Yavaş" },
                ]}
              />
            </Row>
          )}

          <Row label="FPS göstergesi">
            <Toggle
              value={fps}
              onChange={(v) => {
                setFps(v);
                save("pc_fps", v);
              }}
              options={[
                { id: "1", label: t.on },
                { id: "0", label: t.off },
              ]}
            />
          </Row>

          {fps === "1" && (
            <Row label="FPS hedefi">
              <Toggle
                value={fpsCap}
                onChange={(v) => {
                  setFpsCap(v);
                  save("pc_fps_cap", v);
                }}
                options={[
                  { id: "30", label: "30" },
                  { id: "60", label: "60" },
                  { id: "90", label: "90" },
                  { id: "120", label: "120" },
                ]}
              />
            </Row>
          )}

          <div className="py-2.5">
            <div className="mb-1.5 text-sm font-medium">{t.yourNick}</div>
            <div className="flex gap-2">
              <input
                value={nick}
                onChange={(e) => setNick(e.target.value)}
                maxLength={40}
                placeholder="Örn. Magnus"
                className="min-w-0 flex-1 rounded-lg border border-white/20 bg-white/10 px-3 py-2 text-sm text-white placeholder-slate-400 focus:border-amber-400 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => {
                  const v = nick.trim();
                  if (v) save("pc_nick", v);
                }}
                className="rounded-lg bg-amber-500 px-3 py-2 text-xs font-bold text-slate-900 hover:bg-amber-400"
              >
                Kaydet
              </button>
            </div>
          </div>
        </div>
        <p className="pc-faint mt-2 text-[11px]">Ayarlar cihazda saklanır · İnternetsiz çalışır.</p>
      </div>
    </div>
  );
}

export function useSession() {
  const [user, setUser] = useState<SessionInfo | null>(null);
  const [localName, setLocalName] = useState("");
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    try {
      setLocalName(localStorage.getItem("pc_name") || "");
      fetch("/api/auth/me", { cache: "no-store" })
        .then((r) => r.json())
        .then((d) => {
          setUser(d.user ?? null);
          if (d.user?.name && !localStorage.getItem("pc_nick")) {
            localStorage.setItem("pc_nick", d.user.name);
          }
        })
        .catch(() => {})
        .finally(() => setLoaded(true));
    } catch {
      setLoaded(true);
    }
  }, []);
  return { user, localName, loaded };
}

export function Header() {
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const { user, localName } = useSession();
  const { t, lang } = useI18n();
  const display = user?.name || localName;

  const logout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
      localStorage.removeItem("pc_name");
    } catch {}
    location.href = "/";
  };

  const currentFlag = LANGUAGES.find((l) => l.code === lang)?.flag || "🇹🇷";

  return (
    <header className="mb-6 flex items-center justify-between">
      <Link href="/" className="group flex items-center gap-2 text-2xl font-black tracking-tight">
        <span>{t.appName || "İki Kafa Bir Tahta"}</span>
      </Link>
      <div className="relative flex items-center gap-2">
        {/* Quick Language button */}
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="pc-ghost flex h-9 items-center justify-center rounded-lg px-2 text-sm font-bold transition hover:bg-white/20"
          title="Dil / Language"
        >
          {currentFlag}
        </button>

        {display ? (
          <button
            type="button"
            onClick={() => setMenu((m) => !m)}
            className="pc-ghost flex max-w-[180px] items-center gap-2 rounded-lg px-2 py-1 text-xs font-semibold"
            title={user?.email || "Hesap"}
          >
            {user?.picture ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={user.picture}
                alt=""
                referrerPolicy="no-referrer"
                className="h-6 w-6 rounded-full"
              />
            ) : (
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-400 text-[11px] font-black text-slate-900">
                {display.slice(0, 1).toUpperCase()}
              </span>
            )}
            <span className="truncate">{display}</span>
          </button>
        ) : (
          <Link href="/giris" className="pc-ghost rounded-lg px-3 py-1.5 text-xs font-semibold">
            👤 {t.googleLogin}
          </Link>
        )}
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="pc-ghost flex h-9 w-9 items-center justify-center rounded-lg text-lg transition hover:rotate-45"
          title={t.settings}
          aria-label={t.settings}
        >
          ⚙️
        </button>
        {menu && display && (
          <div className="pc-fade-up absolute right-11 top-11 z-40 w-52 rounded-xl border border-white/15 bg-[#141b36] p-2 text-slate-100 shadow-2xl">
            <div className="px-2 py-1.5 text-xs">
              <div className="font-bold">{display}</div>
              <div className="pc-faint truncate">{user?.email || "çevrimdışı hazır"}</div>
            </div>
            <button
              type="button"
              onClick={logout}
              className="mt-1 w-full rounded-lg bg-white/10 px-2 py-1.5 text-left text-xs font-semibold hover:bg-red-500/30"
            >
              ⎋ Çıkış yap
            </button>
          </div>
        )}
        {open && <SettingsModal onClose={() => setOpen(false)} />}
      </div>
    </header>
  );
}
