"use client";

import { useEffect, useState, type ReactNode } from "react";
import { FpsMeter } from "./FpsMeter";

export function AppShell({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<string>("dark");
  const [fpsOn, setFpsOn] = useState(true);
  const [fpsCap, setFpsCap] = useState(120);
  const [anim, setAnim] = useState<"on" | "off">("on");
  const [speed, setSpeed] = useState(320);

  useEffect(() => {
    const read = () => {
      const t = localStorage.getItem("pc_theme");
      setTheme(t || "dark");
      const f = localStorage.getItem("pc_fps");
      setFpsOn(f === null ? true : f === "1");
      const capVal = Number(localStorage.getItem("pc_fps_cap"));
      setFpsCap([30, 60, 90, 120].includes(capVal) ? capVal : 120);
      const a = localStorage.getItem("pc_anim");
      setAnim(a === "0" ? "off" : "on");
      const s = Number(localStorage.getItem("pc_anim_ms"));
      setSpeed(s >= 100 && s <= 1200 ? s : 320);
    };
    read();
    window.addEventListener("pc-settings", read);
    return () => window.removeEventListener("pc-settings", read);
  }, []);

  return (
    <div
      data-theme={theme}
      data-anim={anim}
      className="pc-app min-h-screen"
      style={{ ["--pc-anim-ms" as string]: `${speed}ms` }}
    >
      {children}
      <FpsMeter show={fpsOn} cap={fpsCap} />
    </div>
  );
}
