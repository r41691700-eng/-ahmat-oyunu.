"use client";

import { useEffect, useRef, useState } from "react";

export function FpsMeter({ show, cap = 120 }: { show: boolean; cap?: number }) {
  const [fps, setFps] = useState(0);
  const frames = useRef(0);
  const last = useRef(0);
  const raf = useRef(0);

  useEffect(() => {
    if (!show) return;
    last.current = performance.now();
    frames.current = 0;
    const loop = (t: number) => {
      frames.current += 1;
      if (t - last.current >= 400) {
        setFps(Math.round((frames.current * 1000) / (t - last.current)));
        frames.current = 0;
        last.current = t;
      }
      raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf.current);
  }, [show]);

  if (!show) return null;
  const color = fps >= cap * 0.75 ? "#34d399" : fps >= cap * 0.45 ? "#fbbf24" : "#f87171";
  const width = Math.min(100, Math.round((fps / cap) * 100));

  return (
    <div className="pointer-events-none fixed bottom-3 right-3 z-50 select-none rounded-lg border border-white/10 bg-black/75 px-3 py-2 font-mono text-[11px] text-slate-100 shadow-xl backdrop-blur">
      <div className="flex items-center justify-between gap-3">
        <span>
          <span style={{ color }} className="text-sm font-bold tabular-nums">
            {fps}
          </span>{" "}
          FPS
        </span>
        <span className="text-slate-400 tabular-nums">≤{cap}</span>
      </div>
      <div className="mt-1 h-1.5 w-28 overflow-hidden rounded-full bg-white/10">
        <div
          className="h-full rounded-full transition-[width] duration-300"
          style={{ width: `${width}%`, backgroundColor: color }}
        />
      </div>
    </div>
  );
}
