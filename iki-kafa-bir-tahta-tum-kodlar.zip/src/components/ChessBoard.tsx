"use client";

import type { Square } from "chess.js";
import { Chess } from "chess.js";
import type { ChessState } from "@/lib/chessState";

const FILES = ["a", "b", "c", "d", "e", "f", "g", "h"] as const;

interface Props {
  state: ChessState;
  orientation: "w" | "b";
  selected: Square | null;
  targets: { to: Square; capture: boolean }[];
  lastMove: { from: Square; to: Square } | null;
  checkSq: Square | null;
  interactive: boolean;
  onSquare: (sq: Square) => void;
  popKey: number;
}

function fileRank(sq: Square): [number, number] {
  return [FILES.indexOf(sq[0] as (typeof FILES)[number]), parseInt(sq[1], 10) - 1];
}

export function ChessBoard({
  state,
  orientation,
  selected,
  targets,
  lastMove,
  checkSq,
  interactive,
  onSquare,
  popKey,
}: Props) {
  const ch = new Chess(state.fen);
  const board = ch.board(); // [0] = rank 8

  const cells: { rank: number; file: number }[] = [];
  for (let d = 0; d < 8; d++) {
    for (let e = 0; e < 8; e++) {
      cells.push({
        rank: orientation === "w" ? 7 - d : d,
        file: orientation === "w" ? e : 7 - e,
      });
    }
  }

  // slide offset (in % of a square) for the piece that just moved
  let slide: { dx: number; dy: number } | null = null;
  if (lastMove) {
    const [ff, fr] = fileRank(lastMove.from);
    const [tf, tr] = fileRank(lastMove.to);
    const sx = orientation === "w" ? ff - tf : tf - ff;
    const sy = orientation === "w" ? tr - fr : fr - tr;
    slide = { dx: sx * 100, dy: sy * 100 };
  }

  return (
    <div
      className="grid aspect-square w-full select-none overflow-hidden rounded-lg shadow-2xl shadow-black/50"
      style={{
        gridTemplateColumns: "repeat(8, minmax(0, 1fr))",
        gridTemplateRows: "repeat(8, minmax(0, 1fr))",
        touchAction: "manipulation",
      }}
    >
      {cells.map(({ rank, file }) => {
        const square = `${FILES[file]}${rank + 1}` as Square;
        const piece = board[7 - rank][file];
        const isLight = (rank + file) % 2 === 1;
        const isSelected = selected === square;
        const isLast = lastMove && (lastMove.from === square || lastMove.to === square);
        const isCheck = checkSq === square;
        const target = targets.find((t) => t.to === square);
        const isMoved = !!lastMove && lastMove.to === square;
        return (
          <button
            key={square}
            type="button"
            onClick={() => interactive && onSquare(square)}
            className={`relative m-0 block min-h-0 min-w-0 overflow-visible p-0 ${
              isLight ? "bg-[#f0d9b5]" : "bg-[#b58863]"
            } ${interactive ? "cursor-pointer" : "cursor-default"}`}
            aria-label={square}
          >
            {isLast && <span className="pointer-events-none absolute inset-0 bg-amber-400/35" />}
            {isCheck && (
              <span
                className="pointer-events-none absolute inset-0"
                style={{
                  background:
                    "radial-gradient(circle, rgba(239,68,68,0.85) 15%, rgba(239,68,68,0.25) 55%, transparent 75%)",
                }}
              />
            )}
            {isSelected && <span className="pointer-events-none absolute inset-0 bg-emerald-400/45" />}
            {piece && (
              <span
                key={isMoved ? `mv-${popKey}` : `pc-${square}`}
                className={`pointer-events-none absolute inset-0 z-10 flex items-center justify-center ${
                  isMoved && slide ? "pc-slide" : ""
                }`}
                style={
                  isMoved && slide
                    ? ({ "--dx": `${slide.dx}%`, "--dy": `${slide.dy}%` } as React.CSSProperties)
                    : undefined
                }
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={`/pieces/${piece.color}${piece.type.toUpperCase()}.svg`}
                  alt=""
                  draggable={false}
                  className="h-[88%] w-[88%] select-none"
                  style={{ filter: "drop-shadow(0 1px 1px rgba(0,0,0,0.35))" }}
                />
              </span>
            )}
            {target && !target.capture && (
              <span className="pointer-events-none absolute left-1/2 top-1/2 z-20 h-[30%] w-[30%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-500/60" />
            )}
            {target && target.capture && (
              <span className="pointer-events-none absolute inset-[6%] z-20 rounded-full border-[3px] border-emerald-500/70" />
            )}
            {file === (orientation === "w" ? 0 : 7) && (
              <span
                className={`pointer-events-none absolute left-0.5 top-0.5 text-[9px] font-bold leading-none sm:text-[10px] ${
                  isLight ? "text-[#b58863]" : "text-[#f0d9b5]"
                }`}
              >
                {rank + 1}
              </span>
            )}
            {rank === (orientation === "w" ? 0 : 7) && (
              <span
                className={`pointer-events-none absolute bottom-0.5 right-1 text-[9px] font-bold leading-none sm:text-[10px] ${
                  isLight ? "text-[#b58863]" : "text-[#f0d9b5]"
                }`}
              >
                {FILES[file]}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
