"use client";

import { CK_N, ckC, ckR, type CKState, type CKColor } from "@/lib/checkers";

function Crown({ dark }: { dark: boolean }) {
  return (
    <svg viewBox="0 0 24 24" className="h-[55%] w-[55%]" aria-hidden="true">
      <path
        d="M3 18h18l-1.2-9-4.3 3.4L12 5 8.5 12.4 4.2 9 3 18z"
        fill={dark ? "#fbbf24" : "#b45309"}
        stroke={dark ? "#78350f" : "#fde68a"}
        strokeWidth="1.4"
        strokeLinejoin="round"
      />
    </svg>
  );
}

interface Props {
  state: CKState;
  orientation: CKColor; // whose pieces sit at the bottom
  selected: number | null;
  targets: number[];
  interactive: boolean;
  onSquare: (i: number) => void;
  popKey: number;
}

export function CheckersBoard({
  state,
  orientation,
  selected,
  targets,
  interactive,
  onSquare,
  popKey,
}: Props) {
  const cells: number[] = [];
  for (let d = 0; d < CK_N; d++) {
    for (let e = 0; e < CK_N; e++) {
      const r = orientation === "w" ? d : CK_N - 1 - d;
      const c = orientation === "w" ? e : CK_N - 1 - e;
      cells.push(r * CK_N + c);
    }
  }
  const files = "abcdefgh".split("");
  const capSet = new Set(state.lastMove?.caps ?? []);
  const pathSet = new Set(state.lastMove?.path ?? []);

  let slide: { dx: number; dy: number } | null = null;
  if (state.lastMove) {
    const dr = ckR(state.lastMove.from) - ckR(state.lastMove.to);
    const dc = ckC(state.lastMove.from) - ckC(state.lastMove.to);
    const sign = orientation === "w" ? 1 : -1;
    slide = { dx: dc * 100 * sign, dy: dr * 100 * sign };
  }

  return (
    <div
      className="grid aspect-square w-full select-none overflow-hidden rounded-lg shadow-2xl shadow-black/50"
      style={{
        gridTemplateColumns: `repeat(${CK_N}, minmax(0, 1fr))`,
        gridTemplateRows: `repeat(${CK_N}, minmax(0, 1fr))`,
        touchAction: "manipulation",
      }}
    >
      {cells.map((i) => {
        const r = ckR(i);
        const c = ckC(i);
        const dark = (r + c) % 2 === 1;
        const piece = state.board[i];
        const isSel = selected === i;
        const onPath = pathSet.has(i);
        const isTarget = targets.includes(i);
        const isMoved = !!state.lastMove && state.lastMove.to === i;
        const isCap = capSet.has(i);
        return (
          <button
            key={i}
            type="button"
            onClick={() => interactive && onSquare(i)}
            className={`relative m-0 block min-h-0 min-w-0 p-0 ${
              dark ? "bg-[#8a6544]" : "bg-[#ecd9b0]"
            } ${interactive ? "cursor-pointer" : "cursor-default"}`}
            aria-label={`${files[c]}${CK_N - r}`}
          >
            {onPath && <span className="pointer-events-none absolute inset-0 bg-amber-400/30" />}
            {isSel && <span className="pointer-events-none absolute inset-0 bg-emerald-400/40" />}
            {isCap && (
              <span className="pointer-events-none absolute inset-[14%] rounded-full border-2 border-dashed border-red-500/80" />
            )}
            {piece && (
              <span
                key={isMoved ? `mv-${popKey}` : `pc-${i}`}
                className={`pointer-events-none absolute inset-0 z-10 flex items-center justify-center ${
                  isMoved && slide ? "pc-slide" : ""
                }`}
                style={
                  isMoved && slide
                    ? ({ "--dx": `${slide.dx}%`, "--dy": `${slide.dy}%` } as React.CSSProperties)
                    : undefined
                }
              >
                <span
                  className="flex h-[78%] w-[78%] items-center justify-center rounded-full"
                  style={{
                    background:
                      piece.c === "w"
                        ? "radial-gradient(circle at 35% 30%, #ffffff, #e7e5e4 55%, #a8a29e)"
                        : "radial-gradient(circle at 35% 30%, #57534e, #1c1917 60%, #000)",
                    border: piece.c === "w" ? "2px solid #78716c" : "2px solid #000",
                    boxShadow: "0 2px 4px rgba(0,0,0,0.45), inset 0 0 0 3px rgba(0,0,0,0.08)",
                  }}
                >
                  {piece.k && <Crown dark={piece.c === "b"} />}
                </span>
              </span>
            )}
            {!piece && isTarget && (
              <span className="pointer-events-none absolute left-1/2 top-1/2 z-20 h-[34%] w-[34%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-500/70" />
            )}
            {c === (orientation === "w" ? 0 : CK_N - 1) && (
              <span
                className={`pointer-events-none absolute left-0.5 top-0.5 text-[8px] font-bold leading-none sm:text-[10px] ${
                  dark ? "text-[#ecd9b0]" : "text-[#8a6544]"
                }`}
              >
                {CK_N - r}
              </span>
            )}
            {r === (orientation === "w" ? CK_N - 1 : 0) && (
              <span
                className={`pointer-events-none absolute bottom-0.5 right-1 text-[8px] font-bold leading-none sm:text-[10px] ${
                  dark ? "text-[#ecd9b0]" : "text-[#8a6544]"
                }`}
              >
                {files[c]}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
