"use client";

import React from "react";
import type { UnoCard, UnoColor } from "@/lib/uno";

interface UnoCardViewProps {
  card?: UnoCard;
  faceDown?: boolean;
  playable?: boolean;
  selected?: boolean;
  onClick?: () => void;
  size?: "sm" | "md" | "lg";
  className?: string;
  style?: React.CSSProperties;
}

const COLOR_MAP: Record<UnoColor, { bg: string; border: string; text: string; fill: string }> = {
  red: { bg: "bg-[#e52521]", border: "border-[#b51410]", text: "text-[#e52521]", fill: "#e52521" },
  yellow: { bg: "bg-[#f9c70c]", border: "border-[#c49b04]", text: "text-[#d99b00]", fill: "#f9c70c" },
  green: { bg: "bg-[#2ba84a]", border: "border-[#1d7934]", text: "text-[#2ba84a]", fill: "#2ba84a" },
  blue: { bg: "bg-[#0956a8]", border: "border-[#053d79]", text: "text-[#0956a8]", fill: "#0956a8" },
  wild: { bg: "bg-[#18181b]", border: "border-[#09090b]", text: "text-white", fill: "#ffffff" },
};

// Gerçekçi UNO Tersine Çevir (Reverse) Çift Kavisli Döngü Oku (Official Vector Style)
function ReverseSvg({ color = "currentColor", size = "100%" }: { color?: string; size?: string | number }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className="overflow-visible" aria-hidden="true">
      {/* Üst ok: sola doğru kavis */}
      <path
        d="M 75,32 A 28,28 0 0,0 26,38 L 32,28 M 26,38 L 14,35"
        fill="none"
        stroke={color}
        strokeWidth="11"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Alt ok: sağa doğru kavis */}
      <path
        d="M 25,68 A 28,28 0 0,0 74,62 L 68,72 M 74,62 L 86,65"
        fill="none"
        stroke={color}
        strokeWidth="11"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

// Gerçekçi UNO Pas / Skip İkonu (Çapraz Çizgili Daire)
function SkipSvg({ color = "currentColor", size = "100%" }: { color?: string; size?: string | number }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} aria-hidden="true">
      <circle cx="50" cy="50" r="38" fill="none" stroke={color} strokeWidth="12" />
      <line x1="24" y1="24" x2="76" y2="76" stroke={color} strokeWidth="12" strokeLinecap="round" />
    </svg>
  );
}

// 4 Renkli Wild Çarkı
function WildWheelSvg({ size = "100%" }: { size?: string | number }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className="overflow-visible" aria-hidden="true">
      <path d="M 50,50 L 50,6 A 44,44 0 0,1 94,50 Z" fill="#0956a8" />
      <path d="M 50,50 L 94,50 A 44,44 0 0,1 50,94 Z" fill="#f9c70c" />
      <path d="M 50,50 L 50,94 A 44,44 0 0,1 6,50 Z" fill="#2ba84a" />
      <path d="M 50,50 L 6,50 A 44,44 0 0,1 50,6 Z" fill="#e52521" />
      <circle cx="50" cy="50" r="44" fill="none" stroke="#ffffff" strokeWidth="4" />
    </svg>
  );
}

export function UnoCardView({
  card,
  faceDown = false,
  playable = false,
  selected = false,
  onClick,
  size = "md",
  className = "",
  style,
}: UnoCardViewProps) {
  const sizeClasses =
    size === "sm"
      ? "w-11 h-16 rounded-xl text-xs"
      : size === "lg"
      ? "w-24 h-36 rounded-3xl text-3xl"
      : "w-16 h-24 rounded-2xl text-lg";

  // Kapalı kart (Arka yüz)
  if (faceDown || !card) {
    return (
      <div
        onClick={onClick}
        style={style}
        className={`relative shrink-0 select-none cursor-pointer overflow-hidden border-2 border-neutral-900 bg-neutral-950 p-1 shadow-lg transition-all duration-200 active:scale-95 ${sizeClasses} ${className}`}
      >
        <div className="flex h-full w-full items-center justify-center rounded-xl bg-gradient-to-br from-neutral-850 via-neutral-900 to-black p-1">
          <div className="flex h-full w-full -rotate-15 items-center justify-center rounded-full bg-gradient-to-r from-red-600 to-rose-700 shadow-inner border border-red-500/40">
            <span
              className="font-black italic tracking-tighter text-amber-300 drop-shadow-[0_2px_3px_rgba(0,0,0,0.8)]"
              style={{ fontSize: "72%" }}
            >
              UNO
            </span>
          </div>
        </div>
      </div>
    );
  }

  const { color, value } = card;
  const isWild = color === "wild";
  const colors = COLOR_MAP[color];

  // Merkez sembolü çiz
  const renderCenterContent = () => {
    if (value === "reverse") {
      return (
        <div className="h-[62%] w-[62%] flex items-center justify-center">
          <ReverseSvg color={colors.fill} />
        </div>
      );
    }
    if (value === "skip") {
      return (
        <div className="h-[62%] w-[62%] flex items-center justify-center">
          <SkipSvg color={colors.fill} />
        </div>
      );
    }
    if (value === "wild") {
      return (
        <div className="h-[74%] w-[74%] flex items-center justify-center">
          <WildWheelSvg />
        </div>
      );
    }
    if (value === "wild4") {
      return (
        <div className="flex flex-col items-center justify-center">
          <div className="h-7 w-7 mb-0.5">
            <WildWheelSvg />
          </div>
          <span className="font-black italic text-neutral-950 text-base leading-none drop-shadow-sm">+4</span>
        </div>
      );
    }
    if (value === "draw2") {
      return (
        <span className={`font-black italic tracking-tight drop-shadow-sm ${colors.text}`} style={{ fontSize: "78%" }}>
          +2
        </span>
      );
    }
    return (
      <span className={`font-black italic tracking-tight drop-shadow-sm ${colors.text}`} style={{ fontSize: "105%" }}>
        {value}
      </span>
    );
  };

  // Köşe küçük sembolü
  const renderCornerContent = () => {
    if (value === "reverse") {
      return (
        <div className="w-2.5 h-2.5">
          <ReverseSvg color="#ffffff" />
        </div>
      );
    }
    if (value === "skip") {
      return (
        <div className="w-2.5 h-2.5">
          <SkipSvg color="#ffffff" />
        </div>
      );
    }
    if (value === "wild") return "W";
    if (value === "wild4") return "+4";
    if (value === "draw2") return "+2";
    return value;
  };

  return (
    <div
      onClick={onClick}
      style={style}
      className={`relative shrink-0 select-none overflow-hidden border-2 ${colors.border} ${colors.bg} p-1 shadow-lg transition-all duration-200 ${
        playable
          ? "cursor-pointer hover:-translate-y-2 hover:shadow-2xl ring-2 ring-white/80 active:scale-95"
          : "opacity-90"
      } ${selected ? "-translate-y-4 scale-105 ring-4 ring-amber-300 shadow-2xl z-20" : ""} ${sizeClasses} ${className}`}
    >
      {/* Kartın iç beyaz/elips merkezi */}
      <div className="relative flex h-full w-full items-center justify-center overflow-hidden rounded-xl bg-white/10 shadow-inner">
        {/* Wild arka planı: 4 renkli şık geçiş */}
        {isWild ? (
          <div className="absolute inset-0 flex flex-wrap opacity-95">
            <div className="h-1/2 w-1/2 bg-[#e52521]" />
            <div className="h-1/2 w-1/2 bg-[#0956a8]" />
            <div className="h-1/2 w-1/2 bg-[#f9c70c]" />
            <div className="h-1/2 w-1/2 bg-[#2ba84a]" />
          </div>
        ) : null}

        {/* Beyaz iç elips */}
        <div className="relative flex h-[84%] w-[84%] -rotate-12 items-center justify-center rounded-full bg-white shadow-md">
          {renderCenterContent()}
        </div>

        {/* Sol üst ve sağ alt küçük semboller */}
        <div className="absolute left-1.5 top-1 flex items-center justify-center text-[62%] font-black text-white drop-shadow">
          {renderCornerContent()}
        </div>
        <div className="absolute bottom-1 right-1.5 flex items-center justify-center text-[62%] font-black text-white drop-shadow">
          {renderCornerContent()}
        </div>
      </div>
    </div>
  );
}
