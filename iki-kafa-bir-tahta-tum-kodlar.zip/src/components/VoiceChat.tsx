"use client";

import React, { useEffect, useRef, useState } from "react";
import { useI18n } from "@/lib/i18n";

interface VoiceChatProps {
  roomCode: string;
  role: "host" | "guest";
}

export function VoiceChat({ roomCode, role }: VoiceChatProps) {
  const { t } = useI18n();
  const [active, setActive] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [muted, setMuted] = useState(false);
  const [peerConnected, setPeerConnected] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const pollTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastSignalTsRef = useRef<number>(0);

  const cleanup = () => {
    if (pollTimerRef.current) clearInterval(pollTimerRef.current);
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
    }
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    setActive(false);
    setConnecting(false);
    setPeerConnected(false);
  };

  const startVoice = async () => {
    setErrorMsg(null);
    setConnecting(true);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Tarayıcınız mikrofon erişimini desteklemiyor.");
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        video: false,
      });
      localStreamRef.current = stream;

      const pc = new RTCPeerConnection({
        iceServers: [
          { urls: "stun:stun.l.google.com:19302" },
          { urls: "stun:stun1.l.google.com:19302" },
        ],
      });
      pcRef.current = pc;

      // Add local audio tracks
      stream.getAudioTracks().forEach((track) => pc.addTrack(track, stream));

      // Handle remote audio
      pc.ontrack = (event) => {
        if (remoteAudioRef.current && event.streams[0]) {
          remoteAudioRef.current.srcObject = event.streams[0];
          remoteAudioRef.current.play().catch(() => {});
          setPeerConnected(true);
        }
      };

      pc.onconnectionstatechange = () => {
        if (pc.connectionState === "connected") {
          setPeerConnected(true);
          setConnecting(false);
        } else if (pc.connectionState === "disconnected" || pc.connectionState === "failed") {
          setPeerConnected(false);
        }
      };

      // Collect ICE candidates and send
      pc.onicecandidate = (event) => {
        if (event.candidate) {
          sendSignal({ candidate: event.candidate });
        }
      };

      // If host, create offer; if guest, wait for offer
      if (role === "host") {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        await sendSignal({ sdp: offer });
      }

      setActive(true);
      setConnecting(false);

      // Start polling for signals from other peer
      pollTimerRef.current = setInterval(pollSignals, 1200);
    } catch (err: unknown) {
      console.error("voice chat start error", err);
      const msg = err instanceof Error ? err.message : "Mikrofon başlatılamadı";
      setErrorMsg(msg);
      setConnecting(false);
      cleanup();
    }
  };

  const sendSignal = async (signalData: Record<string, unknown>) => {
    try {
      await fetch(`/api/rooms/${roomCode}/voice`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ from: role, signal: signalData }),
      });
    } catch {
      // ignore
    }
  };

  const pollSignals = async () => {
    try {
      const res = await fetch(`/api/rooms/${roomCode}/voice`, { cache: "no-store" });
      const data = await res.json();
      if (!data.signals) return;

      const otherKey = role === "host" ? "guestSignal" : "hostSignal";
      const otherSignal = data.signals[otherKey];
      if (!otherSignal || !otherSignal.ts || otherSignal.ts <= lastSignalTsRef.current) return;
      lastSignalTsRef.current = otherSignal.ts;

      const pc = pcRef.current;
      if (!pc) return;

      if (otherSignal.sdp) {
        if (role === "guest" && otherSignal.sdp.type === "offer") {
          await pc.setRemoteDescription(new RTCSessionDescription(otherSignal.sdp));
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          await sendSignal({ sdp: answer });
        } else if (role === "host" && otherSignal.sdp.type === "answer") {
          await pc.setRemoteDescription(new RTCSessionDescription(otherSignal.sdp));
        }
      }

      if (otherSignal.candidate && pc.remoteDescription) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(otherSignal.candidate));
        } catch {
          // ignore duplicate candidate
        }
      }
    } catch {
      // ignore
    }
  };

  const toggleMute = () => {
    if (localStreamRef.current) {
      const newMuted = !muted;
      localStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = !newMuted;
      });
      setMuted(newMuted);
    }
  };

  useEffect(() => {
    return () => {
      cleanup();
    };
  }, []);

  return (
    <div className="relative inline-flex items-center">
      <audio ref={remoteAudioRef} autoPlay playsInline />

      {!active ? (
        <button
          type="button"
          onClick={startVoice}
          disabled={connecting}
          className="flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-bold text-white shadow-sm transition hover:bg-white/20 active:scale-95 disabled:opacity-50"
          title={t.voiceChat}
        >
          <span className="text-sm">🎙️</span>
          <span>{connecting ? t.voiceConnecting : t.voiceChat}</span>
        </button>
      ) : (
        <div className="flex items-center gap-1.5 rounded-full border border-emerald-400/40 bg-emerald-950/80 px-2.5 py-1 text-xs font-bold text-emerald-200 shadow-md backdrop-blur">
          {/* Animated pulsing wave */}
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
          </span>

          <span className="text-[11px] font-semibold text-emerald-100">
            {peerConnected ? t.voiceActive : t.voiceConnecting}
          </span>

          <button
            type="button"
            onClick={toggleMute}
            className={`rounded-full px-2 py-0.5 text-[11px] transition ${
              muted ? "bg-rose-500 text-white" : "bg-white/20 text-white hover:bg-white/30"
            }`}
            title={muted ? t.voiceUnmute : t.voiceMute}
          >
            {muted ? "🔇" : "🎙️"}
          </button>

          <button
            type="button"
            onClick={cleanup}
            className="rounded-full bg-red-600/80 px-1.5 py-0.5 text-[10px] text-white hover:bg-red-600"
            title={t.voiceLeave}
          >
            ✕
          </button>
        </div>
      )}

      {errorMsg && (
        <span className="absolute -bottom-6 left-0 whitespace-nowrap rounded bg-rose-600 px-2 py-0.5 text-[10px] text-white shadow">
          {errorMsg}
        </span>
      )}
    </div>
  );
}
