import { pgTable, text, integer, jsonb, timestamp, index } from "drizzle-orm/pg-core";

// Online game rooms. `state` holds the full authoritative game state (JSON),
// `version` is used for optimistic-concurrency when players push moves.
export const rooms = pgTable(
  "rooms",
  {
    id: text("id").primaryKey(), // room code, e.g. "K7MP2A"
    game: text("game").notNull(), // "chess" | "checkers"
    hostName: text("host_name").notNull(),
    guestName: text("guest_name"),
    hostColor: text("host_color").notNull().default("w"), // chess: w|b — checkers: r|b
    state: jsonb("state").$type<Record<string, unknown>>().notNull(),
    version: integer("version").notNull().default(1),
    status: text("status").notNull().default("waiting"), // waiting | playing | finished
    signals: jsonb("signals").$type<Record<string, unknown>>(), // WebRTC voice signaling messages
    goalProposal: jsonb("goal_proposal").$type<{ from: string; points: number; status: "pending" | "accepted" | "declined" }>(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("rooms_created_at_idx").on(t.createdAt)],
);

export type Room = typeof rooms.$inferSelect;

// Google-authenticated users.
export const users = pgTable("users", {
  id: text("id").primaryKey(), // Google `sub`
  email: text("email").notNull(),
  name: text("name").notNull(),
  picture: text("picture"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }).notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
