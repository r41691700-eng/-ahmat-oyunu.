"use client";

import React, { useEffect } from "react";
import Link from "next/link";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("Application error:", error);
  }, [error]);

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-[#0b1020] px-4 text-center text-white">
      <div className="w-full max-w-sm rounded-3xl border border-white/20 bg-white/5 p-6 shadow-2xl backdrop-blur">
        <div className="text-4xl mb-3">🎲</div>
        <h2 className="text-lg font-black text-amber-400">İki Kafa Bir Tahta</h2>
        <p className="mt-2 text-xs text-slate-300">
          Oyun yüklenirken bir durum oluştu. Aşağıdaki butona basarak hemen oyuna devam edebilirsiniz:
        </p>
        <div className="mt-5 flex flex-col gap-2">
          <button
            type="button"
            onClick={() => reset()}
            className="w-full rounded-xl bg-amber-500 py-3 text-sm font-black text-slate-950 shadow hover:bg-amber-400 active:scale-95 transition"
          >
            Yeniden Dene ↻
          </button>
          <Link
            href="/"
            className="w-full rounded-xl bg-white/10 py-2.5 text-xs font-bold text-white hover:bg-white/20 transition"
          >
            Ana Sayfaya Dön →
          </Link>
        </div>
      </div>
    </main>
  );
}
