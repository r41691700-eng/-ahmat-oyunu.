"use client";

import React, { Suspense, useEffect, useState, useRef } from "react";
import Link from "next/link";
import { SafeClientBoundary } from "@/components/SafeClientBoundary";
import { SettingsModal } from "@/components/Header";
import {
  newBlockBlastGame,
  placeShape,
  canPlaceShape,
  generateShapeBatch,
  hasAnyPossibleMove,
  GRID_SIZE,
  type BlockBlastState,
} from "@/lib/blockBlast";
import {
  playBlockPlaceSound,
  playBlockClearSound,
  playBlockGameOverSound,
  playStartGameSound,
} from "@/lib/sounds";

export function BlockBlastInner() {
  const [state, setState] = useState<BlockBlastState>(() => newBlockBlastGame(0));
  const [selectedShapeIndex, setSelectedShapeIndex] = useState<number | null>(null);
  const [hoverCell, setHoverCell] = useState<{ r: number; c: number } | null>(null);
  const [scorePop, setScorePop] = useState<{ points: number; combo: number } | null>(null);
  const [refreshRerollUsed, setRefreshRerollUsed] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  // New placed cell keys to trigger thud impact animation
  const [justPlacedKeys, setJustPlacedKeys] = useState<Set<string>>(new Set());
  // Batch spawn trigger
  const [batchId, setBatchId] = useState(1);

  // Dragging state
  const [draggingShapeIndex, setDraggingShapeIndex] = useState<number | null>(null);
  const [dragPointerPos, setDragPointerPos] = useState<{ x: number; y: number } | null>(null);

  const boardRef = useRef<HTMLDivElement>(null);
  const prevGameOver = useRef(false);

  // Load High Score
  useEffect(() => {
    try {
      playStartGameSound();
      const savedHigh = Number(localStorage.getItem("pc_blockblast_high") || 0);
      if (savedHigh > 0) {
        setState((prev) => ({ ...prev, highScore: savedHigh }));
      }
    } catch {}
  }, []);

  // Save High Score on change
  useEffect(() => {
    if (state.highScore > 0) {
      try {
        localStorage.setItem("pc_blockblast_high", String(state.highScore));
      } catch {}
    }
  }, [state.highScore]);

  // Game over sound
  useEffect(() => {
    if (state.gameOver && !prevGameOver.current) {
      playBlockGameOverSound();
    }
    prevGameOver.current = state.gameOver;
  }, [state.gameOver]);

  // Clear justPlaced keys after animation
  useEffect(() => {
    if (justPlacedKeys.size === 0) return;
    const t = setTimeout(() => setJustPlacedKeys(new Set()), 260);
    return () => clearTimeout(t);
  }, [justPlacedKeys]);

  // Execute placement with tactile thud & pop
  const executePlace = (shapeIdx: number, r: number, c: number) => {
    const shape = state.availableShapes[shapeIdx];
    if (!shape) return;

    // Precalculate which cells are newly placed for tactile animation
    const placedSet = new Set<string>();
    for (let row = 0; row < shape.matrix.length; row++) {
      for (let col = 0; col < shape.matrix[0].length; col++) {
        if (shape.matrix[row][col] === 1) {
          placedSet.add(`${r + row}-${c + col}`);
        }
      }
    }

    const next = placeShape(state, shapeIdx, r, c);
    if (next) {
      setJustPlacedKeys(placedSet);
      playBlockPlaceSound();

      // Trigger batch re-spawn animation if all 3 shapes used
      if (next.availableShapes.every((s) => s !== null)) {
        setBatchId((b) => b + 1);
      }

      if (next.lastClearCount > 0) {
        playBlockClearSound(next.combo);
        setScorePop({ points: next.lastScoreGain, combo: next.combo });
        setTimeout(() => setScorePop(null), 1400);
      }
      setState(next);
      setSelectedShapeIndex(null);
      setHoverCell(null);
      setDraggingShapeIndex(null);
      setDragPointerPos(null);
    }
  };

  // Cell click for selected piece
  const handleCellClick = (r: number, c: number) => {
    if (selectedShapeIndex === null) return;
    const shape = state.availableShapes[selectedShapeIndex];
    if (!shape) return;

    if (canPlaceShape(state.grid, shape, r, c)) {
      executePlace(selectedShapeIndex, r, c);
      return;
    }

    const halfH = Math.floor(shape.matrix.length / 2);
    const halfW = Math.floor(shape.matrix[0].length / 2);
    const centeredR = r - halfH;
    const centeredC = c - halfW;
    if (canPlaceShape(state.grid, shape, centeredR, centeredC)) {
      executePlace(selectedShapeIndex, centeredR, centeredC);
      return;
    }

    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        const nr = r + dr;
        const nc = c + dc;
        if (canPlaceShape(state.grid, shape, nr, nc)) {
          executePlace(selectedShapeIndex, nr, nc);
          return;
        }
      }
    }
  };

  // Shape selection
  const handleShapeSelect = (idx: number) => {
    if (state.availableShapes[idx] === null) return;
    setSelectedShapeIndex((prev) => (prev === idx ? null : idx));
  };

  // Drag start (1:1 cell scale matching board, fingers offset by -50px so board is 100% visible)
  const handleShapePointerDown = (idx: number, e: React.PointerEvent) => {
    const shape = state.availableShapes[idx];
    if (!shape) return;
    e.preventDefault();
    setSelectedShapeIndex(idx);
    setDraggingShapeIndex(idx);
    setDragPointerPos({ x: e.clientX, y: e.clientY });

    const getTargetPlacement = (clientX: number, clientY: number) => {
      if (!boardRef.current) return null;
      const rect = boardRef.current.getBoundingClientRect();
      const cellSize = rect.width / GRID_SIZE;

      // Finger is slightly below the center of the piece so finger never blocks board view
      const pieceCenterY = clientY - 50;
      const pieceCenterX = clientX;

      const halfRows = shape.matrix.length / 2;
      const halfCols = shape.matrix[0].length / 2;

      const topLeftX = pieceCenterX - halfCols * cellSize;
      const topLeftY = pieceCenterY - halfRows * cellSize;

      const col = Math.round((topLeftX - rect.left) / cellSize);
      const row = Math.round((topLeftY - rect.top) / cellSize);

      if (row >= 0 && row + shape.matrix.length <= GRID_SIZE && col >= 0 && col + shape.matrix[0].length <= GRID_SIZE) {
        return { r: row, c: col };
      }
      return null;
    };

    const handlePointerMove = (moveEv: PointerEvent) => {
      setDragPointerPos({ x: moveEv.clientX, y: moveEv.clientY });
      const target = getTargetPlacement(moveEv.clientX, moveEv.clientY);
      setHoverCell(target);
    };

    const handlePointerUp = (upEv: PointerEvent) => {
      window.removeEventListener("pointermove", handlePointerMove);
      window.removeEventListener("pointerup", handlePointerUp);

      const target = getTargetPlacement(upEv.clientX, upEv.clientY);
      if (target) {
        executePlace(idx, target.r, target.c);
      }

      setDraggingShapeIndex(null);
      setDragPointerPos(null);
      setHoverCell(null);
    };

    window.addEventListener("pointermove", handlePointerMove, { passive: true });
    window.addEventListener("pointerup", handlePointerUp, { passive: true });
  };

  // Blokları Yenile (Reroll / Refresh - 1 Kez Kullanma Hakkı - Fotoğraf 1)
  const handleRerollShapes = () => {
    if (refreshRerollUsed || state.gameOver) return;
    playBlockPlaceSound();
    const newShapes = generateShapeBatch();
    const isGameOver = !hasAnyPossibleMove(state.grid, newShapes);

    setState((prev) => ({
      ...prev,
      availableShapes: newShapes,
      gameOver: isGameOver,
    }));
    setRefreshRerollUsed(true);
    setBatchId((b) => b + 1);
    setSelectedShapeIndex(null);
    setHoverCell(null);
  };

  const restartGame = () => {
    playStartGameSound();
    setState(newBlockBlastGame(state.highScore));
    setSelectedShapeIndex(null);
    setHoverCell(null);
    setRefreshRerollUsed(false);
    setBatchId((b) => b + 1);
  };

  const activeShape =
    selectedShapeIndex !== null ? state.availableShapes[selectedShapeIndex] : null;

  const isCellPreviewed = (r: number, c: number): boolean => {
    if (!activeShape || !hoverCell) return false;
    const shapeRows = activeShape.matrix.length;
    const shapeCols = activeShape.matrix[0].length;
    const relR = r - hoverCell.r;
    const relC = c - hoverCell.c;
    if (relR >= 0 && relR < shapeRows && relC >= 0 && relC < shapeCols) {
      return activeShape.matrix[relR][relC] === 1;
    }
    return false;
  };

  const isPlacementValid =
    activeShape && hoverCell
      ? canPlaceShape(state.grid, activeShape, hoverCell.r, hoverCell.c)
      : false;

  // Board pixel size for 1:1 drag sizing
  const cellSizePx = boardRef.current ? Math.round(boardRef.current.clientWidth / GRID_SIZE) - 6 : 42;

  return (
    <main className="relative flex h-screen max-h-screen flex-col items-center justify-between overflow-hidden bg-gradient-to-b from-[#1c2d52] via-[#142342] to-[#0e172e] px-4 py-3 text-white select-none">
      {/* ───── ÜST BAR (Fotoğraf 1) ───── */}
      <header className="relative z-20 flex w-full max-w-md items-center justify-between pt-1">
        {/* Sol Üst: Taç ve En Yüksek Skor (👑 20770) */}
        <div className="flex items-center gap-1.5 rounded-2xl bg-black/40 border border-white/10 px-3 py-1.5 shadow-md backdrop-blur">
          <span className="text-xl drop-shadow">👑</span>
          <span className="font-sans text-base font-black text-amber-400 tabular-nums drop-shadow">
            {state.highScore}
          </span>
        </div>

        {/* Ortada Skor (Fotoğraf 1'deki devasa beyaz "0") */}
        <div className="text-center">
          <div className="font-sans text-4xl sm:text-5xl font-black text-white tabular-nums drop-shadow-[0_2px_10px_rgba(0,0,0,0.6)]">
            {state.score}
          </div>
        </div>

        {/* Sağ Üst: Ayarlar Butonu (⚙️) */}
        <div className="flex items-center gap-2">
          <Link
            href="/"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/15 text-lg font-bold text-white hover:bg-white/25 active:scale-95 transition shadow"
            title="Ana Sayfa"
          >
            ‹
          </Link>
          <button
            type="button"
            onClick={() => setSettingsOpen(true)}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/15 text-lg font-bold text-white hover:bg-white/25 active:scale-95 transition shadow"
            title="Ayarlar"
          >
            ⚙️
          </button>
        </div>
      </header>

      {/* Combo ve Skor Patlaması */}
      {scorePop && (
        <div className="pointer-events-none absolute top-16 z-40 flex flex-col items-center animate-bounce">
          <span className="rounded-full bg-emerald-500 px-4 py-1 text-sm font-black text-slate-950 shadow-2xl ring-2 ring-emerald-300">
            +{scorePop.points} PUAN!
          </span>
          {scorePop.combo > 1 && (
            <span className="mt-1 text-xs font-black tracking-widest text-amber-300 drop-shadow">
              🔥 COMBO x{scorePop.combo}!
            </span>
          )}
        </div>
      )}

      {/* ───── 8x8 TAHTA (Fotoğraf 1: Koyu lacivert gövde, parlak kristal bloklar) ───── */}
      <div className="relative my-auto flex w-full max-w-[390px] flex-col items-center">
        <div
          ref={boardRef}
          className="grid aspect-square w-full gap-1.5 rounded-3xl border-4 border-[#243760] bg-[#111c35] p-2.5 shadow-[0_20px_45px_rgba(0,0,0,0.7)]"
          style={{
            gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))`,
            gridTemplateRows: `repeat(${GRID_SIZE}, minmax(0, 1fr))`,
            touchAction: "none",
          }}
        >
          {state.grid.map((row, r) =>
            row.map((cellColor, c) => {
              const preview = isCellPreviewed(r, c);
              const filled = cellColor !== null;
              const cellKey = `${r}-${c}`;
              const isThudding = justPlacedKeys.has(cellKey);
              const previewColor = isPlacementValid && activeShape ? activeShape.color : undefined;

              return (
                <div
                  key={cellKey}
                  onClick={() => handleCellClick(r, c)}
                  onMouseEnter={() => setHoverCell({ r, c })}
                  className={`relative flex items-center justify-center rounded-xl transition-all duration-100 ${
                    filled
                      ? `bb-block ${isThudding ? "bb-thud-anim" : ""}`
                      : preview
                      ? isPlacementValid
                        ? "bb-block ring-2 ring-white animate-pulse"
                        : "bb-block ring-2 ring-red-400 opacity-60"
                      : "bb-slot"
                  }`}
                  style={{
                    backgroundColor: filled
                      ? cellColor
                      : preview && isPlacementValid
                      ? previewColor
                      : preview
                      ? "#ef4444"
                      : undefined,
                  }}
                >
                  {(filled || preview) && <div className="bb-block-highlight" />}
                </div>
              );
            })
          )}
        </div>

        {/* Tahtanın Sağ Altında: Blokları Yenile Butonu 🔄 (Fotoğraf 1 - 1 Kez Kullanma Hakkı) */}
        <div className="w-full flex justify-end pr-2 pt-2">
          <button
            type="button"
            onClick={handleRerollShapes}
            disabled={refreshRerollUsed || state.gameOver}
            className={`flex h-11 w-11 items-center justify-center rounded-full border-2 shadow-2xl transition-all ${
              !refreshRerollUsed && !state.gameOver
                ? "border-sky-300 bg-gradient-to-tr from-sky-600 to-sky-400 text-white hover:scale-105 active:scale-95 animate-pulse"
                : "border-white/10 bg-white/5 text-white/30 cursor-not-allowed opacity-40"
            }`}
            title={refreshRerollUsed ? "Yenileme hakkı kullanıldı (1/1)" : "Blokları Yenile (1 Hak)"}
          >
            <span className="text-xl font-black">🔄</span>
          </button>
        </div>
      </div>

      {/* ───── ALTTAN 3 KULLANILABİLİR BLOK (Fotoğraf 1) ───── */}
      <div className="w-full max-w-md pb-4 pt-1">
        <div key={`batch-${batchId}`} className="bb-spawn-anim grid grid-cols-3 gap-3 px-2">
          {state.availableShapes.map((shape, idx) => {
            if (!shape) {
              return (
                <div
                  key={idx}
                  className="flex h-24 items-center justify-center rounded-2xl border border-dashed border-white/10 bg-white/5 opacity-25"
                />
              );
            }

            const isSelected = selectedShapeIndex === idx;

            return (
              <div
                key={shape.id}
                onPointerDown={(e) => handleShapePointerDown(idx, e)}
                onClick={() => handleShapeSelect(idx)}
                className={`relative flex h-24 cursor-grab items-center justify-center rounded-2xl border-2 p-2 transition-all duration-150 active:cursor-grabbing ${
                  isSelected
                    ? "scale-105 border-amber-400 bg-amber-400/20 ring-4 ring-amber-400/50 shadow-2xl"
                    : "border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10 shadow-md"
                }`}
              >
                {/* Minyatür 3D Blok Kristal Görünümü */}
                <div
                  className="grid gap-1"
                  style={{
                    gridTemplateRows: `repeat(${shape.matrix.length}, 18px)`,
                    gridTemplateColumns: `repeat(${shape.matrix[0].length}, 18px)`,
                  }}
                >
                  {shape.matrix.map((row, r) =>
                    row.map((val, c) => (
                      <div
                        key={`${r}-${c}`}
                        className={`rounded-md ${
                          val === 1 ? "bb-block" : "bg-transparent"
                        }`}
                        style={{
                          backgroundColor: val === 1 ? shape.color : "transparent",
                        }}
                      >
                        {val === 1 && <div className="bb-block-highlight" />}
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sürüklenen Blok (1:1 Boyut, Parmak -50px Offset) */}
      {draggingShapeIndex !== null && dragPointerPos && state.availableShapes[draggingShapeIndex] && (
        <div
          className="pointer-events-none fixed z-50 -translate-x-1/2 -translate-y-1/2 opacity-95 drop-shadow-[0_15px_30px_rgba(0,0,0,0.85)]"
          style={{
            left: `${dragPointerPos.x}px`,
            top: `${dragPointerPos.y - 50}px`,
          }}
        >
          {(() => {
            const sh = state.availableShapes[draggingShapeIndex]!;
            return (
              <div
                className="grid gap-1.5"
                style={{
                  gridTemplateRows: `repeat(${sh.matrix.length}, ${cellSizePx}px)`,
                  gridTemplateColumns: `repeat(${sh.matrix[0].length}, ${cellSizePx}px)`,
                }}
              >
                {sh.matrix.map((row, r) =>
                  row.map((val, c) => (
                    <div
                      key={`${r}-${c}`}
                      className={`rounded-xl ${val === 1 ? "bb-block" : "bg-transparent"}`}
                      style={{
                        backgroundColor: val === 1 ? sh.color : "transparent",
                      }}
                    >
                      {val === 1 && <div className="bb-block-highlight" />}
                    </div>
                  ))
                )}
              </div>
            );
          })()}
        </div>
      )}

      {/* ───── FOTOĞRAF 2: BEST SCORE! OYUN BİTİŞ EKRANI ───── */}
      {state.gameOver && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-b from-[#7c3aed] via-[#6d28d9] to-[#5b21b6] p-6 text-center select-none overflow-hidden">
          {/* Konfeti Parçacıkları (Fotoğraf 2) */}
          <div className="pointer-events-none absolute inset-0 overflow-hidden">
            <span className="absolute left-[15%] top-[12%] text-lg text-amber-300 animate-bounce">■</span>
            <span className="absolute right-[20%] top-[18%] text-sm text-cyan-300 animate-ping">▲</span>
            <span className="absolute left-[25%] top-[45%] text-base text-rose-400 animate-pulse">●</span>
            <span className="absolute right-[15%] top-[60%] text-sm text-yellow-300 animate-bounce">■</span>
            <span className="absolute left-[30%] top-[70%] text-base text-emerald-300 animate-pulse">◆</span>
            <span className="absolute right-[30%] top-[35%] text-lg text-pink-400 animate-bounce">★</span>
          </div>

          <div className="relative z-10 flex flex-col items-center">
            {/* Altın Taç 👑 (Fotoğraf 2) */}
            <div className="text-7xl mb-2 drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)] animate-bounce">
              👑
            </div>

            {/* Best Score! Altın Sarısı Parlak Başlık (Fotoğraf 2) */}
            <h1 className="font-sans text-5xl sm:text-6xl font-black tracking-tight text-[#facc15] drop-shadow-[0_4px_8px_rgba(0,0,0,0.4)]">
              Best Score!
            </h1>

            {/* Küçük Soluk "Score" Yazısı (Fotoğraf 2) */}
            <div className="mt-6 text-sm font-bold uppercase tracking-widest text-purple-200/80">
              Score
            </div>

            {/* Devasa Beyaz Kalın Skor (Fotoğraf 2: "608262") */}
            <div className="mt-1 font-sans text-6xl sm:text-7xl font-black text-white tabular-nums drop-shadow-[0_4px_10px_rgba(0,0,0,0.6)]">
              {state.score}
            </div>

            {/* Altın Sarısı Parlak Play Butonu ▶ (Fotoğraf 2) */}
            <button
              type="button"
              onClick={restartGame}
              className="mt-10 flex h-16 w-52 items-center justify-center rounded-2xl border-2 border-amber-300 bg-gradient-to-b from-[#facc15] to-[#eab308] shadow-[0_8px_20px_rgba(0,0,0,0.4)] transition hover:scale-105 active:scale-95"
              aria-label="Tekrar Oyna"
            >
              <span className="text-3xl text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)]">▶</span>
            </button>

            <Link
              href="/"
              className="mt-6 text-xs font-bold text-purple-200/90 underline hover:text-white transition"
            >
              ← Ana Sayfaya Dön
            </Link>
          </div>
        </div>
      )}

      {settingsOpen && <SettingsModal onClose={() => setSettingsOpen(false)} />}
    </main>
  );
}

export default function BlockBlastPage() {
  return (
    <SafeClientBoundary fallbackTitle="Block Blast">
      <Suspense
        fallback={
          <main className="flex min-h-screen items-center justify-center bg-[#142342] text-white">
            <div className="text-sm font-bold">Block Blast Yükleniyor…</div>
          </main>
        }
      >
        <BlockBlastInner />
      </Suspense>
    </SafeClientBoundary>
  );
}
