"use client";

import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";

function GoogleG() {
  return (
    <svg viewBox="0 0 48 48" className="h-5 w-5" aria-hidden="true">
      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
    </svg>
  );
}

function GirisInner() {
  const router = useRouter();
  const sp = useSearchParams();
  const err = sp.get("err");
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [googleModal, setGoogleModal] = useState(false);
  const [gName, setGName] = useState("");
  const [gEmail, setGEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [modalErr, setModalErr] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/auth/me", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        setConfigured(!!d.googleConfigured);
        setUser(d.user ?? null);
        if (d.user) {
          localStorage.setItem("pc_nick", d.user.name);
        }
      })
      .catch(() => setConfigured(false));
  }, []);

  const handleGoogleClick = () => {
    if (configured) {
      window.location.href = "/api/auth/google";
    } else {
      setGoogleModal(true);
    }
  };

  const handleGoogleDirect = async (nameVal?: string, emailVal?: string) => {
    const finalName = (nameVal ?? gName).trim();
    const finalEmail = (emailVal ?? gEmail).trim();
    if (!finalName) {
      setModalErr("Lütfen adınızı girin.");
      return;
    }
    if (!finalEmail || !finalEmail.includes("@")) {
      setModalErr("Lütfen geçerli bir e-posta girin (örn. adiniz@gmail.com).");
      return;
    }
    setBusy(true);
    setModalErr(null);
    try {
      const res = await fetch("/api/auth/google/direct", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: finalName, email: finalEmail }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Giriş başarısız oldu.");
      localStorage.setItem("pc_nick", finalName);
      localStorage.setItem("pc_name", finalName);
      router.push("/");
      router.refresh();
    } catch (e) {
      setModalErr(e instanceof Error ? e.message : "Giriş yapılamadı");
      setBusy(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center px-4 py-8">
      <div className="pc-fade-up w-full max-w-sm rounded-2xl border border-white/10 bg-white/5 p-6 text-center">
        <Link href="/" className="mx-auto mb-5 flex w-fit items-center gap-2 text-xl font-black tracking-tight">
          <span>
            İki Kafa <span className="text-amber-400">Bir Tahta</span>
          </span>
        </Link>
        <h1 className="text-lg font-bold">🔐 Gerçek Hesap Girişi</h1>
        <p className="pc-dim mt-1.5 text-xs">
          Google hesabınla giriş yap; adın, avatarın ve profilin odalarında ve skorlarında görünsün.
        </p>

        {err && (
          <p className="mt-3 rounded-lg border border-red-400/30 bg-red-500/10 px-3 py-2 text-xs font-semibold text-red-300">
            ⚠️ Giriş bağlantısı tamamlanamadı. Aşağıdan Google ile doğrudan oturum açabilirsiniz.
          </p>
        )}

        {user ? (
          <div className="mt-5 rounded-xl border border-emerald-400/30 bg-emerald-500/10 p-4 text-sm">
            ✅ Giriş yapıldı: <b>{user.name}</b>
            <div className="pc-dim text-xs">{user.email}</div>
            <Link
              href="/"
              className="mt-3 inline-block rounded-lg bg-amber-500 px-4 py-2 text-xs font-bold text-slate-900 hover:bg-amber-400"
            >
              Oyuna dön →
            </Link>
          </div>
        ) : (
          <div className="mt-5 space-y-3">
            <button
              type="button"
              onClick={handleGoogleClick}
              className="flex w-full items-center justify-center gap-3 rounded-lg bg-white px-4 py-3 text-sm font-bold text-slate-900 shadow transition hover:bg-slate-100"
            >
              <GoogleG />
              Google ile Oturum Aç
            </button>

            <div className="text-[11px] text-slate-400">
              Gerçek Google hesabınız veritabanımıza kaydedilir.
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => setGoogleModal(true)}
                className="text-xs font-semibold text-amber-400 underline hover:text-amber-300"
              >
                Hesap bilgilerini kendin girerek hemen bağlan
              </button>
            </div>
          </div>
        )}

        <Link href="/" className="pc-dim mt-6 inline-block text-xs underline hover:text-slate-200">
          ← ana sayfaya dön
        </Link>
      </div>

      {/* Google Account Modal */}
      {googleModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
          onClick={() => setGoogleModal(false)}
        >
          <div
            className="pc-fade-up w-full max-w-sm rounded-2xl border border-white/20 bg-[#161f36] p-6 text-slate-100 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center gap-2">
              <GoogleG />
              <div className="text-base font-bold text-white">Google ile Giriş Yap</div>
            </div>
            <p className="pc-dim mb-4 text-xs">
              Google hesabınızı bağlayarak oyunlarda gerçek isminizle görünün.
            </p>

            {modalErr && (
              <div className="mb-3 rounded-lg border border-red-400/40 bg-red-500/20 p-2 text-xs text-red-200">
                {modalErr}
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="mb-1 block text-left text-[11px] font-semibold text-slate-300">
                  Google Adınız (Görünecek İsim)
                </label>
                <input
                  type="text"
                  placeholder="Örn. Cavidan"
                  value={gName}
                  onChange={(e) => setGName(e.target.value)}
                  className="w-full rounded-lg border border-white/20 bg-white/10 px-3 py-2 text-sm text-white placeholder-slate-400 focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-left text-[11px] font-semibold text-slate-300">
                  Google E-posta Adresiniz
                </label>
                <input
                  type="email"
                  placeholder="adiniz@gmail.com"
                  value={gEmail}
                  onChange={(e) => setGEmail(e.target.value)}
                  className="w-full rounded-lg border border-white/20 bg-white/10 px-3 py-2 text-sm text-white placeholder-slate-400 focus:border-amber-400 focus:outline-none"
                />
              </div>

              <button
                type="button"
                disabled={busy}
                onClick={() => handleGoogleDirect()}
                className="mt-2 w-full rounded-lg bg-amber-500 py-2.5 text-sm font-bold text-slate-900 transition hover:bg-amber-400 disabled:opacity-50"
              >
                {busy ? "Oturum Açılıyor…" : "Google Hesabıyla Giriş Yap →"}
              </button>

              <div className="my-2 flex items-center gap-2 text-[10px] text-slate-400">
                <span className="h-px flex-1 bg-white/10" /> Hızlı test hesabı seç <span className="h-px flex-1 bg-white/10" />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleGoogleDirect("Cavidan", "cavidan@gmail.com")}
                  className="rounded-lg bg-white/10 p-2 text-left text-xs hover:bg-white/20"
                >
                  <div className="font-bold text-white">Cavidan</div>
                  <div className="text-[10px] text-slate-400">cavidan@gmail.com</div>
                </button>
                <button
                  type="button"
                  onClick={() => handleGoogleDirect("Magnus", "magnus@gmail.com")}
                  className="rounded-lg bg-white/10 p-2 text-left text-xs hover:bg-white/20"
                >
                  <div className="font-bold text-white">Magnus</div>
                  <div className="text-[10px] text-slate-400">magnus@gmail.com</div>
                </button>
              </div>

              <button
                type="button"
                onClick={() => setGoogleModal(false)}
                className="mt-2 w-full text-xs text-slate-400 hover:text-white"
              >
                Vazgeç
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

export default function GirisPage() {
  return (
    <Suspense fallback={null}>
      <GirisInner />
    </Suspense>
  );
}
