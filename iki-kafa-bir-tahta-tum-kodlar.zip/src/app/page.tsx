"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Header } from "@/components/Header";
import { chessInitialState } from "@/lib/chessState";
import { checkersInitialState } from "@/lib/checkers";
import { useI18n } from "@/lib/i18n";

type Game = "chess" | "checkers" | "blockblast" | "uno";
type ColorChoice = "a" | "rnd" | "b"; // a = beyaz, rnd, b = siyah

const DIFFS = [
  { id: "kolay", name: "kolay" },
  { id: "orta", name: "orta" },
  { id: "zor", name: "zor" },
] as const;

export default function Home() {
  const router = useRouter();
  const { t } = useI18n();
  const [game, setGame] = useState<Game>("chess");
  const [color, setColor] = useState<ColorChoice>("rnd");
  const [unoPlayers, setUnoPlayers] = useState<2 | 3 | 4>(2);
  const [nick, setNick] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState<"create" | "join" | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      setNick(localStorage.getItem("pc_nick") || "");
    } catch {}
  }, []);

  const pickColor = (): "w" | "b" => {
    const p = color === "rnd" ? (Math.random() < 0.5 ? "a" : "b") : color;
    return p === "a" ? "w" : "b";
  };

  const startLocal = (mode: "bot" | "2p", d?: string) => {
    if (game === "blockblast") {
      router.push("/blockblast");
      return;
    }
    if (game === "uno") {
      router.push(`/uno?players=${unoPlayers}`);
      return;
    }
    const q = new URLSearchParams({ g: game, mode, c: pickColor() });
    if (d) q.set("d", d);
    router.push(`/oyun?${q.toString()}`);
  };

  const createRoom = async () => {
    setError(null);
    setBusy("create");
    const hostName = nick.trim() || "Oyuncu";
    try {
      if (nick.trim()) localStorage.setItem("pc_nick", nick.trim());
    } catch {}
    const myColor = pickColor();

    if (game === "uno") {
      try {
        const res = await fetch("/api/rooms", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            game: "uno",
            hostName,
            color: "w",
            initialState: { status: "waiting", players: unoPlayers },
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Oda oluşturulamadı");
        router.push(`/uno?players=${unoPlayers}&code=${data.code}&mode=online`);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Oda oluşturulamadı");
        setBusy(null);
      }
      return;
    }

    try {
      const res = await fetch("/api/rooms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          game,
          hostName,
          color: myColor,
          initialState: game === "chess" ? chessInitialState("waiting") : checkersInitialState("waiting"),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Oda oluşturulamadı");
      router.push(`/oyun?g=${game}&mode=online&code=${data.code}&c=${myColor}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Oda oluşturulamadı");
      setBusy(null);
    }
  };

  const joinRoom = async () => {
    setError(null);
    setBusy("join");
    const guestName = nick.trim() || "Misafir";
    try {
      if (nick.trim()) localStorage.setItem("pc_nick", nick.trim());
    } catch {}
    try {
      const res = await fetch("/api/rooms/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code.trim(), guestName }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Oda bulunamadı veya dolu");
      if (data.game === "uno") {
        router.push(`/uno?code=${data.code}&mode=online`);
      } else {
        router.push(`/oyun?g=${data.game}&mode=online&code=${data.code}&c=${data.guestColor}`);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Oda bulunamadı");
      setBusy(null);
    }
  };

  const colorBtn = (id: ColorChoice, icon: string, title: string) => (
    <button
      key={id}
      type="button"
      onClick={() => setColor(id)}
      className={`h-9 w-9 rounded-lg border text-base transition ${
        color === id ? "border-amber-400 bg-amber-500/25" : "border-white/10 bg-white/5 hover:bg-white/10"
      }`}
      title={title}
      aria-label={title}
    >
      {icon}
    </button>
  );

  return (
    <main className="min-h-screen overflow-x-hidden px-4 py-5 text-slate-100">
      <div className="mx-auto w-full max-w-[760px]">
        <Header />

        <section className="mb-8 text-center">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
            {t.heroTitle} <span className="text-amber-400">{t.heroTitleHighlight}</span>
          </h1>
          <p className="mx-auto mt-3 max-w-md text-sm text-slate-300">
            {t.subtitle}
          </p>
        </section>

        {/* Oyun Seçim Kartları */}
        <div className="mb-5 grid gap-3">
          {/* Satranç & Şaşki */}
          <div className="grid gap-3 sm:grid-cols-2">
            <button
              type="button"
              onClick={() => setGame("chess")}
              className={`flex items-center gap-3 rounded-2xl border p-4 text-left transition ${
                game === "chess" ? "border-amber-400 bg-amber-500/20" : "border-white/10 bg-white/5 hover:bg-white/10"
              }`}
            >
              <span className="text-3xl">♞</span>
              <div>
                <div className="font-bold">{t.chess}</div>
                <div className="text-xs text-slate-400">{t.chessDesc}</div>
              </div>
              {game === "chess" && (
                <span className="ml-auto text-emerald-300" aria-hidden="true">
                  ✓
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setGame("checkers")}
              className={`flex items-center gap-3 rounded-2xl border p-4 text-left transition ${
                game === "checkers" ? "border-amber-400 bg-amber-500/20" : "border-white/10 bg-white/5 hover:bg-white/10"
              }`}
            >
              <span className="text-3xl">🔴</span>
              <div>
                <div className="font-bold">{t.checkers}</div>
                <div className="text-xs text-slate-400">{t.checkersDesc}</div>
              </div>
              {game === "checkers" && (
                <span className="ml-auto text-emerald-300" aria-hidden="true">
                  ✓
                </span>
              )}
            </button>
          </div>

          {/* Block Blast (Fotoğraf 1 & 2'deki popüler 8x8 blok bulmacası) */}
          <button
            type="button"
            onClick={() => setGame("blockblast")}
            className={`flex items-center gap-3 rounded-2xl border p-4 text-left transition ${
              game === "blockblast" ? "border-blue-500 bg-blue-500/20" : "border-white/10 bg-white/5 hover:bg-white/10"
            }`}
          >
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-blue-500 to-cyan-400 shadow-md">
              <span className="text-xl">🧊</span>
            </div>
            <div>
              <div className="font-bold flex items-center gap-2">
                <span>{t.blockBlast}</span>
                <span className="rounded bg-blue-500/30 px-1.5 py-0.2 text-[10px] font-black text-blue-300">
                  POPÜLER
                </span>
              </div>
              <div className="text-xs text-slate-400">{t.blockBlastDesc}</div>
            </div>
            {game === "blockblast" && (
              <span className="ml-auto text-emerald-300" aria-hidden="true">
                ✓
              </span>
            )}
          </button>

          {/* Block Blast'ın hemen altında UNO */}
          <button
            type="button"
            onClick={() => setGame("uno")}
            className={`flex items-center gap-3 rounded-2xl border p-4 text-left transition ${
              game === "uno" ? "border-red-500 bg-red-500/20" : "border-white/10 bg-white/5 hover:bg-white/10"
            }`}
          >
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 via-amber-400 to-blue-500 shadow-md">
              <span className="font-black italic text-neutral-950 text-sm">UNO</span>
            </div>
            <div>
              <div className="font-bold flex items-center gap-2">
                <span>{t.uno}</span>
                <span className="rounded bg-red-500/30 px-1.5 py-0.2 text-[10px] font-black text-red-300">
                  YENİ
                </span>
              </div>
              <div className="text-xs text-slate-400">{t.unoDesc}</div>
            </div>
            {game === "uno" && (
              <span className="ml-auto text-emerald-300" aria-hidden="true">
                ✓
              </span>
            )}
          </button>
        </div>

        {/* SADECE UNO'YA BASINCA ALTTA ÇIKAN OYUNCU SAYISI SEÇİMİ (2, 3, 4 Kişilik) */}
        {game === "uno" && (
          <div className="mb-5 rounded-2xl border border-red-500/40 bg-red-500/10 p-4 animate-in fade-in slide-in-from-top-2 duration-300">
            <div className="mb-2.5 flex items-center justify-between">
              <span className="text-xs font-bold text-red-300 uppercase tracking-wider">
                {t.unoPlayers}
              </span>
              <span className="text-xs text-slate-300 font-semibold">
                {t.playersCount.replace("{n}", String(unoPlayers))}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2.5">
              {[2, 3, 4].map((count) => (
                <button
                  key={count}
                  type="button"
                  onClick={() => setUnoPlayers(count as 2 | 3 | 4)}
                  className={`flex items-center justify-center gap-2 rounded-xl border py-2.5 text-sm font-black transition ${
                    unoPlayers === count
                      ? "border-red-500 bg-red-600 text-white shadow-lg ring-2 ring-red-400/50 scale-102"
                      : "border-white/10 bg-white/5 text-slate-200 hover:bg-white/10"
                  }`}
                >
                  <span>👥</span>
                  <span>{count} Kişilik</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Renk Seçimi (Satranç & Şaşki için) */}
        {(game === "chess" || game === "checkers") && (
          <div className="mb-5 flex items-center justify-center gap-2">
            <span className="text-xs text-slate-400">{t.color}:</span>
            {colorBtn("a", "⚪", t.white)}
            {colorBtn("rnd", "🎲", t.random)}
            {colorBtn("b", "⚫", t.black)}
          </div>
        )}

        {/* Bota Karşı / Tek Oyunculu Başlatma Bölümü */}
        <section className="mb-5 rounded-2xl border border-violet-400/30 bg-violet-500/10 p-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-bold">
              {game === "blockblast" ? "🧊 Block Blast Oyna" : `🤖 ${t.vsBot}`}{" "}
              <span className="ml-1 rounded bg-violet-400/20 px-2 py-0.5 text-[10px] font-semibold text-violet-200">
                📴 {t.offline}
              </span>
            </h2>
            {game !== "blockblast" && game !== "uno" && (
              <button
                type="button"
                onClick={() => startLocal("2p")}
                className="rounded-lg bg-white/10 px-3 py-1.5 text-xs font-semibold hover:bg-white/20"
              >
                👥 {t.twoPlayers}
              </button>
            )}
          </div>

          {game === "blockblast" ? (
            <div>
              <button
                type="button"
                onClick={() => startLocal("bot")}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-500 to-cyan-500 py-3.5 text-sm font-black text-white shadow-lg hover:brightness-110 active:scale-98 transition"
              >
                <span>🧊</span>
                <span>Block Blast Başlat (8×8 Bulmaca) →</span>
              </button>
            </div>
          ) : game === "uno" ? (
            <div>
              <button
                type="button"
                onClick={() => startLocal("bot")}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-red-600 via-amber-500 to-blue-600 py-3 text-sm font-black text-white shadow-lg hover:brightness-110 active:scale-98 transition"
              >
                <span>🎴</span>
                <span>{unoPlayers} Kişilik UNO Başlat (Botlara Karşı) →</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-2">
              {DIFFS.map((d) => (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => startLocal("bot", d.id)}
                  className="group rounded-xl border border-white/10 bg-white/5 p-3 text-center transition hover:border-violet-400/50 hover:bg-violet-500/20"
                >
                  <div className="text-sm font-bold">
                    {d.id === "kolay" ? `😊 ${t.easy}` : d.id === "orta" ? `🙂 ${t.medium}` : `😤 ${t.hard}`}
                  </div>
                  <div className="mt-2 inline-block rounded bg-violet-500 px-3 py-1 text-[11px] font-bold text-white opacity-90 group-hover:opacity-100">
                    {t.play}
                  </div>
                </button>
              ))}
            </div>
          )}
        </section>

        {/* Arkadaşınla Oyna (Oda) */}
        {game !== "blockblast" && (
          <section className="mb-5 rounded-2xl border border-sky-400/25 bg-sky-500/5 p-5">
            <h2 className="mb-4 text-lg font-bold">
              🌐 {t.playWithFriend}{" "}
              <span className="ml-1 rounded bg-sky-400/20 px-2 py-0.5 text-[10px] font-semibold text-sky-200">
                {t.onlineWifi}
              </span>
            </h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-300">{t.yourNick}</label>
                <input
                  type="text"
                  value={nick}
                  onChange={(e) => setNick(e.target.value)}
                  placeholder="Örn. Magnus"
                  maxLength={40}
                  className="mb-3 w-full rounded-lg border border-white/20 bg-white/10 px-3 py-2.5 text-sm text-white placeholder-slate-400 focus:border-amber-400 focus:outline-none disabled:opacity-60"
                />
                <button
                  type="button"
                  onClick={createRoom}
                  disabled={busy !== null}
                  className="w-full rounded-lg bg-amber-500 px-4 py-2.5 text-sm font-bold text-slate-900 transition hover:bg-amber-400 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {busy === "create" ? "Oluşturuluyor…" : t.createRoom}
                </button>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-slate-300">{t.joinWithCode}</label>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="ABCDEF"
                  maxLength={10}
                  className="mb-3 w-full rounded-lg border border-white/20 bg-white/10 px-3 py-2.5 text-center font-mono text-lg tracking-widest text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={joinRoom}
                  disabled={busy !== null || code.trim().length < 4}
                  className="w-full rounded-lg bg-emerald-500 px-4 py-2.5 text-sm font-bold text-slate-900 transition hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {busy === "join" ? "Bağlanıyor…" : t.join}
                </button>
              </div>
            </div>
            {error && (
              <p className="mt-3 rounded-lg border border-red-400/30 bg-red-500/10 px-3 py-2 text-xs font-semibold text-red-300">
                ⚠️ {error}
              </p>
            )}
          </section>
        )}

        <footer className="pb-8 pt-2 text-center text-[11px] text-slate-500">
          {t.appName} — {t.footerInfo} ·{" "}
          <a href="/online-satranc.zip" download="" className="underline hover:text-slate-300">
            💾 {t.sourceCode}
          </a>
        </footer>
      </div>
    </main>
  );
}
