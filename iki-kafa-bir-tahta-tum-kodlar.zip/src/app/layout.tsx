import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { AppShell } from "@/components/AppShell";

export const metadata: Metadata = {
  title: "İki Kafa Bir Tahta — Satranç, Şaşki, Domino & UNO",
  description:
    "İki Kafa Bir Tahta — satranç, Azerbaycan şaşkisi, domino ve UNO'yu arkadaşınla sesli konuşarak veya bota karşı oyna.",
  applicationName: "İki Kafa Bir Tahta",
};

export const viewport: Viewport = {
  themeColor: "#0b1020",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="tr" suppressHydrationWarning>
      <body className="text-slate-100 antialiased">
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
