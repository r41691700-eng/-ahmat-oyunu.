"use client";

import React, { Suspense, useEffect, useState, useRef, useCallback } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { UnoCardView } from "@/components/UnoCardView";
import { VoiceChat } from "@/components/VoiceChat";
import {
  playUnoCardDealSound,
  playUnoCardPlaySound,
  playUnoSpecialCardSound,
  playVictorySound,
  playDefeatSound,
  playStartGameSound,
} from "@/lib/sounds";
import {
  newUnoGame,
  canPlayCard,
  getPlayableCards,
  playUnoCard,
  drawUnoCard,
  passUnoTurn,
  declareUno,
  botChooseUnoMove,
  type UnoState,
  type UnoCard,
  type UnoColor,
} from "@/lib/uno";
import { useI18n } from "@/lib/i18n";

type AnimSpeed = "fast" | "normal" | "slow" | "ultraSlow";

const SPEED_CONFIG: Record<AnimSpeed, { ms: number; botDelay: number; label: string; icon: string }> = {
  fast: { ms: 180, botDelay: 450, label: "Hızlı", icon: "⚡" },
  normal: { ms: 320, botDelay: 850, label: "Normal", icon: "🏃" },
  slow: { ms: 550, botDelay: 1400, label: "Yavaş", icon: "🐢" },
  ultraSlow: { ms: 950, botDelay: 2200, label: "Ultra Yavaş", icon: "🦥" },
};

function UnoInner() {
  const sp = useSearchParams();
  const { t } = useI18n();

  const playersParam = Number(sp ? sp.get("players") : 2);
  const playerCount: 2 | 3 | 4 = [2, 3, 4].includes(playersParam) ? (playersParam as 2 | 3 | 4) : 2;

  const roomCode = sp ? sp.get("code")?.toUpperCase() || null : null;
  const isOnline = sp ? sp.get("mode") === "online" && !!roomCode : false;

  const [state, setState] = useState<UnoState>(() => newUnoGame(playerCount));
  const [selectedWildCard, setSelectedWildCard] = useState<UnoCard | null>(null);
  const [unoShoutAnim, setUnoShoutAnim] = useState<string | null>(null);

  // Animasyon hızı kontrolü (Hızlı / Normal / Yavaş / Ultra Yavaş)
  const [speed, setSpeed] = useState<AnimSpeed>("normal");
  const [isDrawingAnim, setIsDrawingAnim] = useState(false);
  const [recentlyDrawnCardId, setRecentlyDrawnCardId] = useState<string | null>(null);

  // Fiziksel kart ortaya atılma animasyonu (Kart elden süzülerek ortaya gidiyor)
  const [physicalThrow, setPhysicalThrow] = useState<{
    card: UnoCard;
    fromPlayer: number;
  } | null>(null);

  // Penalty / Draw animation from center deck to specific opponent (e.g. +2 / +4)
  const [penaltyFly, setPenaltyFly] = useState<{ targetPlayer: number; count: number } | null>(null);

  // Online multiplayer state
  const [roomVersion, setRoomVersion] = useState<number>(1);
  const roomVersionRef = useRef(1);
  const [guestConnected, setGuestConnected] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const stateRef = useRef(state);
  stateRef.current = state;
  const prevStatus = useRef(state.status);

  const topCard = state.discardPile[state.discardPile.length - 1];
  const isMyTurn = state.status === "playing" && state.currentTurn === 0;
  const myHand = state.hands[0];
  const myPlayables = isMyTurn ? getPlayableCards(myHand, topCard, state.currentColor) : [];

  // 1 Kartı Kalan Rakiplerin Tespiti (Kullanıcı İsteği: "rakibin 1 kartı kalınca bana mesaj gelsin")
  const opponentsWithOneCard = state.hands
    .map((h, idx) => ({ playerIndex: idx, name: state.playerNames[idx], count: h.length }))
    .filter((p) => p.playerIndex !== 0 && p.count === 1);

  // LocalStorage'dan animasyon hızını oku & oyun başlama sesi
  useEffect(() => {
    playStartGameSound();
    try {
      const savedSpeed = localStorage.getItem("pc_uno_anim_speed") as AnimSpeed;
      if (savedSpeed && SPEED_CONFIG[savedSpeed]) {
        setSpeed(savedSpeed);
      }
    } catch {}
  }, []);

  const changeSpeed = (newSpeed: AnimSpeed) => {
    setSpeed(newSpeed);
    try {
      localStorage.setItem("pc_uno_anim_speed", newSpeed);
    } catch {}
  };

  // State senkronizasyonu (Online modda odaya push)
  const commitState = useCallback(
    (nextState: UnoState) => {
      stateRef.current = nextState;
      setState(nextState);

      if (isOnline && roomCode) {
        fetch(`/api/rooms/${roomCode}/move`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            expectedVersion: roomVersionRef.current,
            state: nextState,
            status: nextState.status === "finished" ? "finished" : "playing",
          }),
        })
          .then((r) => r.json())
          .then((d) => {
            if (d.version) {
              roomVersionRef.current = d.version;
              setRoomVersion(d.version);
            }
          })
          .catch(() => {});
      }
    },
    [isOnline, roomCode]
  );

  // Online polling
  useEffect(() => {
    if (!isOnline || !roomCode) return;

    fetch(`/api/rooms/${roomCode}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.room?.state) {
          const s = data.room.state as UnoState;
          stateRef.current = s;
          setState(s);
          roomVersionRef.current = data.room.version || 1;
          setRoomVersion(data.room.version || 1);
          if (data.room.status === "playing") setGuestConnected(true);
        }
      })
      .catch(() => {});

    const interval = setInterval(() => {
      fetch(`/api/rooms/${roomCode}`, { cache: "no-store" })
        .then((r) => r.json())
        .then((data) => {
          if (data.room?.version && data.room.version > roomVersionRef.current && data.room.state) {
            const s = data.room.state as UnoState;
            stateRef.current = s;
            setState(s);
            roomVersionRef.current = data.room.version;
            setRoomVersion(data.room.version);
          }
          if (data.room?.status === "playing") setGuestConnected(true);
        })
        .catch(() => {});
    }, 1200);

    return () => clearInterval(interval);
  }, [isOnline, roomCode]);

  // Oyun sonu sesleri
  useEffect(() => {
    if (state.status === "finished" && prevStatus.current !== "finished") {
      if (state.matchWinner === 0) {
        playVictorySound();
      } else {
        playDefeatSound();
      }
    }
    prevStatus.current = state.status;
  }, [state.status, state.matchWinner]);

  // Bot hamleleri (offline modda)
  useEffect(() => {
    if (isOnline || state.status !== "playing") return;
    if (state.currentTurn === 0) return; // Oyuncunun sırası

    const botIdx = state.currentTurn;
    const currentSpeed = SPEED_CONFIG[speed];
    const botThinkTime = currentSpeed.botDelay + Math.random() * 200;

    const timer = setTimeout(() => {
      const cur = stateRef.current;
      if (cur.status !== "playing" || cur.currentTurn !== botIdx) return;

      const choice = botChooseUnoMove(cur, botIdx);
      if (choice.action === "play") {
        const playedCard = cur.hands[botIdx]?.find((c) => c.id === choice.cardId);
        if (!playedCard) return;

        // Fiziksel Kart Ortaya Atılma Animasyonu
        setPhysicalThrow({ card: playedCard, fromPlayer: botIdx });

        const isSpecial =
          playedCard.value === "draw2" ||
          playedCard.value === "wild4" ||
          playedCard.value === "skip" ||
          playedCard.value === "reverse";

        if (isSpecial) {
          playUnoSpecialCardSound();
        } else {
          playUnoCardPlaySound();
        }

        if (playedCard.value === "draw2" || playedCard.value === "wild4") {
          const penaltyCount = playedCard.value === "draw2" ? 2 : 4;
          const targetP = (botIdx + cur.direction * 1 + cur.playerCount) % cur.playerCount;
          setPenaltyFly({ targetPlayer: targetP, count: penaltyCount });
          setTimeout(() => setPenaltyFly(null), currentSpeed.ms * 1.5);
        }

        setTimeout(() => {
          setPhysicalThrow(null);
          const next = playUnoCard(cur, botIdx, choice.cardId, choice.chosenColor);
          commitState(next);
        }, currentSpeed.ms);
      } else if (choice.action === "draw") {
        playUnoCardDealSound();
        const next = drawUnoCard(cur, botIdx);
        commitState(next);
      } else {
        const next = passUnoTurn(cur, botIdx);
        commitState(next);
      }
    }, botThinkTime);

    return () => clearTimeout(timer);
  }, [state.currentTurn, state.status, state.hasDrawnThisTurn, speed, isOnline, commitState]);

  // Oyuncunun Kart Oynaması (Fiziksel süzülerek ortaya konma)
  const handleCardClick = (card: UnoCard) => {
    if (!isMyTurn || physicalThrow) return;
    if (!canPlayCard(card, topCard, state.currentColor)) return;

    if (card.color === "wild") {
      setSelectedWildCard(card);
    } else {
      executePlayWithPhysics(card);
    }
  };

  const executePlayWithPhysics = (card: UnoCard, chosenColor?: UnoColor) => {
    const currentSpeed = SPEED_CONFIG[speed];
    setPhysicalThrow({ card, fromPlayer: 0 });

    if (card.value === "draw2" || card.value === "skip" || card.value === "reverse") {
      playUnoSpecialCardSound();
    } else {
      playUnoCardPlaySound();
    }

    if (card.value === "draw2") {
      const targetP = (0 + state.direction * 1 + state.playerCount) % state.playerCount;
      setPenaltyFly({ targetPlayer: targetP, count: 2 });
      setTimeout(() => setPenaltyFly(null), currentSpeed.ms * 1.5);
    }

    setTimeout(() => {
      setPhysicalThrow(null);
      const next = playUnoCard(state, 0, card.id, chosenColor);
      commitState(next);
    }, currentSpeed.ms);
  };

  const handleColorChoice = (color: UnoColor) => {
    if (!selectedWildCard) return;
    const card = selectedWildCard;
    setSelectedWildCard(null);

    const currentSpeed = SPEED_CONFIG[speed];
    setPhysicalThrow({ card, fromPlayer: 0 });

    if (card.value === "wild4") {
      playUnoSpecialCardSound();
      const targetP = (0 + state.direction * 1 + state.playerCount) % state.playerCount;
      setPenaltyFly({ targetPlayer: targetP, count: 4 });
      setTimeout(() => setPenaltyFly(null), currentSpeed.ms * 1.5);
    } else {
      playUnoCardPlaySound();
    }

    setTimeout(() => {
      setPhysicalThrow(null);
      const next = playUnoCard(state, 0, card.id, color);
      commitState(next);
    }, currentSpeed.ms);
  };

  // Kart Çekme Animasyonu
  const handleDraw = () => {
    if (!isMyTurn || state.hasDrawnThisTurn || isDrawingAnim || physicalThrow) return;

    setIsDrawingAnim(true);
    playUnoCardDealSound();
    const animMs = SPEED_CONFIG[speed].ms;

    setTimeout(() => {
      const next = drawUnoCard(stateRef.current, 0);
      const drawnCard = next.hands[0][next.hands[0].length - 1];
      if (drawnCard) {
        setRecentlyDrawnCardId(drawnCard.id);
      }
      commitState(next);
      setIsDrawingAnim(false);

      setTimeout(() => {
        setRecentlyDrawnCardId(null);
      }, animMs + 100);
    }, animMs);
  };

  const handlePass = () => {
    if (!isMyTurn || !state.hasDrawnThisTurn) return;
    const next = passUnoTurn(state, 0);
    commitState(next);
  };

  const handleSayUno = () => {
    setUnoShoutAnim("UNO!");
    setTimeout(() => setUnoShoutAnim(null), 1500);
    const next = declareUno(state, 0);
    commitState(next);
  };

  // Sonraki Round (3 round üzerinden)
  const nextRound = () => {
    const next = newUnoGame(playerCount, state.playerNames, state.roundWins, state.round + 1);
    commitState(next);
  };

  const restartGame = () => {
    const next = newUnoGame(playerCount, state.playerNames);
    commitState(next);
  };

  const copyRoomLink = async () => {
    try {
      if (typeof window !== "undefined") {
        await navigator.clipboard.writeText(window.location.href);
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2000);
      }
    } catch {}
  };

  // Kart aralığı: ferah ve ortalanmış
  const handOverlapClass =
    myHand.length <= 4
      ? "gap-3"
      : myHand.length <= 7
      ? "gap-2"
      : myHand.length <= 10
      ? "gap-1 -space-x-1"
      : "-space-x-2";

  return (
    <main
      className="relative flex h-screen max-h-screen flex-col overflow-hidden bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-900 text-white select-none"
      style={{ ["--pc-anim-ms" as string]: `${SPEED_CONFIG[speed].ms}ms` }}
    >
      {/* Üst Bar */}
      <header className="relative z-20 flex shrink-0 items-center justify-between px-3.5 py-2.5 bg-neutral-950/85 backdrop-blur border-b border-white/10 shadow-lg">
        <div className="flex items-center gap-2.5">
          <Link
            href="/"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/15 text-xl font-bold hover:bg-white/25 active:scale-95 transition"
            aria-label="Ana sayfa"
          >
            ‹
          </Link>
          <div className="flex items-center gap-1.5">
            <span className="text-xl">🎴</span>
            <span className="font-black tracking-wider text-amber-400 text-sm">UNO</span>
            <span className="rounded bg-white/10 px-2 py-0.5 text-[10px] font-bold text-neutral-300">
              {isOnline && roomCode ? `ODA: ${roomCode}` : `${playerCount}P`}
            </span>
          </div>
        </div>

        {/* Hız Seçici & Aksiyonlar */}
        <div className="flex items-center gap-2">
          {/* Kart Çekme / Animasyon Hızı Seçici */}
          <div className="flex items-center rounded-full bg-white/10 p-0.5 border border-white/10">
            {(["fast", "normal", "slow", "ultraSlow"] as AnimSpeed[]).map((spKey) => (
              <button
                key={spKey}
                type="button"
                onClick={() => changeSpeed(spKey)}
                className={`flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-bold transition ${
                  speed === spKey
                    ? "bg-amber-400 text-neutral-950 shadow"
                    : "text-neutral-300 hover:text-white"
                }`}
                title={`Animasyon Hızı: ${SPEED_CONFIG[spKey].label}`}
              >
                <span>{SPEED_CONFIG[spKey].icon}</span>
                <span className="hidden sm:inline">{SPEED_CONFIG[spKey].label}</span>
              </button>
            ))}
          </div>

          {isOnline && roomCode && (
            <>
              <button
                type="button"
                onClick={copyRoomLink}
                className="rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold hover:bg-white/25 transition"
                title="Oda linkini kopyala"
              >
                {copiedLink ? "✓ Kopyalandı" : "🔗 Davet"}
              </button>
              <VoiceChat roomCode={roomCode} role="host" />
            </>
          )}

          {/* Tur Pas Butonu */}
          {isMyTurn && state.hasDrawnThisTurn && (
            <button
              type="button"
              onClick={handlePass}
              className="rounded-full bg-amber-500 px-3.5 py-1 text-xs font-black text-neutral-950 shadow-md hover:bg-amber-400 active:scale-95 transition animate-pulse"
            >
              Pas Geç →
            </button>
          )}

          <button
            type="button"
            onClick={restartGame}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-white/15 text-base font-bold hover:bg-white/25 active:scale-95 transition"
            title="Yeniden Başlat"
          >
            ↻
          </button>
        </div>
      </header>

      {/* ⚠️ RAKİBİN 1 KARTI KALDI UYARI BİLDİRİMİ */}
      {opponentsWithOneCard.length > 0 && (
        <div className="relative z-30 mx-auto -mb-2 mt-1 w-full max-w-md px-3 animate-bounce">
          <div className="pc-uno-alert-banner flex items-center justify-center gap-2 rounded-2xl border-2 border-red-500 bg-gradient-to-r from-red-650 via-amber-600 to-red-650 px-4 py-1.5 text-center shadow-2xl">
            <span className="text-base animate-spin">⚠️</span>
            <span className="text-xs font-black tracking-wide text-white uppercase drop-shadow">
              DİKKAT: {opponentsWithOneCard.map((o) => o.name).join(", ")}&#39;nin sadece 1 KARTI KALDI! (UNO!)
            </span>
            <span className="text-base animate-pulse">🔥</span>
          </div>
        </div>
      )}

      {/* Masa Alanı */}
      <div className="relative flex flex-1 flex-col items-center justify-between p-3 overflow-hidden">
        {/* Üstteki Oyuncu */}
        <div className="flex flex-col items-center">
          <div className="flex items-center gap-2 rounded-full bg-black/40 px-3 py-1 border border-white/10 text-xs font-bold mb-1 shadow">
            <span
              className={
                state.currentTurn === (playerCount === 2 ? 1 : 2)
                  ? "text-amber-400 animate-pulse font-black"
                  : "text-neutral-500"
              }
            >
              ●
            </span>
            <span>{state.playerNames[playerCount === 2 ? 1 : 2]}</span>
            <span className="rounded bg-white/15 px-1.5 text-[10px]">
              {state.hands[playerCount === 2 ? 1 : 2].length} kart
            </span>
            <span className="rounded bg-amber-400/20 px-1.5 text-[10px] text-amber-300 font-bold">
              ★ {state.roundWins[playerCount === 2 ? 1 : 2]}/{state.maxRounds}
            </span>
          </div>
          <div className="flex gap-1 -space-x-1">
            {state.hands[playerCount === 2 ? 1 : 2].slice(0, 10).map((_, i) => (
              <UnoCardView key={i} faceDown size="sm" />
            ))}
          </div>
        </div>

        {/* 3 ve 4 Kişilikte Yan Oyuncular */}
        {playerCount >= 3 && (
          <div className="absolute inset-y-0 left-3 flex flex-col justify-center items-center pointer-events-none">
            <div className="flex items-center gap-1.5 rounded-full bg-black/40 px-2.5 py-1 border border-white/10 text-[11px] font-bold mb-1 shadow rotate-90">
              <span className={state.currentTurn === 1 ? "text-amber-400 animate-pulse" : "text-neutral-500"}>●</span>
              <span>{state.playerNames[1]}</span>
              <span className="rounded bg-white/15 px-1 text-[9px]">{state.hands[1].length}</span>
            </div>
            <div className="flex flex-col -space-y-6 mt-6">
              {state.hands[1].slice(0, 6).map((_, i) => (
                <UnoCardView key={i} faceDown size="sm" className="rotate-90" />
              ))}
            </div>
          </div>
        )}

        {playerCount === 4 && (
          <div className="absolute inset-y-0 right-3 flex flex-col justify-center items-center pointer-events-none">
            <div className="flex items-center gap-1.5 rounded-full bg-black/40 px-2.5 py-1 border border-white/10 text-[11px] font-bold mb-1 shadow -rotate-90">
              <span className={state.currentTurn === 3 ? "text-amber-400 animate-pulse" : "text-neutral-500"}>●</span>
              <span>{state.playerNames[3]}</span>
              <span className="rounded bg-white/15 px-1 text-[9px]">{state.hands[3].length}</span>
            </div>
            <div className="flex flex-col -space-y-6 mt-6">
              {state.hands[3].slice(0, 6).map((_, i) => (
                <UnoCardView key={i} faceDown size="sm" className="-rotate-90" />
              ))}
            </div>
          </div>
        )}

        {/* Masanın Ortası: Deste & Atılan Kart & Durum */}
        <div className="relative flex flex-col items-center justify-center my-auto">
          {/* Son Eylem / Durum Bildirimi */}
          <div className="mb-3 rounded-full bg-black/60 px-4 py-1 text-xs font-semibold text-neutral-200 border border-white/15 shadow backdrop-blur text-center max-w-xs truncate">
            {state.lastAction}
          </div>

          <div className="flex items-center gap-8">
            {/* Kapalı Çekme Destesi - Tıklayınca Akıcı Çekme Animasyonu */}
            <div className="flex flex-col items-center">
              <div
                onClick={handleDraw}
                className={`relative transition-transform duration-200 ${
                  isMyTurn && !state.hasDrawnThisTurn
                    ? "hover:scale-105 active:scale-95 cursor-pointer ring-2 ring-amber-400/80 rounded-2xl"
                    : "opacity-80"
                }`}
              >
                <div className="absolute -left-1.5 -top-1.5 h-full w-full rounded-2xl bg-neutral-900 border border-neutral-750" />
                <div className="absolute -left-0.5 -top-0.5 h-full w-full rounded-2xl bg-neutral-850" />
                <UnoCardView faceDown size="lg" className="shadow-2xl" />

                {/* Çekilen kart uçuş animasyonu */}
                {isDrawingAnim && (
                  <div className="pointer-events-none absolute inset-0 z-30 pc-card-draw-anim">
                    <UnoCardView faceDown size="lg" />
                  </div>
                )}
              </div>
              <span
                className={`mt-2 text-xs font-black tracking-wide ${
                  isMyTurn && !state.hasDrawnThisTurn
                    ? "text-amber-400 animate-pulse"
                    : "text-neutral-400"
                }`}
              >
                {isMyTurn && !state.hasDrawnThisTurn ? "Kart Çek 🂠" : "Deste"}
              </span>
            </div>

            {/* Ortadaki Açık Kart (Discard Pile) */}
            <div className="flex flex-col items-center relative">
              {/* +2 / +4 kart uçuşu animasyonu */}
              {penaltyFly && (
                <div
                  className="pointer-events-none absolute z-40 pc-card-draw-anim flex items-center justify-center"
                  style={{
                    top:
                      penaltyFly.targetPlayer === 1 && playerCount > 2
                        ? "0px"
                        : penaltyFly.targetPlayer === 2 || (playerCount === 2 && penaltyFly.targetPlayer === 1)
                        ? "-150px"
                        : "120px",
                    left:
                      penaltyFly.targetPlayer === 1 && playerCount > 2
                        ? "-160px"
                        : penaltyFly.targetPlayer === 3
                        ? "160px"
                        : "0px",
                  }}
                >
                  <div className="flex -space-x-4">
                    {Array.from({ length: Math.min(penaltyFly.count, 4) }).map((_, idx) => (
                      <UnoCardView key={idx} faceDown size="sm" className="shadow-2xl ring-2 ring-red-500" />
                    ))}
                  </div>
                  <span className="absolute -top-6 rounded-full bg-red-600 px-2 py-0.5 text-[11px] font-black text-white shadow animate-bounce">
                    +{penaltyFly.count}!
                  </span>
                </div>
              )}

              {/* Fiziksel Olarak Ortaya Kart Fırlatma Animasyonu */}
              {physicalThrow && (
                <div
                  className="pointer-events-none absolute inset-0 z-50 pc-card-physical-throw flex items-center justify-center"
                  style={{
                    ["--throw-from-y" as string]:
                      physicalThrow.fromPlayer === 0
                        ? "190px"
                        : physicalThrow.fromPlayer === (playerCount === 2 ? 1 : 2)
                        ? "-190px"
                        : "0px",
                    ["--throw-from-x" as string]:
                      physicalThrow.fromPlayer === 1 && playerCount > 2
                        ? "-180px"
                        : physicalThrow.fromPlayer === 3
                        ? "180px"
                        : "0px",
                  }}
                >
                  <UnoCardView card={physicalThrow.card} size="lg" className="shadow-2xl ring-2 ring-white" />
                </div>
              )}

              <div className="relative">
                <div className="pc-card-drop">
                  <UnoCardView card={topCard} size="lg" className="shadow-2xl" />
                </div>

                {/* Yön & Aktif Renk Göstergesi */}
                <div
                  className="absolute -right-3 -top-3 flex h-8 w-8 items-center justify-center rounded-full border-2 border-white shadow-xl text-xs font-black"
                  style={{
                    backgroundColor:
                      state.currentColor === "red"
                        ? "#e52521"
                        : state.currentColor === "yellow"
                        ? "#f9c70c"
                        : state.currentColor === "green"
                        ? "#2ba84a"
                        : "#0956a8",
                  }}
                  title={`Aktif Renk: ${state.currentColor.toUpperCase()}`}
                >
                  {state.direction === 1 ? "↷" : "↶"}
                </div>
              </div>
              <span className="mt-2 text-xs font-black uppercase tracking-wider text-neutral-200">
                Renk: <span className="text-amber-400 font-black">{state.currentColor}</span>
              </span>
            </div>
          </div>

          {/* UNO Butonu (Eğer 1 veya 2 kartımız varsa) */}
          {myHand.length <= 2 && (
            <button
              type="button"
              onClick={handleSayUno}
              className="mt-4 flex items-center justify-center rounded-full bg-gradient-to-r from-red-600 via-amber-500 to-red-600 px-6 py-2 text-base font-black italic tracking-wider text-white shadow-2xl ring-2 ring-white/60 transition hover:scale-105 active:scale-95 animate-bounce"
            >
              🔥 UNO!
            </button>
          )}

          {/* UNO Haykırış Animasyonu */}
          {unoShoutAnim && (
            <div className="pointer-events-none absolute z-50 text-6xl font-black italic text-amber-300 drop-shadow-[0_4px_14px_rgba(239,68,68,0.95)] animate-ping">
              {unoShoutAnim}
            </div>
          )}
        </div>

        {/* ───── ALTTAN OYUNCUNUN ELİ (Ortalanmış, Ferah Aralıklarla) ───── */}
        <div className="relative z-10 w-full max-w-2xl pb-2">
          {/* Başlık ve Round Skoru */}
          <div className="mb-1.5 flex items-center justify-between px-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black tracking-wider text-neutral-300">SENİN ELİN:</span>
              <span className="rounded-full bg-amber-400/20 px-2.5 py-0.5 text-xs font-bold text-amber-300">
                {myHand.length} KART
              </span>
              <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[11px] font-black text-emerald-300">
                Round {state.round} (Kazanılan: {state.roundWins[0]}/{state.maxRounds})
              </span>
            </div>
            {isMyTurn && (
              <span className="rounded-full bg-emerald-500/25 border border-emerald-400/50 px-3.5 py-0.5 text-xs font-black text-emerald-300 shadow-sm animate-pulse">
                Sıra Sende!
              </span>
            )}
          </div>

          {/* Kartlar: Tam ortada (`justify-center mx-auto`), ferah aralıklarla */}
          <div className="flex w-full items-end justify-center overflow-x-auto py-3 px-2 scrollbar-thin">
            <div className={`flex items-end justify-center ${handOverlapClass}`}>
              {myHand.map((card, idx) => {
                const playable = isMyTurn && canPlayCard(card, topCard, state.currentColor);
                const isJustDrawn = recentlyDrawnCardId === card.id;

                return (
                  <div
                    key={card.id}
                    className={`transition-all duration-200 ${
                      isJustDrawn ? "pc-card-draw-anim" : "pc-card-enter"
                    }`}
                    style={{ animationDelay: `${idx * 25}ms` }}
                  >
                    <UnoCardView
                      card={card}
                      playable={playable}
                      size="md"
                      onClick={() => handleCardClick(card)}
                    />
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Wild Renk Seçim Modalı */}
      {selectedWildCard && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-xs rounded-3xl border-2 border-white/20 bg-neutral-900 p-6 text-center shadow-2xl">
            <h3 className="text-lg font-black text-white mb-2">Renk Seçin:</h3>
            <p className="text-xs text-neutral-400 mb-4">Oyunun devam edeceği rengi belirleyin.</p>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => handleColorChoice("red")}
                className="flex h-16 items-center justify-center rounded-2xl bg-[#e52521] text-base font-black text-white shadow-lg transition hover:scale-105 active:scale-95"
              >
                Kırmızı
              </button>
              <button
                type="button"
                onClick={() => handleColorChoice("blue")}
                className="flex h-16 items-center justify-center rounded-2xl bg-[#0956a8] text-base font-black text-white shadow-lg transition hover:scale-105 active:scale-95"
              >
                Mavi
              </button>
              <button
                type="button"
                onClick={() => handleColorChoice("yellow")}
                className="flex h-16 items-center justify-center rounded-2xl bg-[#f9c70c] text-base font-black text-neutral-950 shadow-lg transition hover:scale-105 active:scale-95"
              >
                Sarı
              </button>
              <button
                type="button"
                onClick={() => handleColorChoice("green")}
                className="flex h-16 items-center justify-center rounded-2xl bg-[#2ba84a] text-base font-black text-white shadow-lg transition hover:scale-105 active:scale-95"
              >
                Yeşil
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Round Sonu veya Maç Sonu Modalı (3 Round Kuralı) */}
      {(state.status === "round_over" || state.status === "finished") && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl border-2 border-amber-400 bg-neutral-900 p-6 text-center shadow-2xl">
            <div className="text-5xl mb-2">
              {state.status === "finished"
                ? state.matchWinner === 0
                  ? "🏆"
                  : "😔"
                : state.roundWinner === 0
                ? "🎉"
                : "🤖"}
            </div>
            <h2 className="text-2xl font-black text-white">
              {state.status === "finished"
                ? state.matchWinner === 0
                  ? "Tebrikler, Maçı Kazandın!"
                  : `${state.playerNames[state.matchWinner!]} Maçı Kazandı!`
                : state.roundWinner === 0
                ? "Roundu Kazandın!"
                : `${state.playerNames[state.roundWinner!]} Roundu Kazandı!`}
            </h2>
            <p className="text-xs text-neutral-300 mt-1">{state.lastAction}</p>

            {/* Round Skor Tablosu (3 Round Kuralı) */}
            <div className="my-4 rounded-2xl bg-white/5 p-3 border border-white/10 text-left">
              <div className="text-xs font-bold text-amber-300 mb-2">
                Kazanılan Roundlar (İlk 3 olan maçı alır):
              </div>
              {state.playerNames.map((name, i) => (
                <div key={i} className="flex justify-between items-center py-1 text-xs">
                  <span className={i === (state.matchWinner ?? state.roundWinner) ? "font-bold text-amber-400" : "text-neutral-300"}>
                    {name}
                  </span>
                  <span className="font-mono font-bold text-white">
                    {state.roundWins[i]} / {state.maxRounds} Round
                  </span>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              {state.status === "finished" ? (
                <button
                  type="button"
                  onClick={restartGame}
                  className="flex-1 rounded-xl bg-amber-500 py-3 text-sm font-black text-neutral-950 shadow hover:bg-amber-400 transition"
                >
                  Yeni Maç Başlat
                </button>
              ) : (
                <button
                  type="button"
                  onClick={nextRound}
                  className="flex-1 rounded-xl bg-emerald-500 py-3 text-sm font-black text-neutral-950 shadow hover:bg-emerald-400 transition"
                >
                  Sonraki Round ({state.round + 1}) →
                </button>
              )}
              <Link
                href="/"
                className="rounded-xl bg-white/10 px-4 py-3 text-sm font-bold text-white hover:bg-white/20 transition"
              >
                Ana Sayfa
              </Link>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

import { SafeClientBoundary } from "@/components/SafeClientBoundary";

export default function UnoPage() {
  return (
    <SafeClientBoundary fallbackTitle="UNO">
      <Suspense
        fallback={
          <main className="flex min-h-screen items-center justify-center bg-neutral-950 text-white">
            <div className="text-sm font-semibold">UNO Yükleniyor…</div>
          </main>
        }
      >
        <UnoInner />
      </Suspense>
    </SafeClientBoundary>
  );
}
