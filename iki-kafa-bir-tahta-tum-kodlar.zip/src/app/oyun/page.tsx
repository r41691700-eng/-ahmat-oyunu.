"use client";

import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Chess } from "chess.js";
import type { Square, PieceSymbol } from "chess.js";
import {
  chessApply,
  chessInitialState,
  capturedPieces,
  checkedKingSquare,
  legalChessTargets,
  REASON_TR,
  type ChessState,
  type Color,
} from "@/lib/chessState";
import {
  checkersApply,
  checkersInitialState,
  countPieces,
  legalMoves,
  CK_REASONS_TR,
  type CKColor,
  type CKState,
} from "@/lib/checkers";
import { bestChessMove, type Difficulty } from "@/lib/chessBot";
import { bestCheckersMove } from "@/lib/checkersBot";
import { ChessBoard } from "@/components/ChessBoard";
import { CheckersBoard } from "@/components/CheckersBoard";
import { VoiceChat } from "@/components/VoiceChat";
import {
  playChessMoveSound,
  playCheckersMoveSound,
  playChessCheckSound,
  playVictorySound,
  playDefeatSound,
  playDrawSound,
  playStartGameSound,
} from "@/lib/sounds";
import { Header } from "@/components/Header";

type Game = "chess" | "checkers";
type Mode = "bot" | "2p" | "online";
type GS = ChessState | CKState;
type C = "w" | "b";

const oppositeOf = (c: C, _game: Game): C => (c === "w" ? "b" : "w");

const colorName = (c: C, _game: Game): string => (c === "w" ? "Beyaz" : "Siyah");

function Dots() {
  return (
    <span className="inline-flex gap-0.5 align-middle">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="pc-think-dot inline-block h-1 w-1 rounded-full bg-current"
          style={{ animationDelay: `${i * 0.2}s` }}
        />
      ))}
    </span>
  );
}

function PieceRow({ glyphs, color }: { glyphs: string[]; color: "w" | "b" }) {
  if (glyphs.length === 0) return <span className="pc-faint text-[11px]">—</span>;
  // glyphs are piece type letters (q, r, b, n, p) of the opponent's captured pieces
  const opp = color === "w" ? "b" : "w";
  return (
    <span className="inline-flex items-center">
      {glyphs.map((t, i) => (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          key={i}
          src={`/pieces/${opp}${t.toUpperCase()}.svg`}
          alt={t}
          className="-ml-1 h-4 w-4 first:ml-0"
          draggable={false}
        />
      ))}
    </span>
  );
}

function pieceAt(fen: string, sq: Square): { color: "w" | "b"; type: string } | null {
  const ch = new Chess(fen);
  for (const row of ch.board()) {
    for (const p of row) {
      if (p && p.square === sq) return p;
    }
  }
  return null;
}

function OyunInner() {
  const sp = useSearchParams();
  const game: Game = sp.get("g") === "checkers" ? "checkers" : "chess";
  const mode: Mode =
    sp.get("mode") === "online" ? "online" : sp.get("mode") === "2p" ? "2p" : "bot";
  const diff: Difficulty =
    sp.get("d") === "kolay" || sp.get("d") === "zor" ? (sp.get("d") as Difficulty) : "orta";
  const cParam = (sp.get("c") || "w") as C;
  const codeParam = (sp.get("code") || "").toUpperCase();
  const joinParam = (sp.get("join") || "").toUpperCase();

  const isChess = game === "chess";
  const [code, setCode] = useState(codeParam);

  const [gs, setGs] = useState<GS>(() =>
    isChess ? chessInitialState("playing") : checkersInitialState("playing"),
  );
  const gsRef = useRef<GS>(gs);
  const [myColor, setMyColor] = useState<C>(() => (cParam === "b" ? "b" : "w"));
  const [sel, setSel] = useState<string | null>(null);
  const [pendingPromo, setPendingPromo] = useState<{ from: Square; to: Square } | null>(null);
  const [thinking, setThinking] = useState(false);
  const [version, setVersion] = useState(1);
  const versionRef = useRef(1);
  const [room, setRoom] = useState<{
    hostName: string;
    guestName: string | null;
    hostColor: string;
    status: string;
  } | null>(null);
  const [netError, setNetError] = useState<string | null>(null);
  const [joining, setJoining] = useState(!!joinParam);
  const [copied, setCopied] = useState(false);
  const [ambienceOn, setAmbienceOn] = useState(false);
  const undoStack = useRef<GS[]>([]);
  const botToken = useRef(0);
  const joinDone = useRef(false);
  const listRef = useRef<HTMLDivElement>(null);
  const prevMoveNo = useRef(gs.moveNo);
  const prevStatus = useRef(gs.status);

  const oppColor = oppositeOf(myColor, game);

  const setGs2 = useCallback((next: GS) => {
    gsRef.current = next;
    setGs(next);
    setSel(null);
  }, []);

  const canMove =
    gs.status === "playing" &&
    (mode === "online" ? gs.turn === myColor && room?.status === "playing" : true);

  // ---------- sound effects on game start, moves & game over ----------
  useEffect(() => {
    // Game start fanfare
    playStartGameSound();
  }, []);

  useEffect(() => {
    // Sound on move change
    if (gs.moveNo > prevMoveNo.current) {
      if (isChess) {
        const cState = gs as ChessState;
        const inCheck = !!checkedKingSquare(cState);
        if (inCheck) {
          playChessCheckSound();
        } else {
          const lastHist = cState.history[cState.history.length - 1];
          const isCap = lastHist?.san?.includes("x") ?? false;
          playChessMoveSound(isCap);
        }
      } else {
        const ckState = gs as CKState;
        const isCap = (ckState.lastMove?.caps?.length ?? 0) > 0;
        playCheckersMoveSound(isCap);
      }
    }
    prevMoveNo.current = gs.moveNo;
  }, [gs.moveNo, isChess, gs]);

  useEffect(() => {
    // Sound on game finished
    if (gs.status === "finished" && prevStatus.current !== "finished") {
      if (gs.winner === "draw") {
        playDrawSound();
      } else if (gs.winner === myColor) {
        playVictorySound();
      } else {
        playDefeatSound();
      }
    }
    prevStatus.current = gs.status;
  }, [gs.status, gs.winner, myColor]);

  // ---------- online: join via deep link ----------
  useEffect(() => {
    if (!joinParam || joinDone.current) return;
    joinDone.current = true;
    (async () => {
      try {
        const nick = localStorage.getItem("pc_nick") || "Misafir";
        const res = await fetch("/api/rooms/join", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code: joinParam, guestName: nick }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "oda bulunamadı");
        setMyColor(data.guestColor as C);
        setCode(data.code);
        versionRef.current = data.version;
        setVersion(data.version);
        setJoining(false);
        window.history.replaceState(
          null,
          "",
          `/oyun?g=${data.game}&mode=online&code=${data.code}&c=${data.guestColor}`,
        );
      } catch (e) {
        setJoining(false);
        setNetError(e instanceof Error ? e.message : "oda bulunamadı");
      }
    })();
  }, [joinParam]);

  // ---------- online: fetch + poll ----------
  const fetchRoom = useCallback(
    async (silent = false) => {
      if (!code) return;
      try {
        const res = await fetch(`/api/rooms/${code}`, { cache: "no-store" });
        if (res.status === 404) {
          setNetError("Oda bulunamadı veya silindi.");
          return;
        }
        if (!res.ok) return;
        const data = await res.json();
        const s = data.state as GS;
        if (s && typeof (s as { moveNo?: number }).moveNo === "number") {
          if (data.version !== versionRef.current) {
            versionRef.current = data.version;
            setVersion(data.version);
          }
          if (
            (gsRef.current as { moveNo: number }).moveNo !== (s as { moveNo: number }).moveNo ||
            (gsRef.current as { status: string }).status !== (s as { status: string }).status
          ) {
            gsRef.current = s;
            setGs(s);
            setSel(null);
          }
        }
        setRoom({
          hostName: data.hostName,
          guestName: data.guestName,
          hostColor: data.hostColor,
          status: data.status,
        });
        setNetError(null);
      } catch {
        if (!silent) setNetError("Sunucuya bağlanılamadı.");
      }
    },
    [code],
  );

  useEffect(() => {
    if (mode !== "online" || !code) return;
    fetchRoom();
    const t = setInterval(() => fetchRoom(true), 1300);
    return () => clearInterval(t);
  }, [mode, code, fetchRoom]);

  const pushOnline = useCallback(
    async (next: GS) => {
      if (mode !== "online" || !code) return;
      const res = await fetch(`/api/rooms/${code}/move`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ expectedVersion: versionRef.current, state: next }),
      });
      if (res.ok) {
        versionRef.current += 1;
        setVersion(versionRef.current);
        setGs2(next);
      } else if (res.status === 409) {
        const data = await res.json().catch(() => null);
        if (data) {
          versionRef.current = data.version ?? versionRef.current;
          setVersion(versionRef.current);
          if (data.state) {
            gsRef.current = data.state as GS;
            setGs(data.state as GS);
          }
        }
        setNetError("Eşzamanlı hamle çakışması — durum senkronize edildi.");
        setTimeout(() => setNetError(null), 2500);
      } else if (res.status === 404) {
        setNetError("Oda bulunamadı veya silindi.");
      } else {
        setNetError("Hamle gönderilemedi.");
      }
    },
    [mode, code, setGs2],
  );

  // ---------- local move ----------
  const applyLocal = useCallback(
    (from: string, to: string, promo?: PieceSymbol) => {
      const cur = gsRef.current;
      if (cur.status !== "playing") return;
      let next: GS | null = null;
      if (isChess) {
        next = chessApply(cur as ChessState, from as Square, to as Square, promo, false);
      } else {
        const st = cur as CKState;
        const mv = legalMoves(st.board, st.turn).moves.find(
          (m) => m.from === Number(from) && m.to === Number(to),
        );
        if (mv) next = checkersApply(st, mv);
      }
      if (!next) return;
      undoStack.current.push(cur);
      if (mode === "online") void pushOnline(next);
      else setGs2(next);
    },
    [isChess, mode, pushOnline, setGs2],
  );

  // ---------- bot ----------
  useEffect(() => {
    if (mode !== "bot" || gs.status !== "playing" || gs.turn !== oppColor) return;
    const token = ++botToken.current;
    setThinking(true);
    const t = setTimeout(() => {
      if (token !== botToken.current) return;
      try {
        const cur = gsRef.current;
        if (cur.status !== "playing") {
          setThinking(false);
          return;
        }
        let next: GS | null = null;
        if (isChess) {
          const mv = bestChessMove((cur as ChessState).fen, diff);
          if (mv) next = chessApply(cur as ChessState, mv.from, mv.to, mv.promotion, true);
        } else {
          const mv = bestCheckersMove((cur as CKState).board, oppColor as CKColor, diff);
          if (mv) next = checkersApply(cur as CKState, mv);
        }
        setThinking(false);
        if (next) setGs2(next);
      } catch {
        setThinking(false);
      }
    }, 350 + Math.random() * 500);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gs.moveNo, gs.status, mode]);

  // ---------- controls ----------
  const doUndo = () => {
    if (mode === "online" || undoStack.current.length === 0) return;
    botToken.current += 1;
    setThinking(false);
    const prev = undoStack.current.pop()!;
    setGs2(prev);
  };

  const doResign = () => {
    const cur = gsRef.current;
    if (cur.status !== "playing") return;
    const opp = oppositeOf(myColor, game);
    const next: GS = isChess
      ? {
          ...(cur as ChessState),
          status: "finished",
          winner: opp as "w" | "b",
          reason: "resigned",
        }
      : {
          ...(cur as CKState),
          status: "finished",
          winner: opp as CKColor,
          reason: "resigned",
        };
    if (mode === "online") void pushOnline(next);
    else setGs2(next);
  };

  const doNew = () => {
    botToken.current += 1;
    setThinking(false);
    undoStack.current = [];
    const fresh = isChess ? chessInitialState("playing") : checkersInitialState("playing");
    if (mode === "online") void pushOnline(fresh);
    else setGs2(fresh);
  };

  const shareLink =
    typeof window !== "undefined"
      ? `${window.location.origin}/oyun?g=${game}&mode=online&join=${code}`
      : "";

  const copyShare = async () => {
    try {
      await navigator.clipboard.writeText(shareLink);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = shareLink;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  // ---------- click handling ----------
  const clickChess = (sq: Square) => {
    const st = gs as ChessState;
    if (!canMove || pendingPromo) return;
    if (sel !== null) {
      const move = legalChessTargets(st, sel as Square).find((m) => m.to === sq);
      if (move) {
        if (move.promotion) setPendingPromo({ from: sel as Square, to: sq });
        else applyLocal(sel as Square, sq);
        setSel(null);
        return;
      }
    }
    const piece = pieceAt(st.fen, sq);
    if (piece && piece.color === (mode === "online" ? myColor : (st.turn as "w" | "b"))) {
      setSel(sq === sel ? null : sq);
    } else {
      setSel(null);
    }
  };

  const clickCheckers = (i: number) => {
    const st = gs as CKState;
    if (!canMove) return;
    if (sel !== null) {
      const mv = legalMoves(st.board, st.turn).moves.find(
        (m) => m.from === Number(sel) && m.to === i,
      );
      if (mv) {
        applyLocal(String(sel), String(i));
        setSel(null);
        return;
      }
    }
    const p = st.board[i];
    const actColor: CKColor = (mode === "online" ? myColor : st.turn) as CKColor;
    const movable = legalMoves(st.board, st.turn).moves.some((m) => m.from === i);
    if (p && p.c === actColor && movable) setSel(String(i) === sel ? null : String(i));
    else setSel(null);
  };

  // ---------- derived UI ----------
  const targets = useMemo(() => {
    if (!canMove || sel === null) return [] as { to: string | number; capture: boolean }[];
    if (isChess) {
      const st = gs as ChessState;
      return legalChessTargets(st, sel as Square).map((m) => ({
        to: m.to,
        capture: !!m.captured,
      }));
    }
    const st = gs as CKState;
    return legalMoves(st.board, st.turn)
      .moves.filter((m) => m.from === Number(sel))
      .map((m) => ({ to: m.to, capture: m.caps.length > 0 }));
  }, [gs, sel, canMove, isChess]);

  const forceCap = useMemo(() => {
    if (isChess || !canMove) return false;
    const st = gs as CKState;
    return legalMoves(st.board, st.turn).hasCaptures;
  }, [gs, canMove, isChess]);

  const names = useMemo(() => {
    if (mode === "bot") {
      const diffLabel = { kolay: "Kolay", orta: "Orta", zor: "Zor" }[diff];
      return { me: "Sen", opp: `Bot · ${diffLabel}` };
    }
    if (mode === "2p") {
      return { me: colorName(myColor, game), opp: colorName(oppColor, game) };
    }
    const iAmHost = room ? myColor === room.hostColor : myColor === "w";
    const me = iAmHost ? (room?.hostName || "Oyuncu") : (room?.guestName || "Misafir");
    const opp = iAmHost ? (room?.guestName || "…") : (room?.hostName || "Oyuncu");
    return { me, opp };
  }, [mode, diff, game, room, myColor, oppColor]);

  const turnIsMe = mode === "online" ? gs.turn === myColor : true;
  const turnIsBot = mode === "bot" && gs.turn === oppColor;
  const statusText =
    gs.status !== "playing"
      ? "Oyun bitti"
      : mode === "online"
        ? room?.status === "waiting"
          ? "Rakip bekleniyor"
          : turnIsMe
            ? "Sıra sende"
            : "Rakip düşünüyor"
        : turnIsBot
          ? thinking
            ? "Bot düşünüyor"
            : "Bot…"
          : "Sıra sende";

  const orientation: C = myColor;
  const finished = gs.status === "finished";

  const winnerText = (() => {
    const w = gs.winner;
    if (!w) return "Oyun bitti";
    const reason = isChess ? REASON_TR[gs.reason || ""] : CK_REASONS_TR[gs.reason || ""];
    if (w === "draw") return `🤝 Berabere — ${reason || "berabere"}`;
    if (mode === "2p") return `🏆 ${colorName(w as C, game)} kazandı — ${reason}`;
    const iWon = w === myColor;
    return `${iWon ? "🏆 Kazandın!" : "😔 Kaybettin"} — ${colorName(w as C, game)} (${reason})`;
  })();

  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [gs.history.length]);

  if (joining) {
    return (
      <main className="flex min-h-screen items-center justify-center px-4">
        <div className="pc-fade-up text-center">
          <div className="text-4xl">♞</div>
          <p className="pc-dim mt-3 text-sm">
            Odaya bağlanılıyor <Dots />
          </p>
        </div>
      </main>
    );
  }

  if (netError && mode === "online" && !room) {
    return (
      <main className="flex min-h-screen items-center justify-center px-4">
        <div className="pc-fade-up w-full max-w-sm rounded-2xl border border-red-400/30 bg-red-500/10 p-6 text-center">
          <div className="text-3xl">⚠️</div>
          <p className="mt-3 text-sm font-semibold text-red-300">{netError}</p>
          <Link
            href="/"
            className="mt-4 inline-block rounded-lg bg-amber-500 px-4 py-2 text-sm font-bold text-slate-900 hover:bg-amber-400"
          >
            ← Ana Sayfa
          </Link>
        </div>
      </main>
    );
  }

  const playerRow = (side: "me" | "opp") => {
    const isMe = side === "me";
    const name = isMe ? names.me : names.opp;
    const color: C = isMe ? myColor : oppColor;
    const dot =
      color === "w" ? "bg-slate-100" : "bg-stone-900";
    let extra: React.ReactNode = null;
    if (isChess) {
      const capBy = capturedPieces(gs as ChessState, color as Color);
      extra = <PieceRow glyphs={capBy} color={color as "w" | "b"} />;
    } else {
      const left = countPieces((gs as CKState).board, color as CKColor);
      extra = (
        <span className="pc-dim font-mono text-[11px]" title="tahtadaki taş sayısı">
          ◆ {left}
        </span>
      );
    }
    const turnHere = gs.status === "playing" && gs.turn === color;
    return (
      <div
        className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 ${
          turnHere ? "border-amber-400/60 bg-amber-500/15" : "border-white/10 bg-white/5"
        }`}
      >
        <span className={`h-3.5 w-3.5 shrink-0 rounded-full border border-black/40 ${dot}`} />
        <span className="truncate text-sm font-bold">{name}</span>
        {isMe && (
          <span className="rounded bg-amber-400/20 px-1.5 text-[10px] font-bold text-amber-300">
            sen
          </span>
        )}
        <span className="ml-auto shrink-0">{extra}</span>
      </div>
    );
  };

  return (
    <main className="min-h-screen overflow-x-hidden px-4 py-5">
      <div className="mx-auto w-full max-w-[780px]">
        <Header />
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Link
              href="/"
              className="pc-ghost hover:pc-card-hover rounded-lg px-2.5 py-1.5 text-xs font-semibold"
            >
              ← Ana Sayfa
            </Link>
            <h1 className="text-xl font-black tracking-tight">
              {isChess ? "♞ Satranç" : "🔴 Şaşki"}
            </h1>
            <span
              className={`rounded px-2 py-0.5 text-[10px] font-semibold ${
                mode === "bot"
                  ? "bg-violet-400/20 text-violet-200"
                  : mode === "2p"
                    ? "bg-emerald-400/20 text-emerald-200"
                    : "bg-sky-400/20 text-sky-200"
              }`}
            >
              {mode === "bot"
                ? "🤖 Bot · internetsiz"
                : mode === "2p"
                  ? "👥 Aynı cihaz"
                  : `🌐 Oda ${code}`}
            </span>
          </div>
          {mode === "online" && room && (
            <div className="flex items-center gap-2">
              <VoiceChat
                roomCode={code}
                role={room.hostColor === myColor ? "host" : "guest"}
              />
              <button
                type="button"
                onClick={copyShare}
                className="pc-ghost hover:pc-card-hover rounded-lg px-3 py-1.5 font-mono text-xs font-semibold tracking-widest"
              >
                {copied ? "✓ Kopyalandı" : `🔗 ${code} · davet linki`}
              </button>
            </div>
          )}
        </div>

        <div className="grid gap-4 sm:grid-cols-[minmax(0,1fr)_200px]">
          <div className="relative mx-auto w-full max-w-[560px]">
            {isChess ? (
              <ChessBoard
                state={gs as ChessState}
                orientation={orientation as "w" | "b"}
                selected={(sel as Square | null) ?? null}
                targets={targets as { to: Square; capture: boolean }[] }
                lastMove={(gs as ChessState).lastMove}
                checkSq={
                  gs.status === "playing" ? checkedKingSquare(gs as ChessState) : null
                }
                interactive={canMove && !pendingPromo}
                onSquare={clickChess}
                popKey={(gs as ChessState).moveNo}
              />
            ) : (
              <CheckersBoard
                state={gs as CKState}
                orientation={orientation as CKColor}
                selected={sel !== null ? Number(sel) : null}
                targets={targets.map((t) => Number(t.to))}
                interactive={canMove}
                onSquare={clickCheckers}
                popKey={(gs as CKState).moveNo}
              />
            )}

            {pendingPromo && (
              <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/60 backdrop-blur-sm">
                <div className="pc-fade-up rounded-2xl border border-white/15 bg-[#141b36] p-4 text-center text-slate-100 shadow-2xl">
                  <p className="mb-3 text-sm font-bold">Terfi — taş seç</p>
                  <div className="flex gap-2">
                    {(
                      [
                        ["q", "♛", "Vezir"],
                        ["r", "♜", "Kale"],
                        ["b", "♝", "Fil"],
                        ["n", "♞", "At"],
                      ] as [PieceSymbol, string, string][]
                    ).map(([p, glyph, label]) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => {
                          const { from, to } = pendingPromo;
                          setPendingPromo(null);
                          applyLocal(from, to, p);
                        }}
                        className="flex h-16 w-14 flex-col items-center justify-center rounded-xl border border-white/15 bg-white/10 text-3xl transition hover:border-amber-400 hover:bg-amber-500/20"
                      >
                        <span style={{ color: "#f5f5f4", textShadow: "0 0 2px #000" }}>
                          {glyph}
                        </span>
                        <span className="mt-1 text-[10px] font-semibold">{label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {mode === "online" && room?.status === "waiting" && (
              <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 backdrop-blur-[2px]">
                <div className="pc-fade-up mx-4 w-full max-w-xs rounded-2xl border border-sky-400/30 bg-[#101733] p-5 text-center text-slate-100 shadow-2xl">
                  <p className="text-sm font-semibold text-sky-200">Oda hazır: {code}</p>
                  <p className="pc-dim mt-1 text-xs">Arkadaşına şu linki gönder:</p>
                  <div className="mt-3 break-all rounded-lg bg-black/40 p-2 font-mono text-[11px] text-slate-300">
                    {shareLink}
                  </div>
                  <button
                    type="button"
                    onClick={copyShare}
                    className="mt-3 w-full rounded-lg bg-sky-500 px-4 py-2 text-sm font-bold text-slate-900 hover:bg-sky-400"
                  >
                    {copied ? "✓ Kopyalandı" : "🔗 Davet Linkini Kopyala"}
                  </button>
                  <p className="pc-dim mt-3 text-[11px]">
                    Rakip bağlanana kadar bekliyoruz <Dots />
                  </p>
                </div>
              </div>
            )}

            {finished && (
              <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 backdrop-blur-sm">
                <div className="pc-fade-up mx-4 w-full max-w-xs rounded-2xl border border-amber-400/40 bg-[#141b36] p-5 text-center text-slate-100 shadow-2xl">
                  <p className="text-base font-black leading-snug">{winnerText}</p>
                  <div className="mt-4 flex gap-2">
                    <button
                      type="button"
                      onClick={doNew}
                      className="flex-1 rounded-lg bg-amber-500 px-3 py-2 text-sm font-bold text-slate-900 hover:bg-amber-400"
                    >
                      🔄 Yeni Oyun
                    </button>
                    <Link
                      href="/"
                      className="flex-1 rounded-lg bg-white/10 px-3 py-2 text-sm font-bold hover:bg-white/20"
                    >
                      🏠 Ana Sayfa
                    </Link>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-col gap-2">
            {playerRow("opp")}
            <div
              className={`rounded-lg border px-3 py-2 text-center text-xs font-bold ${
                gs.status !== "playing"
                  ? "border-white/10 bg-white/5 text-slate-400"
                  : turnIsMe && !turnIsBot
                    ? "border-amber-400/60 bg-amber-500/15 text-amber-300"
                    : "border-white/10 bg-white/5 text-slate-300"
              }`}
            >
              {statusText}{" "}
              {gs.status === "playing" &&
                (turnIsBot || (mode === "online" && !turnIsMe)) && <Dots />}
            </div>
            {playerRow("me")}
            {forceCap && (
              <div className="rounded-lg border border-red-400/40 bg-red-500/15 px-3 py-1.5 text-center text-[11px] font-bold text-red-300">
                ⚠️ Yakalama zorunlu!
              </div>
            )}
            {netError && (
              <div className="rounded-lg border border-red-400/40 bg-red-500/15 px-3 py-1.5 text-center text-[11px] font-semibold text-red-300">
                {netError}
              </div>
            )}

            <div className="min-h-0 flex-1 rounded-lg border border-white/10 bg-white/5 p-2">
              <div className="pc-faint mb-1.5 text-[10px] font-bold uppercase tracking-wider">
                Hamleler
              </div>
              <div
                ref={listRef}
                className="h-36 overflow-y-auto pr-1 font-mono text-[11px] leading-5 sm:h-44"
              >
                {gs.history.length === 0 ? (
                  <p className="pc-faint font-sans text-[11px]">Henüz hamle yok.</p>
                ) : isChess ? (
                  <div className="grid grid-cols-[1.6em_1fr_1fr] gap-x-1">
                    {(gs as ChessState).history
                      .map((_, i) => i)
                      .filter((i) => i % 2 === 0)
                      .map((i) => {
                        const a = (gs as ChessState).history[i];
                        const b = (gs as ChessState).history[i + 1];
                        return (
                          <div key={i} className="contents">
                            <span className="pc-faint">{i / 2 + 1}.</span>
                            <span className="text-slate-200">{a?.san}</span>
                            <span className="text-slate-200">{b?.san}</span>
                          </div>
                        );
                      })}
                  </div>
                ) : (
                  <ol className="space-y-0.5">
                    {(gs as CKState).history.map((h, i) => (
                      <li key={i} className="flex gap-1.5">
                        <span className="pc-faint w-5 shrink-0 text-right">{i + 1}.</span>
                        <span
                          className={h.color === "w" ? "text-slate-100" : "text-slate-400"}
                        >
                          {h.label}
                        </span>
                      </li>
                    ))}
                  </ol>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={doUndo}
                disabled={mode === "online" || undoStack.current.length === 0}
                className="rounded-lg bg-white/10 px-3 py-2 text-xs font-bold transition hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-40"
              >
                ↩ Geri Al
              </button>
              <button
                type="button"
                onClick={doResign}
                disabled={gs.status !== "playing"}
                className="rounded-lg bg-white/10 px-3 py-2 text-xs font-bold transition hover:bg-red-500/40 disabled:cursor-not-allowed disabled:opacity-40"
              >
                🏳 Teslim Ol
              </button>
              <button
                type="button"
                onClick={doNew}
                className="rounded-lg bg-amber-500 px-3 py-2 text-xs font-bold text-slate-900 transition hover:bg-amber-400"
              >
                🔄 Yeni Oyun
              </button>
              <Link
                href="/"
                className="rounded-lg bg-white/10 px-3 py-2 text-center text-xs font-bold transition hover:bg-white/20"
              >
                🏠 Ana Sayfa
              </Link>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

export default function OyunPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center">
          <div className="text-slate-400">Yükleniyor…</div>
        </main>
      }
    >
      <OyunInner />
    </Suspense>
  );
}
