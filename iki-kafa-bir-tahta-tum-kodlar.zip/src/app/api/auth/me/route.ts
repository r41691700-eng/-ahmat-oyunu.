import { getSessionUser, googleConfigured } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  return Response.json({ user, googleConfigured: googleConfigured() });
}
