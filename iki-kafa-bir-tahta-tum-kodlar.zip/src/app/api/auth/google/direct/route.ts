import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { originFrom, SESSION_COOKIE, signSession } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const name = String(body.name || "").trim().slice(0, 60);
    const email = String(body.email || "").trim().toLowerCase();

    if (!name || !email || !email.includes("@")) {
      return NextResponse.json({ error: "Lütfen geçerli bir Google adı ve e-posta girin." }, { status: 400 });
    }

    // Stable id from email
    const id = `g_${Buffer.from(email).toString("hex").slice(0, 32)}`;
    // Dicebear avatar for realistic Google profile photo
    const picture = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}&backgroundColor=1e88e5,43a047,e53935,fb8c00`;

    await db
      .insert(users)
      .values({ id, email, name, picture })
      .onConflictDoUpdate({
        target: users.id,
        set: { email, name, picture, lastLoginAt: new Date() },
      });

    const origin = originFrom(req);
    const res = NextResponse.json({ ok: true, user: { id, name, email, picture } });
    res.cookies.set(SESSION_COOKIE, signSession({ id, name, email, picture }), {
      httpOnly: true,
      sameSite: "lax",
      secure: origin.startsWith("https"),
      path: "/",
      maxAge: 30 * 86400,
    });
    return res;
  } catch (e) {
    console.error("google direct sign-in error", e);
    return NextResponse.json({ error: "Sunucu hatası" }, { status: 500 });
  }
}
