import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  googleConfigured,
  originFrom,
  SESSION_COOKIE,
  STATE_COOKIE,
  signSession,
} from "@/lib/auth";

export async function GET(req: Request) {
  const origin = originFrom(req);
  const url = new URL(req.url);
  const fail = (code: string) => {
    const r = NextResponse.redirect(new URL(`/giris?err=${code}`, origin));
    r.cookies.delete(STATE_COOKIE);
    return r;
  };
  if (!googleConfigured()) return fail("notconfigured");

  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const cookieHeader = req.headers.get("cookie") || "";
  const stateCookie = cookieHeader
    .split(";")
    .map((s) => s.trim())
    .find((s) => s.startsWith(`${STATE_COOKIE}=`))
    ?.split("=")[1];
  if (!code || !state || !stateCookie || state !== stateCookie) return fail("state");

  try {
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: process.env.GOOGLE_CLIENT_ID!,
        client_secret: process.env.GOOGLE_CLIENT_SECRET!,
        redirect_uri: `${origin}/api/auth/google/callback`,
        grant_type: "authorization_code",
      }),
    });
    if (!tokenRes.ok) return fail("token");
    const tokens = (await tokenRes.json()) as { access_token?: string };
    if (!tokens.access_token) return fail("token");

    const infoRes = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    });
    if (!infoRes.ok) return fail("userinfo");
    const info = (await infoRes.json()) as {
      sub: string;
      email?: string;
      name?: string;
      picture?: string;
      email_verified?: boolean;
    };
    if (!info.sub) return fail("userinfo");

    const name = (info.name || info.email?.split("@")[0] || "Oyuncu").slice(0, 60);
    const email = info.email || "";
    const picture = info.picture || null;

    await db
      .insert(users)
      .values({ id: info.sub, email, name, picture })
      .onConflictDoUpdate({
        target: users.id,
        set: { email, name, picture, lastLoginAt: new Date() },
      });

    const res = NextResponse.redirect(new URL("/?login=ok", origin));
    res.cookies.set(SESSION_COOKIE, signSession({ id: info.sub, name, email, picture }), {
      httpOnly: true,
      sameSite: "lax",
      secure: origin.startsWith("https"),
      path: "/",
      maxAge: 30 * 86400,
    });
    res.cookies.delete(STATE_COOKIE);
    return res;
  } catch (e) {
    console.error("google callback failed", e);
    return fail("server");
  }
}
