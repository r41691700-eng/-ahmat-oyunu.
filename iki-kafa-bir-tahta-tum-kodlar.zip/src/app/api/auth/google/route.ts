import { NextResponse } from "next/server";
import { googleConfigured, newState, originFrom, STATE_COOKIE } from "@/lib/auth";

export async function GET(req: Request) {
  if (!googleConfigured()) {
    return NextResponse.redirect(new URL("/giris?err=notconfigured", originFrom(req)));
  }
  const state = newState();
  const redirectUri = `${originFrom(req)}/api/auth/google/callback`;
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID!,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "openid email profile",
    state,
    access_type: "online",
    prompt: "select_account",
  });
  const res = NextResponse.redirect(
    `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`,
  );
  res.cookies.set(STATE_COOKIE, state, {
    httpOnly: true,
    sameSite: "lax",
    secure: redirectUri.startsWith("https"),
    path: "/",
    maxAge: 600,
  });
  return res;
}
