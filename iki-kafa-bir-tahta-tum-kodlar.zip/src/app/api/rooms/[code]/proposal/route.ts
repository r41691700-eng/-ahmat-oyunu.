import { db } from "@/db";
import { rooms } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(
  req: Request,
  ctx: { params: Promise<{ code: string }> },
) {
  const { code: raw } = await ctx.params;
  const code = raw.toUpperCase().replace(/[^A-Z2-9]/g, "").slice(0, 10);
  if (!code) return Response.json({ error: "geçersiz kod" }, { status: 400 });

  try {
    const body = await req.json();
    const { action, from, points } = body;
    // action: 'propose' | 'accept' | 'decline'

    const room = (await db.select().from(rooms).where(eq(rooms.id, code)))[0];
    if (!room) return Response.json({ error: "oda bulunamadı" }, { status: 404 });

    if (action === "propose") {
      const proposal = {
        from: from || "host",
        points: Number(points) || 200,
        status: "pending" as const,
      };
      await db
        .update(rooms)
        .set({ goalProposal: proposal, updatedAt: new Date() })
        .where(eq(rooms.id, code));
      return Response.json({ ok: true, proposal });
    }

    if (action === "accept") {
      const current = room.goalProposal;
      if (!current || current.status !== "pending") {
        return Response.json({ error: "teklif bulunamadı" }, { status: 400 });
      }

      // Update game state goal if domino
      const state = (room.state || {}) as Record<string, unknown>;
      if (typeof state === "object" && state !== null && "goal" in state) {
        state.goal = current.points;
      }

      await db
        .update(rooms)
        .set({
          goalProposal: { ...current, status: "accepted" },
          state,
          version: room.version + 1,
          updatedAt: new Date(),
        })
        .where(eq(rooms.id, code));

      return Response.json({ ok: true, points: current.points, status: "accepted" });
    }

    if (action === "decline") {
      const current = room.goalProposal;
      if (current) {
        await db
          .update(rooms)
          .set({
            goalProposal: { ...current, status: "declined" },
            updatedAt: new Date(),
          })
          .where(eq(rooms.id, code));
      }
      return Response.json({ ok: true, status: "declined" });
    }

    return Response.json({ error: "geçersiz eylem" }, { status: 400 });
  } catch (e) {
    console.error("proposal error", e);
    return Response.json({ error: "sunucu hatası" }, { status: 500 });
  }
}

export async function GET(
  req: Request,
  ctx: { params: Promise<{ code: string }> },
) {
  const { code: raw } = await ctx.params;
  const code = raw.toUpperCase().replace(/[^A-Z2-9]/g, "").slice(0, 10);
  const room = (await db.select().from(rooms).where(eq(rooms.id, code)))[0];
  if (!room) return Response.json({ error: "oda bulunamadı" }, { status: 404 });
  return Response.json({ proposal: room.goalProposal ?? null });
}
