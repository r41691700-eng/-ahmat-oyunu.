import { db } from "@/db";
import { rooms } from "@/db/schema";
import { and, eq } from "drizzle-orm";

export async function POST(
  req: Request,
  ctx: { params: Promise<{ code: string }> },
) {
  const { code: raw } = await ctx.params;
  const code = raw.toUpperCase().replace(/[^A-Z2-9]/g, "").slice(0, 10);
  if (!code) return Response.json({ error: "geçersiz kod" }, { status: 400 });

  let body: { expectedVersion?: number; state?: Record<string, unknown>; status?: string };
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "geçersiz istek" }, { status: 400 });
  }

  const expected = Number(body?.expectedVersion);
  const state = body?.state;
  if (!Number.isInteger(expected) || !state || typeof state !== "object") {
    return Response.json({ error: "geçersiz istek" }, { status: 400 });
  }
  // minimal shape check
  const isChess = "fen" in state && typeof state.fen === "string";
  const isCheckers = Array.isArray(state.board) && (state.board as unknown[]).length === 64;
  const isDomino = Array.isArray(state.line) && Array.isArray(state.hands);
  const isUno = Array.isArray(state.hands) && Array.isArray(state.discardPile);
  if (!isChess && !isCheckers && !isDomino && !isUno) {
    return Response.json({ error: "geçersiz oyun durumu" }, { status: 400 });
  }
  const rawJson = JSON.stringify(state);
  if (rawJson.length > 60_000) {
    return Response.json({ error: "durum çok büyük" }, { status: 413 });
  }
  const status =
    body.status === "finished" || body.status === "playing" || body.status === "waiting"
      ? body.status
      : undefined;

  const updated = await db
    .update(rooms)
    .set({ state, version: expected + 1, updatedAt: new Date(), ...(status ? { status } : {}) })
    .where(and(eq(rooms.id, code), eq(rooms.version, expected)))
    .returning({ id: rooms.id });

  if (updated.length === 0) {
    const row = (await db.select().from(rooms).where(eq(rooms.id, code)))[0];
    if (!row) return Response.json({ error: "oda bulunamadı" }, { status: 404 });
    return Response.json(
      { error: "çakışma", version: row.version, state: row.state, status: row.status },
      { status: 409 },
    );
  }
  return Response.json({ version: expected + 1 });
}
