import { db } from "@/db";
import { rooms } from "@/db/schema";
import { eq } from "drizzle-orm";

// Voice Chat signaling endpoint: sends and receives WebRTC offer, answer, ice candidates
export async function POST(
  req: Request,
  ctx: { params: Promise<{ code: string }> },
) {
  const { code: raw } = await ctx.params;
  const code = raw.toUpperCase().replace(/[^A-Z2-9]/g, "").slice(0, 10);
  if (!code) return Response.json({ error: "geçersiz kod" }, { status: 400 });

  try {
    const body = await req.json();
    const { from, signal } = body; // from: 'host' | 'guest'

    if (!from || !signal) {
      return Response.json({ error: "eksik veri" }, { status: 400 });
    }

    const room = (await db.select().from(rooms).where(eq(rooms.id, code)))[0];
    if (!room) return Response.json({ error: "oda bulunamadı" }, { status: 404 });

    const currentSignals = (room.signals || {}) as Record<string, unknown>;
    // Store message under sender key with timestamp
    const targetKey = from === "host" ? "hostSignal" : "guestSignal";
    currentSignals[targetKey] = { ...signal, ts: Date.now() };

    await db
      .update(rooms)
      .set({ signals: currentSignals, updatedAt: new Date() })
      .where(eq(rooms.id, code));

    return Response.json({ ok: true });
  } catch (e) {
    console.error("voice signaling post error", e);
    return Response.json({ error: "sunucu hatası" }, { status: 500 });
  }
}

export async function GET(
  req: Request,
  ctx: { params: Promise<{ code: string }> },
) {
  const { code: raw } = await ctx.params;
  const code = raw.toUpperCase().replace(/[^A-Z2-9]/g, "").slice(0, 10);
  if (!code) return Response.json({ error: "geçersiz kod" }, { status: 400 });

  try {
    const room = (await db.select().from(rooms).where(eq(rooms.id, code)))[0];
    if (!room) return Response.json({ error: "oda bulunamadı" }, { status: 404 });
    return Response.json({ signals: room.signals || {} });
  } catch (e) {
    return Response.json({ error: "sunucu hatası" }, { status: 500 });
  }
}
