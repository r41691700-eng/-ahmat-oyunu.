import { db } from "@/db";
import { rooms } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(
  _req: Request,
  ctx: { params: Promise<{ code: string }> },
) {
  const { code: raw } = await ctx.params;
  const code = raw.toUpperCase().replace(/[^A-Z2-9]/g, "").slice(0, 10);
  if (!code) return Response.json({ error: "geçersiz kod" }, { status: 400 });
  const row = (await db.select().from(rooms).where(eq(rooms.id, code)))[0];
  if (!row) return Response.json({ error: "oda bulunamadı" }, { status: 404 });
  return Response.json({
    code: row.id,
    game: row.game,
    hostName: row.hostName,
    guestName: row.guestName,
    hostColor: row.hostColor,
    state: row.state,
    version: row.version,
    status: row.status,
    updatedAt: row.updatedAt,
  });
}

export async function DELETE(
  _req: Request,
  ctx: { params: Promise<{ code: string }> },
) {
  const { code: raw } = await ctx.params;
  const code = raw.toUpperCase().replace(/[^A-Z2-9]/g, "").slice(0, 10);
  await db.delete(rooms).where(eq(rooms.id, code));
  return Response.json({ ok: true });
}
