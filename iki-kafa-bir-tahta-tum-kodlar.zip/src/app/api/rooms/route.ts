import { db } from "@/db";
import { rooms } from "@/db/schema";
import { eq, lt } from "drizzle-orm";
import { sql } from "drizzle-orm";
import type { ChessState } from "@/lib/chessState";
import type { CKState } from "@/lib/checkers";

const CODE_CHARS = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

function genCode(len = 6): string {
  let s = "";
  for (let i = 0; i < len; i++) s += CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)];
  return s;
}

function cleanName(v: unknown, fallback: string): string {
  const s = String(v ?? "")
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .trim()
    .slice(0, 40);
  return s || fallback;
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    if (!body || typeof body !== "object") {
      return Response.json({ error: "geçersiz istek" }, { status: 400 });
    }
    const game =
      body.game === "uno"
        ? "uno"
        : body.game === "domino"
        ? "domino"
        : body.game === "checkers"
        ? "checkers"
        : "chess";
    const color: string = body.color === "b" ? "b" : "w";
    const hostName = cleanName(body.hostName, "Oyuncu");
    const state = body.initialState;
    const isWaiting =
      state && typeof state === "object" && ((state as { status?: string }).status === "waiting" || (state as { status?: string }).status === "playing" || (state as { round?: number }).round !== undefined);
    if (!state || typeof state !== "object" || !isWaiting) {
      return Response.json({ error: "geçersiz oyun durumu" }, { status: 400 });
    }

    // lazy cleanup: drop rooms older than 7 days
    try {
      await db
        .delete(rooms)
        .where(lt(rooms.createdAt, sql`now() - interval '7 days'`));
    } catch {
      /* ignore */
    }

    for (let attempt = 0; attempt < 6; attempt++) {
      const code = genCode();
      const exists = await db.select({ id: rooms.id }).from(rooms).where(eq(rooms.id, code));
      if (exists.length > 0) continue;
      await db.insert(rooms).values({
        id: code,
        game,
        hostName,
        hostColor: color,
        state: JSON.parse(JSON.stringify(state)) as Record<string, unknown>,
        version: 1,
        status: "waiting",
      });
      return Response.json({ code, hostColor: color }, { status: 201 });
    }
    return Response.json({ error: "oda kodu üretilemedi" }, { status: 500 });
  } catch (e) {
    console.error("create room failed", e);
    return Response.json({ error: "sunucu hatası" }, { status: 500 });
  }
}


