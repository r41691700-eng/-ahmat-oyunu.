import { db } from "@/db";
import { rooms } from "@/db/schema";
import { eq } from "drizzle-orm";

function cleanName(v: unknown, fallback: string): string {
  const s = String(v ?? "")
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .trim()
    .slice(0, 40);
  return s || fallback;
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const code = String(body?.code ?? "")
      .toUpperCase()
      .replace(/[^A-Z2-9]/g, "")
      .slice(0, 10);
    if (code.length < 4) {
      return Response.json({ error: "geçersiz oda kodu" }, { status: 400 });
    }
    const guestName = cleanName(body?.guestName, "Misafir");

    const row = (await db.select().from(rooms).where(eq(rooms.id, code)))[0];
    if (!row) return Response.json({ error: "oda bulunamadı" }, { status: 404 });
    if (row.status !== "waiting") {
      return Response.json({ error: "oda dolu" }, { status: 409 });
    }
    const guestColor = row.hostColor === "b" ? "w" : "b";

    const updated = await db
      .update(rooms)
      .set({
        guestName,
        status: "playing",
        version: row.version + 1,
        updatedAt: new Date(),
      })
      .where(eq(rooms.id, code))
      .returning({ version: rooms.version });

    return Response.json({
      code: row.id,
      game: row.game,
      hostColor: row.hostColor,
      guestColor,
      hostName: row.hostName,
      version: updated[0].version,
      status: "playing",
    });
  } catch (e) {
    console.error("join room failed", e);
    return Response.json({ error: "sunucu hatası" }, { status: 500 });
  }
}
