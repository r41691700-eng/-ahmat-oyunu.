import {
  type CKBoard,
  type CKColor,
  type CKMove,
  CK_N,
  legalMoves,
  applyMoveToBoard,
  ckR,
  opposite,
} from "./checkers";
import type { Difficulty } from "./chessBot";

/** Static eval from `color`'s perspective. */
function evalBoard(board: CKBoard, color: CKColor): number {
  let score = 0;
  for (let i = 0; i < board.length; i++) {
    const p = board[i];
    if (!p) continue;
    let v = p.k ? 300 : 100;
    if (!p.k) {
      const r = ckR(i);
      const adv = p.c === "b" ? r : CK_N - 1 - r; // 0..7
      v += adv * 3;
      if (adv === CK_N - 2) v += 10; // one step from crowning
      if (adv === 0) v += 5; // back rank guard
    }
    score += p.c === color ? v : -v;
  }
  return score;
}

function search(board: CKBoard, color: CKColor, depth: number, alpha: number, beta: number): number {
  const { moves } = legalMoves(board, color);
  if (moves.length === 0) return -100000 - depth * 10;
  if (depth === 0) return evalBoard(board, color);
  const opp = opposite(color);
  let best = -Infinity;
  for (const m of moves) {
    const s = -search(applyMoveToBoard(board, m), opp, depth - 1, -beta, -alpha);
    if (s > best) best = s;
    if (best > alpha) alpha = best;
    if (alpha >= beta) break;
  }
  return best;
}

const DEPTH: Record<Difficulty, number> = { kolay: 1, orta: 3, zor: 6 };

export function bestCheckersMove(board: CKBoard, color: CKColor, difficulty: Difficulty): CKMove | null {
  const { moves } = legalMoves(board, color);
  if (moves.length === 0) return null;
  if (moves.length === 1) return moves[0];

  if (difficulty === "kolay" && Math.random() < 0.6) {
    return moves[Math.floor(Math.random() * moves.length)];
  }
  const d = DEPTH[difficulty];
  const noise = difficulty === "orta" ? 25 : difficulty === "kolay" ? 60 : 0;
  let best = moves[0];
  let bestScore = -Infinity;
  for (const m of moves) {
    const val =
      -search(applyMoveToBoard(board, m), opposite(color), d - 1, -Infinity, Infinity) +
      Math.random() * noise;
    if (val > bestScore) {
      bestScore = val;
      best = m;
    }
  }
  return best;
}
