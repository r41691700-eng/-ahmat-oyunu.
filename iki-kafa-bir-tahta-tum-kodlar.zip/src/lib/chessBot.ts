import { Chess, type Move, type PieceSymbol } from "chess.js";

export type Difficulty = "kolay" | "orta" | "zor";

const VAL: Record<PieceSymbol, number> = {
  p: 100, n: 320, b: 330, r: 500, q: 900, k: 20000,
};

// Piece-square tables, white perspective, index 0 = a8 … 63 = h1
const T_PAWN = [
  0, 0, 0, 0, 0, 0, 0, 0,
  50, 50, 50, 50, 50, 50, 50, 50,
  10, 10, 20, 30, 30, 20, 10, 10,
  5, 5, 10, 25, 25, 10, 5, 5,
  0, 0, 0, 20, 20, 0, 0, 0,
  5, -5, -10, 0, 0, -10, -5, 5,
  5, 10, 10, -20, -20, 10, 10, 5,
  0, 0, 0, 0, 0, 0, 0, 0,
];
const T_KNIGHT = [
  -50, -40, -30, -30, -30, -30, -40, -50,
  -40, -20, 0, 0, 0, 0, -20, -40,
  -30, 0, 10, 15, 15, 10, 0, -30,
  -30, 5, 15, 20, 20, 15, 5, -30,
  -30, 0, 15, 20, 20, 15, 0, -30,
  -30, 5, 10, 15, 15, 10, 5, -30,
  -40, -20, 0, 5, 5, 0, -20, -40,
  -50, -40, -30, -30, -30, -30, -40, -50,
];
const T_BISHOP = [
  -20, -10, -10, -10, -10, -10, -10, -20,
  -10, 0, 0, 0, 0, 0, 0, -10,
  -10, 0, 5, 10, 10, 5, 0, -10,
  -10, 5, 5, 10, 10, 5, 5, -10,
  -10, 0, 10, 10, 10, 10, 0, -10,
  -10, 10, 10, 10, 10, 10, 10, -10,
  -10, 5, 0, 0, 0, 0, 5, -10,
  -20, -10, -10, -10, -10, -10, -10, -20,
];
const T_ROOK = [
  0, 0, 0, 0, 0, 0, 0, 0,
  5, 10, 10, 10, 10, 10, 10, 5,
  -5, 0, 0, 0, 0, 0, 0, -5,
  -5, 0, 0, 0, 0, 0, 0, -5,
  -5, 0, 0, 0, 0, 0, 0, -5,
  -5, 0, 0, 0, 0, 0, 0, -5,
  -5, 0, 0, 0, 0, 0, 0, -5,
  0, 0, 0, 5, 5, 0, 0, 0,
];
const T_QUEEN = [
  -20, -10, -10, -5, -5, -10, -10, -20,
  -10, 0, 0, 0, 0, 0, 0, -10,
  -10, 0, 5, 5, 5, 5, 0, -10,
  -5, 0, 5, 5, 5, 5, 0, -5,
  0, 0, 5, 5, 5, 5, 0, -5,
  -10, 5, 5, 5, 5, 5, 0, -10,
  -10, 0, 5, 0, 0, 0, 0, -10,
  -20, -10, -10, -5, -5, -10, -10, -20,
];
const T_KING = [
  -30, -40, -40, -50, -50, -40, -40, -30,
  -30, -40, -40, -50, -50, -40, -40, -30,
  -30, -40, -40, -50, -50, -40, -40, -30,
  -30, -40, -40, -50, -50, -40, -40, -30,
  -20, -30, -30, -40, -40, -30, -30, -20,
  -10, -20, -20, -20, -20, -20, -20, -10,
  20, 20, 0, 0, 0, 0, 20, 20,
  20, 30, 10, 0, 0, 10, 30, 20,
];

const TABLES: Record<PieceSymbol, number[]> = {
  p: T_PAWN, n: T_KNIGHT, b: T_BISHOP, r: T_ROOK, q: T_QUEEN, k: T_KING,
};

/** Static evaluation. Positive = good for white. */
export function evaluate(ch: Chess): number {
  let score = 0;
  const board = ch.board();
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p) continue;
      const idx = p.color === "w" ? r * 8 + c : (7 - r) * 8 + c;
      const v = VAL[p.type] + TABLES[p.type][idx] / 10;
      score += p.color === "w" ? v : -v;
    }
  }
  return score;
}

function orderMoves(moves: Move[]): Move[] {
  return moves
    .map((m, i) => ({
      m,
      s: (m.captured ? 10 + (m.captured === "p" ? 5 : 0) : 0) + (m.promotion ? 8 : 0) - i * 0.01,
    }))
    .sort((a, b) => b.s - a.s)
    .map((x) => x.m);
}

const MATE = 100000;

function search(
  ch: Chess,
  depth: number,
  alpha: number,
  beta: number,
  ply: number,
  cap: number,
  nodes: { n: number },
): number {
  nodes.n += 1;
  // all scores are from WHITE's perspective; the mated side is the side to move
  if (ch.isCheckmate()) return ch.turn() === "w" ? -MATE - ply : MATE + ply;
  if (depth <= 0 || ch.isDraw() || ch.isStalemate()) {
    if (ch.isStalemate() || ch.isDraw()) return 0;
    return ch.turn() === "w" ? evaluate(ch) : -evaluate(ch);
  }
  if (nodes.n > cap) {
    return ch.turn() === "w" ? evaluate(ch) : -evaluate(ch);
  }

  const moves = orderMoves(ch.moves({ verbose: true }));
  if (ch.turn() === "w") {
    let best = -Infinity;
    for (const m of moves) {
      ch.move(m);
      const s = search(ch, depth - 1, alpha, beta, ply + 1, cap, nodes);
      ch.undo();
      if (s > best) best = s;
      if (best > alpha) alpha = best;
      if (beta <= alpha) break;
    }
    return best;
  }
  let best = Infinity;
  for (const m of moves) {
    ch.move(m);
    const s = search(ch, depth - 1, alpha, beta, ply + 1, cap, nodes);
    ch.undo();
    if (s < best) best = s;
    if (best < beta) beta = best;
    if (beta <= alpha) break;
  }
  return best;
}

const CONFIG: Record<Difficulty, { depth: number; cap: number; noise: number; randomChance: number }> = {
  kolay: { depth: 1, cap: 4000, noise: 120, randomChance: 0.35 },
  orta: { depth: 2, cap: 40000, noise: 20, randomChance: 0.05 },
  zor: { depth: 3, cap: 300000, noise: 0, randomChance: 0 },
};

/** Returns a concrete move the bot should play, or null if it has no move. */
export function bestChessMove(fen: string, difficulty: Difficulty): Move | null {
  const ch = new Chess(fen);
  const moves = ch.moves({ verbose: true });
  if (moves.length === 0) return null;
  const cfg = CONFIG[difficulty];

  // Kolay sometimes just plays a random legal move.
  if (Math.random() < cfg.randomChance && difficulty !== "zor") {
    return moves[Math.floor(Math.random() * moves.length)];
  }

  const nodes = { n: 0 };
  const whiteToMove = ch.turn() === "w";
  const scored: { m: Move; s: number }[] = [];
  for (const m of orderMoves(moves)) {
    ch.move(m);
    const s =
      search(ch, cfg.depth - 1, -Infinity, Infinity, 1, cfg.cap, nodes) +
      (Math.random() * 2 - 1) * cfg.noise;
    ch.undo();
    scored.push({ m, s });
  }
  // scores are white-perspective: white maximizes, black minimizes
  scored.sort((a, b) => (whiteToMove ? b.s - a.s : a.s - b.s));
  // Slight variety among near-equal moves.
  const top = scored[0].s;
  const close = scored.filter((x) => Math.abs(x.s - top) <= 15);
  return close[Math.floor(Math.random() * Math.min(close.length, difficulty === "kolay" ? 3 : 2))].m;
}
