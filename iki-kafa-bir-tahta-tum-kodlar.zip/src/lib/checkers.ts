// Azerbaijani checkers (Azerbaycan şaşkisi / Russian draughts rules) — 8×8 board,
// 12 pieces per side on 3 rows.
// - Men move one step diagonally forward; they CAPTURE both forward and backward.
// - Kings ("dama") fly any distance along diagonals; capture by jumping the
//   first enemy on the ray and landing on any empty square beyond it.
// - Captures are mandatory and must be continued until no more are possible.
// - A man reaching the last rank becomes a king immediately — even in the
//   middle of a capture chain — and continues capturing as a king.
// - White (bottom) moves first.

export type CKColor = "w" | "b";

export interface CKCell {
  c: CKColor;
  k: boolean;
}

export const CK_N = 8;
export type CKBoard = (CKCell | null)[]; // 64 cells, idx = r * 8 + c  (r = 0 is top)

export interface CKMove {
  from: number;
  to: number;
  path: number[]; // full jump path incl. from and to
  caps: number[]; // squares of captured pieces
}

export interface CKState {
  board: CKBoard;
  turn: CKColor;
  lastMove: { from: number; to: number; caps: number[]; path: number[] } | null;
  status: "waiting" | "playing" | "finished";
  winner: CKColor | "draw" | null;
  reason: string | null;
  history: { label: string; color: CKColor }[];
  still: number; // consecutive king-only moves w/o capture (30 → draw)
  moveNo: number;
}

export const ck = (r: number, c: number) => r * CK_N + c;
export const ckR = (i: number) => Math.floor(i / CK_N);
export const ckC = (i: number) => i % CK_N;
export const inB = (r: number, c: number) => r >= 0 && r < CK_N && c >= 0 && c < CK_N;
export const opposite = (x: CKColor): CKColor => (x === "w" ? "b" : "w");
/** Black moves down (toward r=7), white moves up (toward r=0). */
export const isLastRow = (color: CKColor, pos: number) =>
  color === "b" ? ckR(pos) === CK_N - 1 : ckR(pos) === 0;

export function sqLabel(pos: number): string {
  return `${String.fromCharCode(97 + ckC(pos))}${CK_N - ckR(pos)}`;
}

export function checkersInitialState(status: "waiting" | "playing" = "playing"): CKState {
  const board: CKBoard = Array(CK_N * CK_N).fill(null);
  for (let r = 0; r < CK_N; r++) {
    for (let c = 0; c < CK_N; c++) {
      if ((r + c) % 2 !== 1) continue; // dark squares only
      if (r < 3) board[ck(r, c)] = { c: "b", k: false };
      else if (r > 4) board[ck(r, c)] = { c: "w", k: false };
    }
  }
  return {
    board,
    turn: "w",
    lastMove: null,
    status,
    winner: null,
    reason: null,
    history: [],
    still: 0,
    moveNo: 0,
  };
}

export function countPieces(board: CKBoard, color: CKColor): number {
  let n = 0;
  for (const p of board) if (p && p.c === color) n++;
  return n;
}

/** Single capture jumps available for a piece at `pos`. `taken` = already captured this chain (cannot be jumped twice). */
function captureJumps(
  board: CKBoard,
  pos: number,
  color: CKColor,
  isKing: boolean,
  taken: number[],
): { to: number; cap: number }[] {
  const r = ckR(pos);
  const c = ckC(pos);
  const out: { to: number; cap: number }[] = [];
  for (const dr of [-1, 1]) {
    for (const dc of [-1, 1]) {
      if (!isKing) {
        const r1 = r + dr;
        const c1 = c + dc;
        const r2 = r + 2 * dr;
        const c2 = c + 2 * dc;
        if (!inB(r2, c2)) continue;
        const midI = ck(r1, c1);
        const mid = board[midI];
        const land = board[ck(r2, c2)];
        if (mid && mid.c !== color && !land && !taken.includes(midI)) {
          out.push({ to: ck(r2, c2), cap: midI });
        }
        continue;
      }
      let rr = r + dr;
      let cc = c + dc;
      let jumped = -1;
      while (inB(rr, cc)) {
        const i = ck(rr, cc);
        const p = board[i];
        if (!p) {
          if (jumped >= 0) out.push({ to: i, cap: jumped });
        } else {
          if (p.c === color || jumped >= 0 || taken.includes(i)) break;
          jumped = i;
        }
        rr += dr;
        cc += dc;
      }
    }
  }
  return out;
}

function plainMoves(board: CKBoard, pos: number, color: CKColor, isKing: boolean): number[] {
  const r = ckR(pos);
  const c = ckC(pos);
  const out: number[] = [];
  if (!isKing) {
    const dir = color === "b" ? 1 : -1;
    for (const dc of [-1, 1]) {
      const nr = r + dir;
      const nc = c + dc;
      if (inB(nr, nc) && !board[ck(nr, nc)]) out.push(ck(nr, nc));
    }
    return out;
  }
  for (const dr of [-1, 1]) {
    for (const dc of [-1, 1]) {
      let rr = r + dr;
      let cc = c + dc;
      while (inB(rr, cc) && !board[ck(rr, cc)]) {
        out.push(ck(rr, cc));
        rr += dr;
        cc += dc;
      }
    }
  }
  return out;
}

/** All complete capture sequences for the piece at `from`. */
export function captureSequences(board: CKBoard, from: number): CKMove[] {
  const piece = board[from];
  if (!piece) return [];
  const out: CKMove[] = [];
  const walk = (cur: number, isKing: boolean, path: number[], caps: number[], b: CKBoard) => {
    const jumps = captureJumps(b, cur, piece.c, isKing, caps);
    if (jumps.length === 0) {
      if (path.length > 1) out.push({ from, to: cur, path, caps });
      return;
    }
    for (const j of jumps) {
      const nb = b.slice();
      // Captured pieces stay on the board until the chain ends (Russian rule —
      // "Turkish strike"), so we only mark them in `caps` and block re-jumping.
      nb[cur] = null;
      let king = isKing;
      if (!king && isLastRow(piece.c, j.to)) king = true;
      nb[j.to] = { c: piece.c, k: king };
      walk(j.to, king, [...path, j.to], [...caps, j.cap], nb);
    }
  };
  walk(from, piece.k, [from], [], board);
  return out;
}

/**
 * All legal moves for `color`. If any capture exists, only captures are legal.
 */
export function legalMoves(board: CKBoard, color: CKColor): { moves: CKMove[]; hasCaptures: boolean } {
  const caps: CKMove[] = [];
  const plains: CKMove[] = [];
  for (let i = 0; i < board.length; i++) {
    const p = board[i];
    if (!p || p.c !== color) continue;
    const seqs = captureSequences(board, i);
    if (seqs.length) caps.push(...seqs);
    else
      for (const to of plainMoves(board, i, color, p.k)) {
        plains.push({ from: i, to, path: [i, to], caps: [] });
      }
  }
  const chosen = caps.length ? caps : plains;
  const map = new Map<string, CKMove>();
  for (const m of chosen) {
    const key = `${m.from}-${m.to}`;
    const prev = map.get(key);
    if (!prev || m.caps.length > prev.caps.length) map.set(key, m);
  }
  return { moves: [...map.values()], hasCaptures: caps.length > 0 };
}

export function applyMoveToBoard(board: CKBoard, move: CKMove): CKBoard {
  const piece = board[move.from]!;
  const nb = board.slice();
  nb[move.from] = null;
  for (const cap of move.caps) nb[cap] = null;
  let k = piece.k;
  if (!k) {
    // promotion if it passes through / ends on the last row
    for (const sq of move.path.slice(1)) if (isLastRow(piece.c, sq)) k = true;
  }
  nb[move.to] = { c: piece.c, k };
  return nb;
}

export function checkersApply(state: CKState, move: CKMove): CKState {
  if (state.status !== "playing") return state;
  const piece = state.board[move.from];
  if (!piece || piece.c !== state.turn) return state;
  const board = applyMoveToBoard(state.board, move);
  const promoted = !piece.k && board[move.to]!.k;

  const nextTurn = opposite(state.turn);
  const still = move.caps.length || !piece.k ? 0 : state.still + 1;
  let status: CKState["status"] = "playing";
  let winner: CKState["winner"] = null;
  let reason: string | null = null;
  if (countPieces(board, nextTurn) === 0) {
    status = "finished";
    winner = state.turn;
    reason = "no-pieces";
  } else if (legalMoves(board, nextTurn).moves.length === 0) {
    status = "finished";
    winner = state.turn;
    reason = "no-moves";
  } else if (still >= 30) {
    status = "finished";
    winner = "draw";
    reason = "thirty";
  }

  const label = `${piece.k ? "♛" : ""}${move.path.map(sqLabel).join(move.caps.length ? ":" : "-")}${
    promoted ? " ♛" : ""
  }`;

  return {
    ...state,
    board,
    turn: nextTurn,
    lastMove: { from: move.from, to: move.to, caps: move.caps, path: move.path },
    status,
    winner,
    reason,
    history: [...state.history, { label, color: state.turn }],
    still,
    moveNo: state.moveNo + 1,
  };
}

export const CK_REASONS_TR: Record<string, string> = {
  "no-pieces": "tüm taşlar alındı",
  "no-moves": "hamle kalmadı",
  thirty: "30 dama hamlesi boyunca yakalama yok",
  resigned: "teslim",
};
