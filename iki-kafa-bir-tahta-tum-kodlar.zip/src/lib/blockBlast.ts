// Block Blast Game Engine
// 8x8 grid block puzzle with drag & drop placement, row & column clears, and combo streaks

export interface BlockShape {
  id: string;
  matrix: number[][]; // 2D array: 1 = block, 0 = empty
  color: string;
  name: string;
}

export type GridCell = string | null; // null = empty, string = color hex/class
export type BoardGrid = GridCell[][]; // 8x8

export interface BlockBlastState {
  grid: BoardGrid;
  availableShapes: (BlockShape | null)[]; // 3 shapes per batch
  score: number;
  highScore: number;
  combo: number; // streak of consecutive moves that cleared lines
  gameOver: boolean;
  lastClearCount: number; // number of lines cleared in last move
  lastScoreGain: number;
}

export const GRID_SIZE = 8;

// Vivid, punchy Block Blast jewel palette (matching reference screenshots)
export const SHAPE_COLORS = [
  "#2563eb", // Royal Sapphire Blue
  "#eab308", // Golden Yellow
  "#9333ea", // Vivid Purple
  "#06b6d4", // Electric Cyan
  "#ef4444", // Bright Ruby Red
  "#10b981", // Emerald Green
  "#f97316", // Tangerine Orange
  "#ec4899", // Bright Magenta
];

const SHAPE_DEFINITIONS: { matrix: number[][]; name: string }[] = [
  // 1x1 dot
  { matrix: [[1]], name: "dot" },

  // 1x2, 2x1
  { matrix: [[1, 1]], name: "h2" },
  { matrix: [[1], [1]], name: "v2" },

  // 1x3, 3x1
  { matrix: [[1, 1, 1]], name: "h3" },
  { matrix: [[1], [1], [1]], name: "v3" },

  // 1x4, 4x1
  { matrix: [[1, 1, 1, 1]], name: "h4" },
  { matrix: [[1], [1], [1], [1]], name: "v4" },

  // 1x5, 5x1
  { matrix: [[1, 1, 1, 1, 1]], name: "h5" },
  { matrix: [[1], [1], [1], [1], [1]], name: "v5" },

  // 2x2 Square
  {
    matrix: [
      [1, 1],
      [1, 1],
    ],
    name: "sq2",
  },

  // 3x3 Square
  {
    matrix: [
      [1, 1, 1],
      [1, 1, 1],
      [1, 1, 1],
    ],
    name: "sq3",
  },

  // L-shapes (2x2 small corner)
  {
    matrix: [
      [1, 0],
      [1, 1],
    ],
    name: "corner2_bl",
  },
  {
    matrix: [
      [0, 1],
      [1, 1],
    ],
    name: "corner2_br",
  },
  {
    matrix: [
      [1, 1],
      [1, 0],
    ],
    name: "corner2_tl",
  },
  {
    matrix: [
      [1, 1],
      [0, 1],
    ],
    name: "corner2_tr",
  },

  // L-shapes (3x3 big corner)
  {
    matrix: [
      [1, 0, 0],
      [1, 0, 0],
      [1, 1, 1],
    ],
    name: "corner3_bl",
  },
  {
    matrix: [
      [0, 0, 1],
      [0, 0, 1],
      [1, 1, 1],
    ],
    name: "corner3_br",
  },
  {
    matrix: [
      [1, 1, 1],
      [1, 0, 0],
      [1, 0, 0],
    ],
    name: "corner3_tl",
  },
  {
    matrix: [
      [1, 1, 1],
      [0, 0, 1],
      [0, 0, 1],
    ],
    name: "corner3_tr",
  },

  // T-shapes
  {
    matrix: [
      [1, 1, 1],
      [0, 1, 0],
    ],
    name: "t_down",
  },
  {
    matrix: [
      [0, 1, 0],
      [1, 1, 1],
    ],
    name: "t_up",
  },
  {
    matrix: [
      [1, 0],
      [1, 1],
      [1, 0],
    ],
    name: "t_right",
  },

  // Z / S shapes
  {
    matrix: [
      [1, 1, 0],
      [0, 1, 1],
    ],
    name: "z_shape",
  },
  {
    matrix: [
      [0, 1, 1],
      [1, 1, 0],
    ],
    name: "s_shape",
  },
];

let shapeIdCounter = 1;

export function generateRandomShape(): BlockShape {
  const def = SHAPE_DEFINITIONS[Math.floor(Math.random() * SHAPE_DEFINITIONS.length)];
  const color = SHAPE_COLORS[Math.floor(Math.random() * SHAPE_COLORS.length)];
  return {
    id: `shape_${shapeIdCounter++}`,
    matrix: def.matrix,
    color,
    name: def.name,
  };
}

export function generateShapeBatch(): (BlockShape | null)[] {
  return [generateRandomShape(), generateRandomShape(), generateRandomShape()];
}

export function createEmptyGrid(): BoardGrid {
  const grid: BoardGrid = [];
  for (let r = 0; r < GRID_SIZE; r++) {
    const row: GridCell[] = [];
    for (let c = 0; c < GRID_SIZE; c++) {
      row.push(null);
    }
    grid.push(row);
  }
  return grid;
}

export function newBlockBlastGame(initialHighScore = 0): BlockBlastState {
  return {
    grid: createEmptyGrid(),
    availableShapes: generateShapeBatch(),
    score: 0,
    highScore: initialHighScore,
    combo: 0,
    gameOver: false,
    lastClearCount: 0,
    lastScoreGain: 0,
  };
}

/** Check if shape can be placed at board row, col */
export function canPlaceShape(
  grid: BoardGrid,
  shape: BlockShape,
  startRow: number,
  startCol: number
): boolean {
  const rows = shape.matrix.length;
  const cols = shape.matrix[0].length;

  if (startRow < 0 || startCol < 0) return false;
  if (startRow + rows > GRID_SIZE || startCol + cols > GRID_SIZE) return false;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (shape.matrix[r][c] === 1) {
        if (grid[startRow + r][startCol + c] !== null) {
          return false;
        }
      }
    }
  }
  return true;
}

/** Check if shape has ANY valid placement on the entire board */
export function canShapeFitAnywhere(grid: BoardGrid, shape: BlockShape): boolean {
  const rows = shape.matrix.length;
  const cols = shape.matrix[0].length;

  for (let r = 0; r <= GRID_SIZE - rows; r++) {
    for (let c = 0; c <= GRID_SIZE - cols; c++) {
      if (canPlaceShape(grid, shape, r, c)) {
        return true;
      }
    }
  }
  return false;
}

/** Check if at least one available shape can fit on the board */
export function hasAnyPossibleMove(
  grid: BoardGrid,
  availableShapes: (BlockShape | null)[]
): boolean {
  for (const shape of availableShapes) {
    if (shape && canShapeFitAnywhere(grid, shape)) {
      return true;
    }
  }
  return false;
}

/** Place a shape onto the grid and perform full line/column clearing */
export function placeShape(
  state: BlockBlastState,
  shapeIndex: number,
  startRow: number,
  startCol: number
): BlockBlastState | null {
  const shape = state.availableShapes[shapeIndex];
  if (!shape || state.gameOver) return null;

  if (!canPlaceShape(state.grid, shape, startRow, startCol)) {
    return null;
  }

  // Clone grid and place the piece
  const newGrid: BoardGrid = state.grid.map((row) => [...row]);
  let placedBlocksCount = 0;

  for (let r = 0; r < shape.matrix.length; r++) {
    for (let c = 0; c < shape.matrix[0].length; c++) {
      if (shape.matrix[r][c] === 1) {
        newGrid[startRow + r][startCol + c] = shape.color;
        placedBlocksCount++;
      }
    }
  }

  // Detect completed rows
  const fullRows: number[] = [];
  for (let r = 0; r < GRID_SIZE; r++) {
    if (newGrid[r].every((cell) => cell !== null)) {
      fullRows.push(r);
    }
  }

  // Detect completed columns
  const fullCols: number[] = [];
  for (let c = 0; c < GRID_SIZE; c++) {
    let colFull = true;
    for (let r = 0; r < GRID_SIZE; r++) {
      if (newGrid[r][c] === null) {
        colFull = false;
        break;
      }
    }
    if (colFull) {
      fullCols.push(c);
    }
  }

  // Clear completed rows & columns
  for (const r of fullRows) {
    for (let c = 0; c < GRID_SIZE; c++) {
      newGrid[r][c] = null;
    }
  }
  for (const c of fullCols) {
    for (let r = 0; r < GRID_SIZE; r++) {
      newGrid[r][c] = null;
    }
  }

  const totalLinesCleared = fullRows.length + fullCols.length;
  let newCombo = state.combo;

  // Calculate score
  let lineScore = 0;
  if (totalLinesCleared > 0) {
    newCombo += 1;
    // Base line clear points + multi-line clear bonus + combo bonus
    const basePoints = [0, 10, 28, 56, 100, 160, 240][Math.min(totalLinesCleared, 6)] || totalLinesCleared * 35;
    const comboBonus = (newCombo - 1) * 10;
    lineScore = basePoints + comboBonus;
  } else {
    newCombo = 0;
  }

  const moveScoreGain = placedBlocksCount + lineScore;
  const newScore = state.score + moveScoreGain;
  const newHighScore = Math.max(state.highScore, newScore);

  // Consume used shape
  let newAvailable = [...state.availableShapes];
  newAvailable[shapeIndex] = null;

  // If all 3 shapes used, spawn 3 new ones
  if (newAvailable.every((s) => s === null)) {
    newAvailable = generateShapeBatch();
  }

  // Check Game Over
  const isGameOver = !hasAnyPossibleMove(newGrid, newAvailable);

  return {
    grid: newGrid,
    availableShapes: newAvailable,
    score: newScore,
    highScore: newHighScore,
    combo: newCombo,
    gameOver: isGameOver,
    lastClearCount: totalLinesCleared,
    lastScoreGain: moveScoreGain,
  };
}
