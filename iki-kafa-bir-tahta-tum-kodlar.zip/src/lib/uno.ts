export type UnoColor = "red" | "yellow" | "green" | "blue" | "wild";
export type UnoValue =
  | "0"
  | "1"
  | "2"
  | "3"
  | "4"
  | "5"
  | "6"
  | "7"
  | "8"
  | "9"
  | "skip"
  | "reverse"
  | "draw2"
  | "wild"
  | "wild4";

export interface UnoCard {
  id: string;
  color: UnoColor;
  value: UnoValue;
  points: number;
}

export interface UnoState {
  playerCount: 2 | 3 | 4;
  playerNames: string[];
  hands: UnoCard[][];
  deck: UnoCard[];
  discardPile: UnoCard[];
  currentColor: UnoColor;
  currentTurn: number;
  direction: 1 | -1; // 1: saat yönü, -1: ters
  status: "playing" | "round_over" | "finished";
  roundWinner: number | null;
  matchWinner: number | null;
  lastAction: string;
  hasDrawnThisTurn: boolean;
  unoDeclared: Record<number, boolean>;
  roundWins: number[]; // Her oyuncunun kazandığı round sayısı (ilk 3 round kazanan maçı alır)
  round: number;
  maxRounds: number; // 3 round kazanan maçın galibi
}

const COLORS: ("red" | "yellow" | "green" | "blue")[] = ["red", "yellow", "green", "blue"];

export function createFullUnoDeck(): UnoCard[] {
  const deck: UnoCard[] = [];
  let uid = 1;

  for (const c of COLORS) {
    // 1x '0'
    deck.push({ id: `card_${uid++}`, color: c, value: "0", points: 0 });

    // 2x '1'-'9'
    for (let n = 1; n <= 9; n++) {
      const valStr = String(n) as UnoValue;
      deck.push({ id: `card_${uid++}`, color: c, value: valStr, points: n });
      deck.push({ id: `card_${uid++}`, color: c, value: valStr, points: n });
    }

    // 2x Action cards
    for (let i = 0; i < 2; i++) {
      deck.push({ id: `card_${uid++}`, color: c, value: "skip", points: 20 });
      deck.push({ id: `card_${uid++}`, color: c, value: "reverse", points: 20 });
      deck.push({ id: `card_${uid++}`, color: c, value: "draw2", points: 20 });
    }
  }

  // 4x Wild & 4x Wild Draw 4
  for (let i = 0; i < 4; i++) {
    deck.push({ id: `card_${uid++}`, color: "wild", value: "wild", points: 50 });
    deck.push({ id: `card_${uid++}`, color: "wild", value: "wild4", points: 50 });
  }

  return shuffle(deck);
}

function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function newUnoGame(
  playerCount: 2 | 3 | 4 = 2,
  playerNames: string[] = ["Sen", "Bot 1", "Bot 2", "Bot 3"].slice(0, playerCount),
  initialRoundWins?: number[],
  currentRound = 1
): UnoState {
  let deck = createFullUnoDeck();
  const hands: UnoCard[][] = [];

  for (let p = 0; p < playerCount; p++) {
    hands.push(deck.slice(0, 7));
    deck = deck.slice(7);
  }

  let starterIdx = deck.findIndex(
    (c) => c.color !== "wild" && c.value !== "draw2" && c.value !== "skip" && c.value !== "reverse"
  );
  if (starterIdx < 0) starterIdx = 0;
  const topCard = deck.splice(starterIdx, 1)[0];

  const unoDeclared: Record<number, boolean> = {};
  for (let p = 0; p < playerCount; p++) unoDeclared[p] = false;

  return {
    playerCount,
    playerNames,
    hands,
    deck,
    discardPile: [topCard],
    currentColor: topCard.color === "wild" ? "red" : topCard.color,
    currentTurn: 0,
    direction: 1,
    status: "playing",
    roundWinner: null,
    matchWinner: null,
    lastAction: `${topCard.color.toUpperCase()} ${topCard.value} ile oyun başladı!`,
    hasDrawnThisTurn: false,
    unoDeclared,
    roundWins: initialRoundWins ?? new Array(playerCount).fill(0),
    round: currentRound,
    maxRounds: 3, // 3 round galibiyet kuralı
  };
}

export function canPlayCard(card: UnoCard, topCard: UnoCard, currentColor: UnoColor): boolean {
  if (card.color === "wild") return true;
  if (card.color === currentColor) return true;
  if (card.value === topCard.value) return true;
  return false;
}

export function getPlayableCards(hand: UnoCard[], topCard: UnoCard, currentColor: UnoColor): UnoCard[] {
  return hand.filter((c) => canPlayCard(c, topCard, currentColor));
}

function nextPlayerIndex(current: number, direction: 1 | -1, total: number, step = 1): number {
  let next = (current + direction * step) % total;
  if (next < 0) next += total;
  return next;
}

function recycleDeckIfNeeded(deck: UnoCard[], discardPile: UnoCard[]): { deck: UnoCard[]; discardPile: UnoCard[] } {
  if (deck.length > 0) return { deck, discardPile };
  if (discardPile.length <= 1) return { deck: [], discardPile };

  const top = discardPile[discardPile.length - 1];
  const rest = discardPile.slice(0, discardPile.length - 1);
  const newDeck = shuffle(rest);
  return { deck: newDeck, discardPile: [top] };
}

export function playUnoCard(
  state: UnoState,
  playerIndex: number,
  cardId: string,
  chosenColor?: UnoColor
): UnoState {
  if (state.status !== "playing" || state.currentTurn !== playerIndex) return state;

  const hand = state.hands[playerIndex];
  const cardIndex = hand.findIndex((c) => c.id === cardId);
  if (cardIndex < 0) return state;

  const card = hand[cardIndex];
  const topCard = state.discardPile[state.discardPile.length - 1];

  if (!canPlayCard(card, topCard, state.currentColor)) return state;

  const newHand = hand.filter((_, i) => i !== cardIndex);
  const newHands = state.hands.map((h, i) => (i === playerIndex ? newHand : h));
  const newDiscard = [...state.discardPile, card];

  let newCurrentColor: UnoColor = card.color;
  if (card.color === "wild") {
    newCurrentColor = chosenColor && chosenColor !== "wild" ? chosenColor : "red";
  }

  // Kart Bittiğinde Round / Maç Kazanma Kontrolü (3 Round Kuralı)
  if (newHand.length === 0) {
    const roundWins = state.roundWins.slice();
    roundWins[playerIndex] += 1;

    const matchWon = roundWins[playerIndex] >= state.maxRounds;

    return {
      ...state,
      hands: newHands,
      discardPile: newDiscard,
      currentColor: newCurrentColor,
      status: matchWon ? "finished" : "round_over",
      roundWinner: playerIndex,
      matchWinner: matchWon ? playerIndex : null,
      roundWins,
      lastAction: matchWon
        ? `🏆 ${state.playerNames[playerIndex]} 3 round kazanarak maçı bitirdi!`
        : `🎉 ${state.playerNames[playerIndex]} bu roundu kazandı! (${roundWins[playerIndex]}/${state.maxRounds})`,
    };
  }

  let newDirection = state.direction;
  let nextStep = 1;
  let { deck, discardPile } = recycleDeckIfNeeded(state.deck, newDiscard);
  const nextTargetPlayer = nextPlayerIndex(playerIndex, newDirection, state.playerCount, 1);

  let actionText = `${state.playerNames[playerIndex]}: ${card.value}`;

  if (card.value === "reverse") {
    if (state.playerCount === 2) {
      nextStep = 2;
      actionText = `${state.playerNames[playerIndex]} Yön Değiştirdi (Pas)!`;
    } else {
      newDirection = (newDirection * -1) as 1 | -1;
      actionText = `${state.playerNames[playerIndex]} Yönü Değiştirdi!`;
    }
  } else if (card.value === "skip") {
    nextStep = 2;
    actionText = `${state.playerNames[nextTargetPlayer]} Pas Geçti!`;
  } else if (card.value === "draw2") {
    const needed = 2;
    let rec = recycleDeckIfNeeded(deck, discardPile);
    deck = rec.deck;
    discardPile = rec.discardPile;

    const drawn = deck.slice(0, needed);
    deck = deck.slice(needed);

    newHands[nextTargetPlayer] = [...newHands[nextTargetPlayer], ...drawn];
    nextStep = 2;
    actionText = `${state.playerNames[nextTargetPlayer]} +2 Kart Çekti ve Pas Geçti!`;
  } else if (card.value === "wild4") {
    const needed = 4;
    let rec = recycleDeckIfNeeded(deck, discardPile);
    deck = rec.deck;
    discardPile = rec.discardPile;

    const drawn = deck.slice(0, needed);
    deck = deck.slice(needed);

    newHands[nextTargetPlayer] = [...newHands[nextTargetPlayer], ...drawn];
    nextStep = 2;
    actionText = `${state.playerNames[playerIndex]} Wild +4 attı, renk: ${newCurrentColor.toUpperCase()}!`;
  } else if (card.value === "wild") {
    actionText = `${state.playerNames[playerIndex]} Wild attı, renk: ${newCurrentColor.toUpperCase()}!`;
  }

  const nextTurn = nextPlayerIndex(playerIndex, newDirection, state.playerCount, nextStep);

  const unoDeclared = { ...state.unoDeclared };
  if (newHand.length === 1) {
    unoDeclared[playerIndex] = true;
    actionText += ` 🔥 UNO!`;
  } else {
    unoDeclared[playerIndex] = false;
  }

  return {
    ...state,
    hands: newHands,
    deck,
    discardPile,
    currentColor: newCurrentColor,
    currentTurn: nextTurn,
    direction: newDirection,
    lastAction: actionText,
    hasDrawnThisTurn: false,
    unoDeclared,
  };
}

export function drawUnoCard(state: UnoState, playerIndex: number): UnoState {
  if (state.status !== "playing" || state.currentTurn !== playerIndex || state.hasDrawnThisTurn) {
    return state;
  }

  let { deck, discardPile } = recycleDeckIfNeeded(state.deck, state.discardPile);
  if (deck.length === 0) {
    return passUnoTurn(state, playerIndex);
  }

  const drawnCard = deck[0];
  const newDeck = deck.slice(1);
  const newHands = state.hands.map((h, i) => (i === playerIndex ? [...h, drawnCard] : h));

  return {
    ...state,
    hands: newHands,
    deck: newDeck,
    discardPile,
    hasDrawnThisTurn: true,
    lastAction: `${state.playerNames[playerIndex]} 1 kart çekti.`,
  };
}

export function passUnoTurn(state: UnoState, playerIndex: number): UnoState {
  if (state.status !== "playing" || state.currentTurn !== playerIndex) return state;

  const nextTurn = nextPlayerIndex(playerIndex, state.direction, state.playerCount, 1);
  return {
    ...state,
    currentTurn: nextTurn,
    hasDrawnThisTurn: false,
    lastAction: `${state.playerNames[playerIndex]} pas geçti.`,
  };
}

export function declareUno(state: UnoState, playerIndex: number): UnoState {
  return {
    ...state,
    unoDeclared: {
      ...state.unoDeclared,
      [playerIndex]: true,
    },
    lastAction: `🔥 ${state.playerNames[playerIndex]}: UNO!`,
  };
}

export function botChooseUnoMove(
  state: UnoState,
  botIndex: number
): { action: "play"; cardId: string; chosenColor?: UnoColor } | { action: "draw" } | { action: "pass" } {
  const hand = state.hands[botIndex];
  const topCard = state.discardPile[state.discardPile.length - 1];
  const playables = getPlayableCards(hand, topCard, state.currentColor);

  if (playables.length > 0) {
    const colorCounts: Record<UnoColor, number> = { red: 0, yellow: 0, green: 0, blue: 0, wild: 0 };
    for (const c of hand) colorCounts[c.color]++;

    let bestColor: UnoColor = "red";
    let maxC = -1;
    for (const c of COLORS) {
      if (colorCounts[c] > maxC) {
        maxC = colorCounts[c];
        bestColor = c;
      }
    }

    const nonWilds = playables.filter((c) => c.color !== "wild");
    const chosenCard =
      nonWilds.length > 0
        ? nonWilds[Math.floor(Math.random() * nonWilds.length)]
        : playables[0];

    return {
      action: "play",
      cardId: chosenCard.id,
      chosenColor: chosenCard.color === "wild" ? bestColor : undefined,
    };
  }

  if (!state.hasDrawnThisTurn) {
    return { action: "draw" };
  }

  return { action: "pass" };
}
