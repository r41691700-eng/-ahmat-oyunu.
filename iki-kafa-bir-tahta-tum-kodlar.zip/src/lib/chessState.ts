import { Chess, type Move, type Square, type PieceSymbol } from "chess.js";

export type Color = "w" | "b";

export interface ChessState {
  fen: string;
  turn: Color;
  history: { san: string; from: string; to: string; color: Color }[];
  lastMove: { from: Square; to: Square } | null;
  status: "waiting" | "playing" | "finished";
  winner: Color | "draw" | null;
  reason: string | null;
  moveNo: number;
}

export const CHESS_INITIAL_FEN =
  "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

export function chessInitialState(status: "waiting" | "playing" = "playing"): ChessState {
  return {
    fen: CHESS_INITIAL_FEN,
    turn: "w",
    history: [],
    lastMove: null,
    status,
    winner: null,
    reason: null,
    moveNo: 0,
  };
}

/** Legal moves from a square (for highlighting). */
export function legalChessTargets(state: ChessState, square: Square): Move[] {
  const ch = new Chess(state.fen);
  return ch.moves({ square, verbose: true });
}

export function isPromotion(state: ChessState, from: Square, to: Square): boolean {
  const ch = new Chess(state.fen);
  return ch.moves({ square: from, verbose: true }).some((m) => m.promotion !== undefined);
}

/**
 * Apply a move to a ChessState. Returns the next state, or null if illegal.
 * `promotion` must be supplied when the move promotes (else it defaults to queen
 * only for bots — human promotions are always user-chosen).
 */
export function chessApply(
  state: ChessState,
  from: Square,
  to: Square,
  promotion?: PieceSymbol,
  allowDefaultQueen = false,
): ChessState | null {
  if (state.status !== "playing") return null;
  const ch = new Chess(state.fen);
  const candidates = ch.moves({ square: from, verbose: true });
  if (candidates.length === 0) return null;
  const target = candidates.find((m) => m.to === to);
  if (!target) return null;
  const promo = target.promotion ? promotion ?? (allowDefaultQueen ? "q" : undefined) : undefined;
  if (target.promotion && !promo) return null; // needs explicit choice
  const mv = ch.move({ from, to, promotion: promo });
  if (!mv) return null;

  let status: ChessState["status"] = "playing";
  let winner: ChessState["winner"] = null;
  let reason: string | null = null;
  if (ch.isCheckmate()) {
    status = "finished";
    winner = mv.color === "w" ? "b" : "w"; // mover wins
    reason = "checkmate";
  } else if (ch.isStalemate()) {
    status = "finished";
    winner = "draw";
    reason = "stalemate";
  } else if (ch.isThreefoldRepetition()) {
    status = "finished";
    winner = "draw";
    reason = "repetition";
  } else if (ch.isInsufficientMaterial()) {
    status = "finished";
    winner = "draw";
    reason = "insufficient";
  } else if (ch.isDraw()) {
    status = "finished";
    winner = "draw";
    reason = "fifty";
  }

  return {
    fen: ch.fen(),
    turn: ch.turn() as Color,
    history: [
      ...state.history,
      { san: mv.san, from: mv.from, to: mv.to, color: mv.color as Color },
    ],
    lastMove: { from: mv.from, to: mv.to },
    status,
    winner,
    reason,
    moveNo: state.moveNo + 1,
  };
}

/** Square of the king currently in check (for highlighting). */
export function checkedKingSquare(state: ChessState): Square | null {
  const ch = new Chess(state.fen);
  if (!ch.inCheck()) return null;
  const turn = ch.turn() as Color;
  for (const row of ch.board()) {
    for (const p of row) {
      if (p && p.type === "k" && p.color === turn) return p.square;
    }
  }
  return null;
}

/** Pieces captured BY `by` (i.e. belonging to the opponent). */
export function capturedPieces(state: ChessState, by: Color): string[] {
  const ch = new Chess(state.fen);
  const start: Record<PieceSymbol, number> = { p: 8, n: 2, b: 2, r: 2, q: 1, k: 1 };
  const count: Record<PieceSymbol, number> = { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 };
  for (const row of ch.board()) {
    for (const p of row) {
      if (p && p.color !== by) count[p.type] += 1;
    }
  }
  const out: string[] = [];
  const order: PieceSymbol[] = ["q", "r", "b", "n", "p"];
  for (const t of order) {
    for (let i = 0; i < start[t] - count[t]; i++) out.push(t);
  }
  return out;
}

export const CHESS_PIECE_GLYPH: Record<PieceSymbol, string> = {
  p: "♟",
  n: "♞",
  b: "♝",
  r: "♜",
  q: "♛",
  k: "♚",
};

export const REASON_TR: Record<string, string> = {
  checkmate: "şah mat",
  stalemate: "pat",
  repetition: "üç kez tekrarla",
  insufficient: "yetersiz malzeme",
  fifty: "elli hamle kuralı",
  resigned: "teslim",
};
